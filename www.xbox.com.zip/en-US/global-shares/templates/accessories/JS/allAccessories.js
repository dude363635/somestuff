$(document).ready(function() {
    $("body").append('<script type="text/javascript" src="/en-US/global-shares/templates/accessories/JS/allAccessories-Sheet1.js"></s' + 'cript>');
});