$(document).ready(function() {

    if ($(".stealth-carousel").length) {

        $(".stealth-carousel").each(function() {
            // set any existing aria-live to off for center carousel
            $(this).find(".center-carousel").attr("aria-live", "off");

            // create left and right carousels from center carousel, for ease of maintenance

            var centerPanels = $(this).find(".center-carousel .stealth-sub-carousel-panel");

            var panelsMax = (centerPanels.length - 1);

            var leftPanels = new Array;
            var rightPanels = new Array;

            // sort center panels into left and right carousels
            for (var i = 0; i <= panelsMax; i++) {
                // right carousel sorting
                if (i == 0) {
                    rightPanel = panelsMax;
                } else {
                    rightPanel = (i - 1);
                }

                rightPanels[rightPanel] = $(centerPanels[i]).clone().attr({ "class": "stealth-panel-" + (rightPanel + 1) + " stealth-sub-carousel-panel", "aria-hidden": "true", "tabindex": "-1", "role": "presentation" });

                //left carousel sorting
                if (i == panelsMax) {
                    leftPanel = 0;
                } else {
                    leftPanel = (i + 1);
                }
                leftPanels[leftPanel] = $(centerPanels[i]).clone().attr({ "class": "stealth-panel-" + (leftPanel + 1) + " stealth-sub-carousel-panel", "aria-hidden": "true", "tabindex": "-1", "role": "presentation" });

                //add numbered class to center panels for script to work
                $(centerPanels[i]).attr("class", "stealth-panel-" + (i + 1) + " stealth-sub-carousel-panel");
            }

            // create left and right carousel containers
            var $leftCarousel = $('<div/>').prependTo($(this)).attr({ "class": "stealth-sub-carousel left-carousel", "aria-hidden": "true", "tabindex": "-1", "role": "presentation" });
            var $rightCarousel = $('<div/>').appendTo($(this)).attr({ "class": "stealth-sub-carousel right-carousel", "aria-hidden": "true", "tabindex": "-1", "role": "presentation" });


            //put panels in place
            for (var i = 0; i <= panelsMax; i++) {
                $(leftPanels[i]).appendTo($(this).find(".left-carousel"));
                $(rightPanels[i]).appendTo($(this).find(".right-carousel"));
            }

            // remove any IDs from right/left panels
            $(".stealth-sub-carousel.left-carousel .stealth-sub-carousel-panel, .stealth-sub-carousel.right-carousel .stealth-sub-carousel-panel, .stealth-sub-carousel.right-carousel *, .stealth-sub-carousel.left-carousel *").removeAttr("id");

            $(".stealth-sub-carousel.center-carousel .stealth-panel-1").addClass("panel-show");

        });

    }

    // ========================================
    //pre-existing functionality

    if ($(".stealth-carousel").length) {

        $(".stealth-carousel").each(function(index, item) {
            function arrowHeights() {
                //-EL:Changed to panel feature to put arrow at center of image, not whole container
                if ($(item).hasClass("wide") && $(item).find('.center-carousel').find('.stealth-panel-' + currentPanel).find('.panel-feature').length > -1) {
                    var arrowHeight = $(item).find('.center-carousel').find('.stealth-panel-' + currentPanel).find('.panel-feature').height() / 2;
                    $(item).find('.stealth-carousel-arrow').css('top', arrowHeight + "px");
                }
                //-SGM: accounting for panels with heroes in them to avoid having to branch this script
                if ($(item).hasClass("wide") && $(item).find('.center-carousel').find('.stealth-panel-' + currentPanel).find('.m-hero-item').length > -1) {
                    var arrowHeight = $(item).find('.center-carousel').find('.stealth-panel-' + currentPanel).find('.m-hero-item').height() / 2;
                    $(item).find('.stealth-carousel-arrow').css('top', arrowHeight + "px");
                }

            }
            arrowHeights();

            var currentPanel = 1;
            var panelCount = $(item).find(".stealth-sub-carousel").first().find('[class^="stealth-panel-"]').length;

            function rotateCaroLeft(focusedCarousel) {
                var nextPanel = currentPanel - 1;
                if (nextPanel < 1) {
                    nextPanel = panelCount;
                }

                $(focusedCarousel).find(".stealth-panel-" + currentPanel).removeClass("panel-show").addClass("panel-hide").css({ "animation": "panelFadeOut 0.4s linear", "opacity": "0", "z-index": "-1" });
                $(focusedCarousel).find(".stealth-panel-" + nextPanel).removeClass("panel-hide").addClass("panel-show").css({ "animation": "panelFadeIn 0.4s linear", "opacity": "1", "z-index": "12", }).find("a, button, summary").attr({ "tabindex": "-1", "aria-hidden": "true" });
                currentPanel = nextPanel;

                $(focusedCarousel).find(".center-carousel .stealth-panel-" + currentPanel + " *").removeClass("x-hidden-focus");

                $(focusedCarousel).find(".center-carousel .stealth-sub-carousel-panel").attr("aria-label", "");

                $(focusedCarousel).find(".center-carousel .stealth-panel-" + currentPanel + " .panel-feature img").focus();
                $(focusedCarousel).find(".center-carousel .stealth-panel-" + currentPanel).attr("aria-label", "previous slide");
                // restore a and button tab focus on active panel only
                $(focusedCarousel).find(".center-carousel .stealth-panel-" + currentPanel).attr("aria-hidden", "false").find("a, button, summary").attr({ "tabindex": "0", "aria-hidden": "false" });
                arrowHeights();
            }

            function rotateCaroRight(focusedCarousel, jumpToPanel) {
                var nextPanel;

                if (jumpToPanel != null) {
                    nextPanel = jumpToPanel;
                } else {
                    nextPanel = currentPanel + 1;
                }
                //var nextPanel = currentPanel + 1;
                if (nextPanel > panelCount) {
                    nextPanel = 1;
                }
                $(focusedCarousel).find(".stealth-panel-" + currentPanel).removeClass("panel-show").addClass("panel-hide").css({ "animation": "panelFadeOut 0.4s linear", "opacity": "0", "z-index": "-1" });
                $(focusedCarousel).find(".stealth-panel-" + nextPanel).removeClass("panel-hide").addClass("panel-show").css({ "animation": "panelFadeIn 0.4s linear", "opacity": "1", "z-index": "12" }).find("a, button, summary").attr({ "tabindex": "-1", "aria-hidden": "true" });

                if (jumpToPanel != null) {
                    $(window).on("load", function() {
                        setTimeout(function() {
                            $("#" + theId + " a.OttoGallery").click();
                            $(".lightboxcontent").attr("aria-live", "assertive");
                        }, 2000);
                    });
                }

                currentPanel = nextPanel;

                $(focusedCarousel).find(".center-carousel .stealth-panel-" + currentPanel + " *").removeClass("x-hidden-focus");

                $(focusedCarousel).find(".center-carousel .stealth-sub-carousel-panel").attr("aria-label", "");


                $(focusedCarousel).find(".center-carousel .stealth-panel-" + currentPanel + " .panel-feature img").focus();
                $(focusedCarousel).find(".center-carousel .stealth-panel-" + currentPanel).attr("aria-label", "next slide");

                // restore a and button tab focus on active panel only
                $(focusedCarousel).find(".center-carousel .stealth-panel-" + currentPanel).attr("aria-hidden", "false").find("a, button, summary").attr({ "tabindex": "0", "aria-hidden": "false" });

                arrowHeights();
            }

            // disable a and button tab focus except starting panel
            $(item).find("[class^=stealth-panel]").not(".center-carousel .stealth-panel-1").attr("aria-hidden", "true").find("a, button, summary").attr({ "tabindex": "-1", "aria-hidden": "true" });

            $(".stealth-carousel-arrow").attr("role", "button");

            $(item).find('.left-arrow').on("keydown", function(e) {
                    (13 == e.keyCode || 32 == e.keyCode) && $(this).click()
                }),
                $(item).find('.left-arrow').on("click", function() {
                    //make screen reader read the button every time it's activated
                    thisArrow = $(this);
                    $(thisArrow).attr("aria-live", "polite");
                    thisArrowAria = $(thisArrow).attr("aria-label");
                    $(thisArrow).attr({ "aria-label": "", "style": "display: none;" });
                    $(thisArrow).blur();
                    $(thisArrow).attr({ "aria-label": thisArrowAria, "style": "display: block;" });

                    setTimeout(function() {
                        $(thisArrow).focus();
                    }, 10);

                    // disable a and button tab focus on every navigation
                    $(item).find("[class^=stealth-panel]").attr("aria-hidden", "true").find("a, button, summary").attr({ "tabindex": "-1", "aria-hidden": "true" });
                    rotateCaroLeft(item);
                });

            $(item).find('.right-arrow').on("keydown", function(e) {
                    (13 == e.keyCode || 32 == e.keyCode) && $(this).click()
                }),
                $(item).find('.right-arrow').on("click", function() {
                    //make screen reader read the button every time it's activated
                    thisArrow = $(this);
                    $(thisArrow).attr("aria-live", "polite");
                    thisArrowAria = $(thisArrow).attr("aria-label");
                    $(thisArrow).attr({ "aria-label": "", "style": "display: none;" });
                    $(thisArrow).blur();
                    $(thisArrow).attr({ "aria-label": thisArrowAria, "style": "display: block;" });

                    setTimeout(function() {
                        $(thisArrow).focus();
                    }, 10);

                    // disable a and button tab focus on every navigation
                    $(item).find("[class^=stealth-panel]").attr("aria-hidden", "true").find("a, button, summary").attr({ "tabindex": "-1", "aria-hidden": "true" });
                    rotateCaroRight(item);
                });


            var touchstartX = 0;
            var touchendX = 0;

            item.addEventListener("touchstart", function(event) {
                touchstartX = event.changedTouches[0].screenX;
            }, false);

            item.addEventListener("touchend", function(event) {
                touchendX = event.changedTouches[0].screenX;
                var distance = touchendX - touchstartX;
                if (distance > 30) {
                    rotateCaroLeft(item);
                } else if (distance < -30) {
                    rotateCaroRight(item);
                }
            }, false);

            var clickstartX = 0;
            var clickendX = 0;

            $(item).on('mousedown', function(event) {
                clickstartX = event.clientX;
            });

            $(item).on('mouseup', function(event) {
                clickendX = event.clientX;
                var distance = clickendX - clickstartX;
                if (distance > 30) {
                    rotateCaroLeft(item);
                } else if (distance < -30) {
                    rotateCaroRight(item);
                }
            });

            item.addEventListener("dragend", function(event) {
                clickendX = event.clientX;
                var distance = clickendX - clickstartX;
                if (distance > 30) {
                    rotateCaroLeft(item);
                } else if (distance < -30) {
                    rotateCaroRight(item);
                }
            }, false);


            $(window).on("load resize", function() {
                arrowHeights();
            }); // skip to specific slide 

            // get hashtag, make sure it's is lower case
            theHash = document.location.hash.toLowerCase();
            theId = document.location.hash.substring(1);

            var centerPanels = $(this).find(".center-carousel .stealth-sub-carousel-panel");
            var targetIndex;
            if (theHash.length) {
                $(centerPanels).each(function() {
                    if ($(this).attr("id") == theId) {

                        targetIndex = ($(this).index() + 1);

                        rotateCaroRight(item, targetIndex);

                    }
                });

            }

        });

    }

    $(".video-sneak-slider a.OttoGallery").on("click", function() {
        sliderOffset = $(".video-sneak-slider").offset().top;
        bannerHeight = 0;
        if ($(".video-sneak-slider .m-banner").length) {
            bannerHeight = $(".video-sneak-slider .m-banner").outerHeight(true);
        }
        scrollTarget = sliderOffset + bannerHeight - 72;

        $(".lightboxclosebutton").on("click", function() {
            $('html,body').scrollTop(scrollTarget);
        });
    });

});