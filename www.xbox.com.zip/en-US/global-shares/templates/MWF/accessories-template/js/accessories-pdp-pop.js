// Accessories Pop
$(document).ready(function() {

    var API_pop = (function() {
        var prodIdForced = $(".accInfo").attr("data-productId");
        var prodIdUpdForced = $(".accInfo").attr("data-updated-productId");
        var specIdBigForced = $(".accInfo").attr("data-special-productId");
        var stripQueryString = document.URL.split("?");
  
        var currentUrl = stripQueryString[0].split("/");
        var pageId = currentUrl[currentUrl.length - 1];
        if (pageId.toLowerCase() === "home") {
            pageId = currentUrl[currentUrl.length - 2];
        }
        if (pageId.indexOf("#") !== -1) {
            pageId = pageId.split("#")[0];
        }
  
        var accessoryVersion = currentUrl[currentUrl.length - 2];
        if (pageId.toLowerCase() === "home" || pageId == "") {
            pageId = currentUrl[currentUrl.length - 2];
            accessoryVersion = currentUrl[currentUrl.length - 3];
        }
  
        // Force Page IDs
        if (pageId === "starfield-limited-edition" && accessoryVersion === "controllers") {
            pageId = "starfield-controller";
        } else if (pageId === "starfield-limited-edition" && accessoryVersion === "headsets") {
            pageId = "starfield-headset";
        }
  
        var urlRegion = document.URL.split("/")[3].toLowerCase();
        var countryCode = urlRegion.split("-")[1].toUpperCase();
        var hasCTA = true;
        var sheetDataLoc = allAccessories1.locales[urlRegion];
        var regionSoldout = globalSoldout.locales[urlRegion];
        var currentProduct;
        var apiMSRPPrice = "";
        var apiListPrice = "";
        var apiRecurrencePrice = "";
        var secondProduct;
        var erpTwoProduct = $("#secondErp").attr("data-page-id");
  
        for (var i = 0; i < sheetDataLoc.length; i++) {
            var splitCurrentProductURL = sheetDataLoc[i].detailsURL.split("/");
            var currentProductPageId = splitCurrentProductURL[splitCurrentProductURL.length - 1];
            var currentProductAccessoryVersion = splitCurrentProductURL[splitCurrentProductURL.length - 2];
            if (currentProductPageId.toLowerCase() === "home" || currentProductPageId == "") {
                currentProductPageId = splitCurrentProductURL[splitCurrentProductURL.length - 2];
                currentProductAccessoryVersion = splitCurrentProductURL[splitCurrentProductURL.length - 3];
            }
  
            prodId = undefined;
            if (sheetDataLoc[i].sheetId.toLowerCase() === pageId.toLowerCase() && accessoryVersion.toLowerCase() === currentProductAccessoryVersion.toLowerCase()) {
                currentProduct = sheetDataLoc[i];
                
                if (currentProduct.poPid.indexOf("/") !== -1) {
                    prodId = currentProduct.poPid.toUpperCase();
                } else if (prodIdForced !== undefined && prodIdForced.indexOf("/") !== -1) {
                    prodId = prodIdForced;
                } else {
                    prodId = "";
                }
                if (currentProduct.gaPid.indexOf("/") !== -1) {
                    prodIdUpd = currentProduct.gaPid.toUpperCase();
                } else if (prodIdUpdForced !== undefined && prodIdUpdForced.indexOf("/") !== -1) {
                    prodIdUpd = prodIdUpdForced;
                } else {
                    prodIdUpd = "updnone";
                }
                if (currentProduct.specPid.length > 0) {
                    specIdBig = currentProduct.specPid.toUpperCase();
                } else if (specIdBigForced !== undefined && specIdBigForced.indexOf("/") !== -1) {
                    specIdBig = specIdBigForced;
                } else {
                    specIdBig = "specnone";
                }
  
                if (currentProduct.retailer === "retailers-page") {
                    $(".gotoRetailer").attr("href", "https://www.xbox.com/" + urlRegion + "/where-to-buy#accessory");
                    $(".gotoRetailer").removeClass("hiddenImp")
                } else if (currentProduct.retailer === "lightbox") {
                    $(".retailerLB").removeClass("hiddenImp")
                } else if (currentProduct.retailer === "no-retailers") {
                    $(".gotoRetailer").css("display", "none")
                } else {
                    hasCTA = false;
                    if (currentProduct.poPid === "" && currentProduct.gaPid === "" && currentProduct.specPid === "") {
                        $(".greenBar").remove();
                    }
                }
                break;
            }
  
  
        }
  
        for (var v = 0; v < sheetDataLoc.length; v++) {
            if (erpTwoProduct !== undefined) {
                if (sheetDataLoc[v].sheetId.toLowerCase() === erpTwoProduct.toLowerCase()) {
                    secondProduct = sheetDataLoc[v];
                    break;
                }
            }
        }
  
        if (prodId === undefined && prodIdUpd === undefined && specIdBig === undefined) { throw ("New Product ID " + pageId + " not found in Accessories Hub JSON allAccessories1.js. Please check spreadsheet.") }
  
        var currencyFormat = priceFormat.locales[urlRegion];
        var priceAsterisks = ($(".accInfo").attr("data-num-asterisk") == "2") ? "<a class='c-hyperlink' href='#price-legal' style='margin: 0' aria-label='" + priceFormat.locales[urlRegion]["keyJumpdown"] + "'><sup>**</sup></a>" : "<a class='c-hyperlink' href='#price-legal' style='margin: 0;' aria-label='" + priceFormat.locales[urlRegion]["keyJumpdown"] + "'><sup>*</sup></a>";
  
        // Adding Price Legal ID Dynamically
        $(".legal .c-caption-1").eq(1).attr("id", "price-legal");
  
  
        // detect daylight saving
        Date.prototype.stdTimezoneOffset = function() {
            var jan = new Date(this.getFullYear(), 0, 1);
            var jul = new Date(this.getFullYear(), 6, 1);
            return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
        }
        Date.prototype.dst = function() {
            return this.getTimezoneOffset() < this.stdTimezoneOffset();
        }
        var pacificoffset = 8;
        var dsttest = new Date();
        var usertzhours = dsttest.getTimezoneOffset() / 60;
        if (dsttest.dst()) {
            pacificoffset = 7;
        }
  
        // check to see if updated bigid is live
        // run through specIdBig, prodIdUpd, prodId
        apiTest(specIdBig);
        function apiTest(bigid) {
          if (bigid !== undefined && bigid !== "" && bigid !== "####" && bigid.length > 11) {
              if (bigid.length === 12) {
                  var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + bigid + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                  $.get(apiUrlTest)
                      .done(function(responseData) {
                          apiDataTest = responseData;
                          if (apiDataTest.Products.length === 0) {
                            if (bigid === specIdBig) {
                              apiTest(prodIdUpd);
                            } else if (bigid === prodIdUpd) {
                              apiTest(prodId);
                            } else {
                              idFound(bigid);
                            }
                          } else {
                              idFound(bigid);
                          }
                      })
                      .fail(function() {
                        if (bigid === specIdBig) {
                          apiTest(prodIdUpd);
                        } else if (bigid === prodIdUpd) {
                          apiTest(prodId);
                        } else {  
                          idFound(bigid);
                        }
                      })
              } else {
                  var testSku = bigid.split("/")[1];
                  var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + bigid.split("/")[0] + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                  $.get(apiUrlTest)
                      .done(function(responseData) {
                          apiDataTest = responseData;
                          if (apiDataTest.Products.length === 0) {
                              //console.log("test 1 " + index);
                              if (bigid === specIdBig) {
                                apiTest(prodIdUpd);
                              } else if (bigid === prodIdUpd) {
                                apiTest(prodId);
                              } else {
                                idFound(bigid);
                              }
                          } else {
                              var skuFound = false;
                              var skuIndex = 0;
                              apiDataTest.Products[0].DisplaySkuAvailabilities.forEach(function(y) {
                                  var stillLooking = true;
                                  var previousSku = "";                              
                                  y.Availabilities.forEach(function(z) {
                                    // console.log(z.SkuId + " " + testSku)
                                      if ((z.SkuId === testSku) && stillLooking) {
                                          skuFound = true;
                                          apiMSRPPrice = z.OrderManagementData.Price.MSRP;
                                          apiListPrice = z.OrderManagementData.Price.ListPrice;
                                          ////console.log(apiMSRPPrice + " - " + apiListPrice);
                                          stillLooking = false; //Leave loop, there may be multiple matches but the first one is ususally the one you want.
                                          y.HistoricalBestAvailabilities.forEach(function(z) {
                                            apiRecurrencePrice = z.OrderManagementData.Price.ListPrice;
                                        })
                                      } else if (!skuFound && (previousSku.indexOf(z.SkuId) === -1)){
                                         skuIndex++;
                                         previousSku += z.SkuId + ","; //To make sure each DisplaySkuAvailabilities is only counted once.
                                      }
                                  })
                              })
                              if (skuFound === false) {
                                  if (bigid === specIdBig) {
                                    apiTest(prodIdUpd);
                                  } else if (bigid === prodIdUpd) {
                                    apiTest(prodId);
                                  } else {
                                    idFound(bigid);
                                  }
                              } else {
                                  var ispreorder = responseData.Products[0].DisplaySkuAvailabilities[skuIndex].Sku.Properties.IsPreOrder;
                                  //console.log("IS PREORDER + index " + ispreorder + " " + index);
                                  if (ispreorder.toString().toLowerCase() === "true") {
                                      var potext = priceFormat.locales[urlRegion].keyPreorder.toUpperCase();
                                      $(".addToCartBtn").text(potext);
                                      $(".addToCartBtn").removeClass("hiddenImp");
                                      // $(".CTAdiv .addToCartBtn").removeClass("hiddenImp");
                                      //console.log("test 3 " + index);
                                      idFound(bigid);
                                  } else {
                                      idFound(bigid);
                                  }
    
                              }
                          }
                      })
                      .fail(function() {
                          if (bigid === specIdBig) {
                            apiTest(prodIdUpd);
                          } else if (bigid === prodIdUpd) {
                            apiTest(prodId);
                          } else {
                            idFound(bigid);
                          }
                      })
              }
          } else {
              if (bigid === specIdBig) {
                apiTest(prodIdUpd);
              } else if (bigid === prodIdUpd) {
                apiTest(prodId);
              } else {
                idFound(bigid);
              }
          }
        }
  
        function idFound(bid) {
            var prodIdBig = bid.split("/")[0];
            var apiUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + prodIdBig + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
            var guidIds = [];
            var apiData;
            var customATC = $(".accInfo").attr("data-custom-addtocart-url");
            if (customATC === undefined) { customATC = ""; }
  
            var sheetDataLoc = allAccessories1.locales[urlRegion];
  
            // Add to Cart if in new store
            if (prodIdBig.length > 10) {
                $.get(apiUrl)
                    .done(function(responseData) {
                        apiData = responseData;
                        populate();
                    })
            } else {
                let releasedateraw = currentProduct.releaseDate;
                date(releasedateraw);
            }
  
            if (currentProduct === undefined) {
                throw ("The ProductID " + bid + " is not found in the console JSON. Please check the spreadsheet.");
            }
            let nonStore = false;
            if (prodIdBig.length < 12) {
                console.log("No Product ID found")
                $(".purchase.store").remove();
                $(".purchase.retailer a").removeClass("f-lightweight").addClass("buffer");
                nonStore = true;
            } else {
                $(".purchRow2").hide();
                // Elite Buy Box
                $(".purchase.retailer").hide();
            }
  
            var buytext = currentProduct.buyText; // USE THIS ONE
  
            $(".buyText").text(buytext);
  
            if ($(".buyText").text() === "####" || $(".buyText").text() === "") {
                $(".buyText").hide();
            }
  
            var priceNumber = currentProduct.priceNumber;
            var priceText = currentProduct.priceText;
            var tprNumber = currentProduct.tprPriceNumber;
            var beforeMSRP = priceFormat.locales[urlRegion].keyMsrpbefore;
            var afterMSRP = priceFormat.locales[urlRegion].keyMsrpafter;
            
  
            var addtocartText = priceFormat.locales[urlRegion].keyAddtocart;
  
            var hasBuyBox = $("#standalonePurch").length;
  
            // ERP Pricing
            var erpText = priceFormat.locales[urlRegion].keyErptext;
            var priceDisclamierAria = priceFormat.locales[urlRegion].keyPriceAria;
            var keyLimitedTimeCopy = priceFormat.locales[urlRegion].keyLimitedTimeCopy;
  
            // For Added Purchase Section
            if (hasBuyBox !== 0) {
                priceDisclamierAria = priceDisclamierAria.replace(/\*/,"");
                erpText = erpText.replace("*", "<a href='#prices' class='c-hyperlink' aria-label='" + priceDisclamierAria + "'><sup>*</sup></a>");
            } else {
                erpText = erpText.replace("*", "<a href='#prices' class='c-hyperlink' aria-label='" + priceDisclamierAria + "'><sup>**</sup></a>");
            }
  
            $("#price-legal").attr("id", "prices");
  
            var useAPIPrice = true; // Using a '!' character at the beginning of the priceText in the allConsoles.js price to override the API price.
            if (priceText !== "" && priceText !== undefined && priceText.indexOf('!') != -1) {
                useAPIPrice = false;
            }
  
            var canUseAPI_MSRP = (apiMSRPPrice !== "" && apiMSRPPrice != "0" && apiMSRPPrice != "100000" && useAPIPrice == true);
  
            if (priceNumber != "####") {
                var priceText = formatCurrency(priceNumber, currencyFormat);
                if (tprNumber != "####") {
                    var discountedPriceText = formatCurrency(tprNumber, currencyFormat);
                }
            }
            if (canUseAPI_MSRP) {
                priceText = formatCurrency(apiMSRPPrice, currencyFormat);
                //console.log("msrp price= " + apiMSRPPrice);
                //console.log("list price = " + apiListPrice);
                if (apiListPrice !== "" && (apiListPrice < apiMSRPPrice)) {
                    discountedPriceText = formatCurrency(apiListPrice, currencyFormat);
                    //console.log("discount price = " + discountedPriceText);
                }
            }
  
            // ERP
            var erpPricing = currentProduct.priceText;
            var recurrenceCopy = priceFormat.locales[urlRegion].keyRecurrenceCopy;
  
            // EU Changes 
            var euchangeArray = ["cs-cz", "da-dk", "de-at", "de-de", "el-gr", "en-ie", "es-es", "fi-fi", "fr-be", "fr-fr", "hu-hu", "it-it", "nl-be", "nl-nl", "pl-pl", "pt-pt", "sk-sk", "sv-se"];
            var nonStoreEU = ["el-gr","hu-hu","sk-sk"];
            
            // No MS Pages for removing MS Text 
            var noMSStorePages = ["turtle-beach-recon-cloud","gamesir-x2-pro-mobile","backbone-one","moga-xp5-x","sn30-pro"];

            // MS Exclusive Pages
            var microsoftStorePages = ["fire-vapor-special-edition"];
  
            var microsoftText = " Microsoft Store";
  
            // Lowest 30 Day Price
            if (euchangeArray.indexOf(urlRegion) !== -1) {
                $(".gotoRetailer").before('<p class="c-subheading-3"><span class="price-erp"></span></p>');
                $(".purchRow2").addClass("priceCTA");
  
                if (apiListPrice !== apiMSRPPrice) {
                    apiRecurrencePrice = formatCurrency(apiRecurrencePrice, currencyFormat);
                    recurrenceCopy = recurrenceCopy.replace("PLACEHOLDER", apiRecurrencePrice);
                    $(".purchRow1 .priceCTA").after('<p class="c-subheading-3" style="padding-top: 24px">' + recurrenceCopy + '</p>');
                }
  
            } 
  
            if (erpPricing.indexOf(",") !== -1) {
                var erpPrices = erpPricing.split(",");
                var erpPriceTpr = formatCurrency(erpPrices[0], currencyFormat);
                var erpPriceList = formatCurrency(erpPrices[1], currencyFormat);
                if (hasBuyBox !== 0) {
                    $(".price-erp").html('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through; margin-right: 10px;"> ' + erpPriceTpr + '<span class="text-erp">' + erpText + '</span>' + ' </span> ' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + erpPriceList);
                } else {
                    $(".price-erp").append('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through; margin-right: 10px;"> ' + erpPriceTpr + '<span class="text-erp">' + erpText + '</span>' + ' </span> ' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + erpPriceList);
                }
  
                $("#prices").text(keyLimitedTimeCopy);
  
            } else if (erpPricing.toLowerCase() === "match") {
                if (!discountedPriceText) {
                    $(".price-erp").html(priceText);
                } else {
                    $(".price-erp").append('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through; margin-right: 10px;"> ' + priceText + '<span class="text-erp">' + erpText + '</span>' + ' </span> ' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + discountedPriceText);
                }
            } else {
                if ((erpPricing !== "####") && (erpPricing !== undefined)) {
                    $(".price-erp").text(formatCurrency(erpPricing, currencyFormat)).append('<span class="text-erp">' + erpText + '</span>');
                } else if (erpPricing === "####") {
                    $(".price-erp").hide();
                    $(".purchRow2 .c-subheading-3").remove();
                    $(".erp-disclaimer").hide();
                }
            }
  
            // Hiding Retailer Price for nonStoreEU
            if(nonStoreEU.indexOf(urlRegion) !== -1) {
                $(".purchRow2 .c-subheading-3").remove();
            }
            
            if(noMSStorePages.indexOf(pageId) !== -1) {
                $(".purchRow2 .c-subheading-3").remove();
                $(".purchRow2 .gotoRetailer").show();
            }
            // Second Prouct Price
            if (secondProduct !== undefined) {
                var erpTwo = secondProduct.priceText;
                if (erpTwo.indexOf(",") !== -1) {
                    var erpPricesTwo = erpTwo.split(",");
                    var erpPriceTprTwo = formatCurrency(erpPricesTwo[0], currencyFormat);
                    var erpPriceListTwo = formatCurrency(erpPricesTwo[1], currencyFormat);
                    $(".price-erpTwo").html('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through; margin-right: 10px;"> ' + erpPriceTprTwo + '<span class="text-erp">' + erpText + '</span>' + ' </span> ' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + erpPriceListTwo);
                } else {
                    $(".price-erpTwo").text(formatCurrency(erpTwo, currencyFormat)).append('<span class="text-erp">' + erpText + '</span>');
                }
                
                if (erpTwo === "####") {
                    $(".price-erpTwo").hide();
                }
            }
  
            if (priceText && priceText.indexOf("####") == -1) {
                if (!discountedPriceText) {
                    if (euchangeArray.indexOf(urlRegion) !== -1 && nonStoreEU.indexOf(urlRegion) === -1 && noMSStorePages.indexOf(pageId) === -1) {
                        $(".purchRow1 .price-msrp, .c-in-page-navigation .price-msrp").append(priceText + '<span class="text-erp">' + erpText + '</span>');
                        $(".buyBox .price-msrp").append(priceText);
                    } else {
                        $(".price-msrp").append(priceText + '<span class="text-erp">' + erpText + '</span>');
                    }
                    $("#standalonePurch .price-msrp").html(priceText);
                } else {
                    if (euchangeArray.indexOf(urlRegion) !== -1 && nonStoreEU.indexOf(urlRegion) === -1 && noMSStorePages.indexOf(pageId) === -1) {
                        $(".purchRow1 .price-msrp, .c-in-page-navigation .price-msrp").append('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through; margin-right: 10px;"> ' + priceText + ' </span> ' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + discountedPriceText + '<span class="msText">' + microsoftText + '</span>');
                        $(".buyBox .price-msrp").append('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through; margin-right: 10px;"> ' + priceText + ' </span> ' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + discountedPriceText);
                    } else {
                        $(".price-msrp").append('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through; margin-right: 10px;"> ' + priceText + '<span class="text-erp">' + erpText + '</span>' + ' </span> ' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + discountedPriceText);
                    }
                    if (nonStoreEU.indexOf(urlRegion) !== -1) {
                        $("#prices").text(keyLimitedTimeCopy);
                    }
                }
            } else if (priceText && priceText.indexOf("####") !== -1) {
                $(".text-erp").hide();
            }
  
            if (nonStore === false) {
                $(".price-msrp .text-erp").hide();
                $(".msText").hide();
            }

            if ($(".price-msrp").text() === "####" || $(".price-msrp").text() === "") {
                $(".price-msrp").hide();
            }

            // $(".addToCartBtn").attr("data-clickname", $(".addToCartBtn").attr("data-clickname").replace("ACCESSORYNAME", currentProduct.id));
  
  
            // if (useupdated !== undefined) {
            //     if (useupdated.toString().toLowerCase() === "preorder") {
            //         var potext = priceFormat.locales[urlRegion].keyPreorder;
            //         $(".addToCartBtn").attr("aria-label", addToCartAria.replace("Add", potext));
  
            //     } else {
            //         $(".addToCartBtn").attr("aria-label", addToCartAria);
            //     }
            // }
  
  
            var populate = function() {
                if (bid.split("/")[1] !== undefined) {
                    var sid = bid.split("/")[1];
                } else {
                    if (apiData.Products[0]) {
                        var sid = apiData.Products[0].DisplaySkuAvailabilities[0].Sku.SkuId;
                    } else {
                        outOfStock();
                        return false;
                    }
                }
  
                if (apiData.Products[0]) {
                    for (var t = 0; t < apiData.Products[0].DisplaySkuAvailabilities.length; t++) {
                        if (apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].SkuId === sid) {
                            var availId = apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].AvailabilityId;
                            var ispreorder = apiData.Products[0].DisplaySkuAvailabilities[t].Sku.Properties.IsPreOrder;
                            if (ispreorder.toString().toLowerCase() === "true") {
                                buttonPreorder();
                            }
                            
                            if (apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].Properties.PreOrderReleaseDate) {
                                //moved buytext availabledate from here
  
                                var releasedateraw = apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].Properties.PreOrderReleaseDate;
                                date(releasedateraw);
                            } else {
                                hideDate();
                            }
  
  
                        }
                    }
                } else {
                    outOfStock();
                    return false;
                }
  
                
                var cartURL = "https://www.microsoft.com/" + urlRegion + "/store/buy?pid=" + prodIdBig + "&sid=" + sid;
                var interstitial = "" /*priceFormat.locales[urlRegion].keyInterstitial;    Add this back in if it is requested*/ ;
                if (interstitial !== "") {
                    cartURL = cartURL + "&aid=" + availId + "&cid=" + interstitial;
                }
                if (specIdBig.length > 11 && specIdBig !== undefined) {
                    cartURL = "https://www.microsoft.com/" + urlRegion + "/store/build/" + "xbox-one-s-bundle" + "/" + specIdBig;
                }
                if (customATC !== "") {
                    cartURL = customATC;
                }
  
                // Elite Add To Cart
                //if (pageId.indexOf("elite-wireless-controller-series-2") !== -1) {
                //    cartURL = cartURL + "&crosssellid=elite2interstitial";
               // }
  
  
                $(".addToCartBtn").attr("href", cartURL);
  
                var stockUrl = "https://inv.mp.microsoft.com/v2.0/inventory/" + countryCode + "/" + prodIdBig + "/" + sid + "/" + availId;
                $.get(stockUrl)
                    .done(function(stockData) {
                        var shipTimes = Object.keys(stockData.futureLots);
                        var futureInstock = "";
                        if (shipTimes.length > 0) {
                            $.each(shipTimes, function() { // Cycles through all future lots to see if in stock.
                                futureInstock = stockData.futureLots[this]["9000000013"].inStock;
                                if (futureInstock.toLowerCase() === "true") {
                                    false; // This breaks out of the foreach loop
                                }
                            });
                        }
                        var instock = stockData.availableLots["0001-01-01T00:00:00.0000000Z"]["9000000013"].inStock;
                        //console.log("instock= " + instock);
                        //console.log("future instock= " + futureInstock.toString());
                        $(".addToCartBtn").removeClass("hiddenImp");
                        //console.log("ispreorder= " + ispreorder)
  
                        let retailerText = lmCopy.locales[urlRegion].keyRetailerText;
                        let wtbURL = "https://www.xbox.com/" + urlRegion + "/where-to-buy";
  
                        //MAY NEED TO UPDATE THIS CODE THE NEXT TIME THERE IS  A PRE-ORDER CONSOLE BUNDLE
                        if ((instock.toLowerCase() !== "true" /*&& ispreorder.toString().toLowerCase() !== "true" */ ) && (futureInstock.toString().toLowerCase() !== "true" /*&& ispreorder.toString().toLowerCase() === "true"*/ )) {
                            console.log("OOS");
                            if (microsoftStorePages.indexOf(pageId) !== -1) {
                                $(".addToCartBtn").css("background-color", "#505050").attr("tabindex", "-1").css("color", "#FFFFFF").css("pointer-events", "none").text(regionSoldout["keySoldout"].toUpperCase());
                            } else {
                                $(".retailerBlade .addToCartBtn").text(retailerText).attr("href", wtbURL).attr("aria-label", "").removeAttr("target");
                                $("#standalonePurch .addToCartBtn").text(retailerText).attr("href", wtbURL).attr("aria-label", "").removeAttr("target");
                                $(".m-in-page-navigation .addToCartBtn").text(retailerText).attr("href", wtbURL).attr("aria-label", "").removeAttr("target");

                                // Switching to ERP Pricing + Retailer Text 
                                $(".price-msrp").html(erpPricing + '<span class="text-erp">' + erpText + '</span>');
                                $(".price-msrp .text-erp").show();
                            }
  
                            outOfStock();
                        }
                    })
                    .fail(function() {
                        outOfStock();
                    })
                $(".addToCartBtn").css("visibility", "visible");
            }
  
            function outOfStock() {
                if (customATC === "") {
                    // $(".addToCartBtn").addClass("hiddenImp");
                    if (hasCTA === false) {
                        $(".greenBar").remove();
                    }
                }
            }
  
            function buttonPreorder() {
                var text = priceFormat.locales[urlRegion].keyPreorder.toUpperCase();
                $(".addToCartBtn").text(text);
                $(".addToCartBtn").attr("aria-label", text + ", " + currentProduct.headline);
            }
  
            // Add to Cart Aria
            $(".addToCartBtn").attr("aria-label", addtocartText + ", " + currentProduct.headline);
  
            //If you don't send in the format from the PriceFormat JSON, you're going to have a bad time.
            function formatCurrency(price, format) {
                var formattedPrice = "" + price;
                if (!format.keyHasdecimal) {
                    formattedPrice = formattedPrice.split(".")[0];
                } else if (formattedPrice.split(".")[1] > 0) {
                    formattedPrice = formattedPrice.split(".")[0] + "." + formattedPrice.split(".")[1];
                    if (formattedPrice.split(".")[1].length < 2) {
                        formattedPrice = formattedPrice + "0"
                    }
                } else if (formattedPrice.indexOf(".99") === -1) {
                    formattedPrice = formattedPrice.split(".")[0] + ".00";
                } else {
                    formattedPrice = formattedPrice.split(".")[0] + "." + formattedPrice.split(".")[1];
                }
                if (formattedPrice.split(".")[0].length > 3) { // Needs to figure out thousands
                    if (!format.keyHasdecimal) {
                        formattedPrice = formattedPrice.substring(0, formattedPrice.length - 3) + "*" + formattedPrice.substring(formattedPrice.length - 3, formattedPrice.length);
                    } else {
                        formattedPrice = formattedPrice.substring(0, formattedPrice.length - 6) + "*" + formattedPrice.substring(formattedPrice.length - 6, formattedPrice.length);
                    }
                }
                if (format.keyThousandcharacter === ",") {
                    formattedPrice = formattedPrice.replace("*", format.keyThousandcharacter);
                } else {
                    formattedPrice = formattedPrice.replace(".", ",");
                    formattedPrice = formattedPrice.replace("*", format.keyThousandcharacter);
                }
                formattedPrice = "" + format.keyPriceformat.replace("#", formattedPrice);
  
                return formattedPrice;
            }
        }

        function date(releasedateraw) {

            if ($(".availableDate").length === 0) {
                $(".buyText").before('<h2 class="c-subheading-2 availableDate"></h2>');
            }

            releasedateraw = new Date(releasedateraw);

            // ko-KR no pacificoffset
            if (urlRegion !== "ko-kr") {
                releasedateraw.setHours(releasedateraw.getHours() + pacificoffset + usertzhours);
            } 

            var deArray = ["de-at", "de-ch", "de-de"];
            var nlArray = ["nl-be", "nl-nl"];
            let zhArray = ["zh-hk", "zh-tw"];

            // Available and date groups
            var esAvailArray = ["es-ar", "fr-be", "es-cl", "es-co", "es-es", "fr-fr", "es-mx", "fr-ch"];
            var engDMAvailArray = ["en-ie", "he-il", "en-nz", "ar-sa", "en-za", "ar-ae", "en-gb"];
            var singAvailArray = ["en-hk", "en-in", "en-sg"];

            if (esAvailArray.indexOf(urlRegion) > -1) {
                availConvert("Disponible ", "daymonth");
            } else if (engDMAvailArray.indexOf(urlRegion) > -1) {
                availConvert("Available ", "daymonth");
            } else if (urlRegion === "en-us" || urlRegion === "en-ca") {
                availConvert("Available ", "monthday");
            } else if (singAvailArray.indexOf(urlRegion) > -1) {
                availConvert("Available ", "daymonth");
            } else if (urlRegion === "zh-hk") {
                availConvert(" 日推出", "monthday");
            } else if (urlRegion === "fr-ca") {
                availConvert("Disponible ", "monthday");
            } else if (urlRegion === "tr-tr") {
                availConvert("Satışta ", "daymonth");
            } else if (urlRegion === "zh-tw") {
                availConvert(" 日隆重推出", "monthday");
            }

            if (deArray.indexOf(urlRegion) > -1) {
                availConvert("Ab ", "daymonth", " erhältlich");
            } else if (nlArray.indexOf(urlRegion) > -1) {
                availConvert("Verkrijgbaar op ", "daymonth");
            } else if (urlRegion === "ko-kr") {
                availConvert("일 구매 가능", "monthday");
            } else if (urlRegion === "cs-cz") {
                availConvert("Dostupné ", "daymonth");
            } else if (urlRegion === "da-dk") {
                availConvert("Tilgængelig ", "daymonth");
            } else if (urlRegion === "el-gr") {
                availConvert("Διαθέσιμα ", "daymonth");
            } else if (urlRegion === "fi-fi") {
                availConvert("Saatavilla ", "daymonth");
            } else if (urlRegion === "hu-hu") {
                availConvert("Elérhető ", "daymonth");
            } else if (urlRegion === "it-it") {
                availConvert("Disponibile dal ", "daymonth");
            } else if (urlRegion === "nb-no") {
                availConvert("Tilgjengelig ", "daymonth");
            } else if (urlRegion === "pl-pl") {
                availConvert("W sprzedaży od ", "daymonth", " r.");
            } else if (urlRegion === "pt-pt") {
                availConvert("Disponível a ", "daymonth");
            } else if (urlRegion === "ru-ru") {
                availConvert("В продаже ", "daymonth");
            } else if (urlRegion === "sk-sk") {
                availConvert("K dispozícii ", "daymonth");
            } else if (urlRegion === "sv-se") {
                availConvert("Tillgänglig ", "daymonth");
            } else if (urlRegion === "ja-jp") {
                availConvert("発売日 ", "ja");
            } else if (urlRegion === "pt-br") {
                availConvert("Disponível ", "daymonth");
            }

            function availConvert(word, monthday, postWord) {
                if (!postWord) { postWord = ""; } //Check if postWord is undefined
                let slashdate  = releasedateraw.toLocaleDateString(urlRegion, monthday);
                if (zhArray.indexOf(urlRegion) !== -1) {
                    
                    const year = slashdate.split("/")[0];
                    const month = slashdate.split("/")[1];
                    const day = slashdate.split("/")[2];
                    slashdate = `${year} 年 ${month} 月 ${day}`

                    $(".availableDate").text(slashdate + word);

                } else if (urlRegion === "ko-kr") {
                    const year = slashdate.split(".")[0];
                    const month = slashdate.split(".")[1];
                    const day = slashdate.split(".")[2];

                    slashdate = `${year}년 ${month}월 ${day}`

                    $(".availableDate").text(slashdate + word);
                } else {
                    $(".availableDate").text(word + slashdate + postWord);
                }
                var nowDate = new Date();
                if (releasedateraw < nowDate) {
                    hideDate();
                }

            }
        }

        function hideDate(alternateText) {
            $(".availableDate").remove();
        }          

})();
 
});

var priceFormat = {
    "locales": {
        "en-us": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "$#","keyHasdecimal": true,"keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": " MSRP","keyAvailablenow": "Available Now","keyInterstitial": "XboxOneInterstitial","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "ar-ae": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "AED #","keyHasdecimal": "FALSE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "ar-sa": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "SR.#","keyHasdecimal": "FALSE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "cs-cz": {
            "keyPreorder": "Předobjednat","keyAddtocart": "PŘIDAT DO KOŠÍKU","keyPriceformat": "# Kč","keyHasdecimal": "TRUE","keyThousandcharacter": " ","keyMsrpbefore": "Doporučená maloobchodní cena ","keyMsrpafter": "","keyAvailablenow": "Ihned k dispozici","keyInterstitial": "X1SGenericInterstitial","keyJumpdown": "Chcete-li se dozvědět více o cenách, přejděte do části právní upozornění.","keyErptext": " OMC*","keyPriceAria": "**, Přejděte na přečtení prohlášení o vyloučení odpovědnosti ohledně cen","keyLimitedTimeCopy": "**Časově omezená nabídka u vybraných prodejců. Ceny se mohou lišit.","keyRecurrenceCopy": "Prodáno za PLACEHOLDER v posledních 30 dnech"
        },
        "da-dk": {
            "keyPreorder": "Forudbestil","keyAddtocart": "FØJ TIL KURV","keyPriceformat": "# kr","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " (vejl. udsalgspris)","keyAvailablenow": "Kan fås nu","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Gå til juridisk ansvarsfraskrivelse for at få mere at vide om priser","keyErptext": " ERP*","keyPriceAria": "**, Gå hen for læse ansvarsfraskrivelsen om priser","keyLimitedTimeCopy": "**Andre tidsbegrænsede tilbud er tilgængelige hos deltagende forhandlere. Priserne kan variere.","keyRecurrenceCopy": "Solgt til PLACEHOLDER inden for de sidste 30 dage"
        },
        "de-at": {
            "keyPreorder": "Vorbestellen","keyAddtocart": "IN DEN EINKAUFSWAGEN","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "Geschätzter Verkaufspreis: ","keyMsrpafter": "","keyAvailablenow": "Jetzt erhältlich.","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Über den Haftungsausschluss weiter unten sind weitere Informationen zur Preisgestaltung erhältlich","keyErptext": " Geschätzter Ladenpreis*","keyPriceAria": "**, Navigieren, um den Haftungsausschluss für Preise zu lesen","keyLimitedTimeCopy": "**Zeitlich begrenztes Angebot, bei teilnehmenden Händlern. Preise können variieren.","keyRecurrenceCopy": "Der niedrigste Preis der letzten 30 Tage war PLACEHOLDER"
        },
        "de-ch": {
            "keyPreorder": "Vorbestellen","keyAddtocart": "IN DEN EINKAUFSWAGEN","keyPriceformat": "CHF #","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "Geschätzter Verkaufspreis: ","keyMsrpafter": "","keyAvailablenow": "Jetzt erhältlich.","keyInterstitial": "x1sgenericinterstitial","keyJumpdown": "Über den Haftungsausschluss weiter unten sind weitere Informationen zur Preisgestaltung erhältlich","keyErptext": " Geschätzter Ladenpreis*","keyPriceAria": "**, Navigieren, um den Haftungsausschluss für Preise zu lesen","keyLimitedTimeCopy": "**Zeitlich begrenztes Angebot, bei teilnehmenden Händlern. Preise können variieren.","keyRecurrenceCopy": "In den letzten 30 Tagen für PLACEHOLDER verkauft"
        },
        "de-de": {
            "keyPreorder": "Vorbestellen","keyAddtocart": "IN DEN EINKAUFSWAGEN","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "Geschätzter Verkaufspreis: ","keyMsrpafter": "","keyAvailablenow": "Jetzt erhältlich.","keyInterstitial": "X1XInterstitial","keyJumpdown": "Über den Haftungsausschluss weiter unten sind weitere Informationen zur Preisgestaltung erhältlich","keyErptext": " Geschätzter Ladenpreis*","keyPriceAria": "**, Navigieren, um den Haftungsausschluss für Preise zu lesen","keyLimitedTimeCopy": "**Zeitlich begrenztes Angebot, bei teilnehmenden Händlern. Preise können variieren.","keyRecurrenceCopy": "Der niedrigste Preis der letzten 30 Tage war PLACEHOLDER"
        },
        "el-gr": {
            "keyPreorder": "Προπαραγγελία","keyAddtocart": "ΠΡΟΣΘΗΚΗ ΣΤΟ ΚΑΡΟΤΣΙ","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Διαθέσιμο τώρα","keyInterstitial": "","keyJumpdown": "Μεταβείτε στη νομική αποποίηση ευθυνών για να μάθετε περισσότερα σχετικά με την τιμολόγηση","keyErptext": " ERP*","keyPriceAria": "**, Πλοηγηθείτε για να διαβάσετε την αποποίηση ευθυνών σχετικά με τις τιμές","keyLimitedTimeCopy": "**Προσφορά περιορισμένης χρονικής διάρκειας σε καταστήματα λιανικής που συμμετέχουν στο πρόγραμμα. Οι τιμές ενδέχεται να διαφέρουν.","keyRecurrenceCopy": "Πωλήσεις για PLACEHOLDER τις τελευταίες 30 ημέρες"
        },
        "en-au": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "$# ","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "RRP: ","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "Xboxoneconsoles500gbinterstitial","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "en-ca": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "$#","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": " MSRP","keyAvailablenow": "Available Now","keyInterstitial": "xboxoneconsolenonrefurbinterstitial","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "en-gb": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "£#","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": " MSRP","keyAvailablenow": "Available Now","keyInterstitial": "X1GenericInterstitial","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "en-hk": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "HK$#","keyHasdecimal": "FALSE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "en-ie": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "€ #","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": " MSRP","keyAvailablenow": "Available Now","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "en-in": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "₹ #","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "en-nz": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "$# ","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "RRP: ","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "Xboxoneconsoles500gbinterstitial","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "en-sg": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "SG$#","keyHasdecimal": "FALSE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "XboxInterstitial","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "en-za": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "es-ar": {
            "keyPreorder": "Reservar","keyAddtocart": "AGREGAR AL CARRO","keyPriceformat": "","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Disponible ahora","keyInterstitial": "","keyJumpdown": "Ve al aviso de declinación de responsabilidades para obtener más información sobre los precios","keyErptext": " PVP*","keyPriceAria": "**, Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "**Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden cambiar.","keyRecurrenceCopy": "Vendido por PLACEHOLDER en los últimos 30 días"
        },
        "es-cl": {
            "keyPreorder": "Reservar","keyAddtocart": "AGREGAR AL CARRO","keyPriceformat": "$#","keyHasdecimal": false,"keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Disponible ahora","keyInterstitial": "","keyJumpdown": "Ve al aviso de declinación de responsabilidades para obtener más información sobre los precios","keyErptext": " PVP*","keyPriceAria": "**, Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "**Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden cambiar.","keyRecurrenceCopy": "Vendido por PLACEHOLDER en los últimos 30 días"
        },
        "es-co": {
            "keyPreorder": "Reservar","keyAddtocart": "AGREGAR AL CARRO","keyPriceformat": "$#","keyHasdecimal": false,"keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Disponible ahora","keyInterstitial": "","keyJumpdown": "Ve al aviso de declinación de responsabilidades para obtener más información sobre los precios","keyErptext": " PVP*","keyPriceAria": "**, Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "**Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden cambiar.","keyRecurrenceCopy": "Vendido por PLACEHOLDER en los últimos 30 días"
        },
        "es-es": {
            "keyPreorder": "Reservar","keyAddtocart": "AGREGAR A LA CESTA","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "PVPr: ","keyMsrpafter": "","keyAvailablenow": "Ya disponible","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Accede al aviso de declinación de responsabilidades para obtener más información sobre los precios","keyErptext": " PVP*","keyPriceAria": "**, Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "**Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden variar.","keyRecurrenceCopy": "Precio más bajo últimos 30 días: PLACEHOLDER"
        },
        "es-mx": {
            "keyPreorder": "Reservar","keyAddtocart": "AGREGAR AL CARRO","keyPriceformat": "$#","keyHasdecimal": false,"keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": " Precio de lista","keyAvailablenow": "Disponible ahora","keyInterstitial": "","keyJumpdown": "Ve al aviso de declinación de responsabilidades para obtener más información sobre los precios","keyErptext": " PVP*","keyPriceAria": "**, Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "**Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden cambiar.","keyRecurrenceCopy": "Vendido por PLACEHOLDER en los últimos 30 días"
        },
        "fi-fi": {
            "keyPreorder": "Tilaa ennakkoon","keyAddtocart": "LISÄÄ OSTOSKÄRRYYN","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " (valmistajan OVH)","keyAvailablenow": "Nyt saatavilla","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Siirry lakisääteiseen vastuuvapauslausekkeeseen saadaksesi lisätietoja hinnoittelusta","keyErptext": " ERP*","keyPriceAria": "**, Siirry lukemaan hintoja koskeva vastuuvapauslauseke","keyLimitedTimeCopy": "**Tarjous voimassa rajoitetun ajan tietyillä jälleenmyyjillä. Hinnat voivat vaihdella.","keyRecurrenceCopy": "Myyty PLACEHOLDER:lla viimeisen 30 päivän aikana"
        },
        "fr-be": {
            "keyPreorder": "Précommander","keyAddtocart": "AJOUTER AU PANIER","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " PDSF","keyAvailablenow": "Déjà disponible","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Accédez à l'avis de non-responsabilité pour en savoir plus sur les prix","keyErptext": " Prix de revente estimé*","keyPriceAria": "**, Naviguez pour lire la clause de non-responsabilité concernant les prix","keyLimitedTimeCopy": "**Offre à durée limitée dans les points de vente participants. Les prix peuvent varier.","keyRecurrenceCopy": "Prix le plus bas pratiqué au cours des 30 derniers jours : PLACEHOLDER"
        },
        "fr-ca": {
            "keyPreorder": "Précommander","keyAddtocart": "AJOUTER AU PANIER","keyPriceformat": "# $","keyHasdecimal": "TRUE","keyThousandcharacter": " ","keyMsrpbefore": "Prix de détail suggéré : ","keyMsrpafter": "","keyAvailablenow": "Maintenant offert","keyInterstitial": "xboxoneconsolenonrefurbinterstitial ","keyJumpdown": "Accédez aux mentions légales pour en savoir plus sur la tarification","keyErptext": " PDE*","keyPriceAria": "**, Naviguer pour lire l’avis de non-responsabilité relatif aux prix","keyLimitedTimeCopy": "**Offre d’une durée limitée chez les détaillants participants. Les prix peuvent varier.","keyRecurrenceCopy": "Vendu pour PLACEHOLDER au cours des 30 derniers jours"
        },
        "fr-fr": {
            "keyPreorder": "Précommander","keyAddtocart": "AJOUTER AU PANIER","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " PDSF","keyAvailablenow": "Déjà disponible","keyInterstitial": "X1SGenericInterstitial","keyJumpdown": "Accédez à l'avis de non-responsabilité pour en savoir plus sur les prix","keyErptext": " Prix de revente estimé*","keyPriceAria": "**, Naviguez pour lire la clause de non-responsabilité concernant les prix","keyLimitedTimeCopy": "**Offre à durée limitée dans les points de vente participants. Les prix peuvent varier.","keyRecurrenceCopy": "Prix le plus bas pratiqué au cours des 30 derniers jours : PLACEHOLDER"
        },
        "fr-ch": {
            "keyPreorder": "Précommander","keyAddtocart": "AJOUTER AU PANIER","keyPriceformat": "CHF #","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": " PDSF","keyAvailablenow": "Déjà disponible","keyInterstitial": "x1sgenericinterstitial","keyJumpdown": "Accédez à l'avis de non-responsabilité pour en savoir plus sur les prix","keyErptext": " Prix de revente estimé*","keyPriceAria": "**, Naviguez pour lire la clause de non-responsabilité concernant les prix","keyLimitedTimeCopy": "**Offre à durée limitée dans les points de vente participants. Les prix peuvent varier.","keyRecurrenceCopy": "Vendu pour PLACEHOLDER au cours des 30 derniers jours"
        },
        "he-il": {
            "keyPreorder": "Pre-order","keyAddtocart": "ADD TO CART","keyPriceformat": "# NIS","keyHasdecimal": "FALSE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Available Now","keyInterstitial": "","keyJumpdown": "Jump down to the legal disclaimer to learn more about pricing","keyErptext": " ERP*","keyPriceAria": "**, Navigate to read disclaimer about prices","keyLimitedTimeCopy": "**Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days"
        },
        "hu-hu": {
            "keyPreorder": "Előrendelés","keyAddtocart": "KOSÁRBA","keyPriceformat": "# HUF","keyHasdecimal": "FALSE","keyThousandcharacter": "","keyMsrpbefore": "Listaár: ","keyMsrpafter": "","keyAvailablenow": "Már megjelent","keyInterstitial": "","keyJumpdown": "Ugrás a jogi nyilatkozatra, hogy többet megtudj az árakról","keyErptext": " Becsült fogyasztói ár*","keyPriceAria": "**, Navigálj az árakkal kapcsolatos jogi nyilatkozat elolvasásához","keyLimitedTimeCopy": "**Korlátozott ideig rendelkezésre álló akció a részt vevő viszonteladóknál. Az árak változhatnak.","keyRecurrenceCopy": "Eladva PLACEHOLDER részére az elmúlt 30 napban"
        },
        "it-it": {
            "keyPreorder": "Preordina","keyAddtocart": "AGGIUNGI AL CARRELLO","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " Prezzo al dettaglio stimato dal produttore","keyAvailablenow": "Disponibile","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Passa alle note legali qui sotto per ulteriori informazioni sui prezzi","keyErptext": " Prezzo stimato*","keyPriceAria": "**, Passa alle note legali relative ai prezzi","keyLimitedTimeCopy": "**Offerta limitata nel tempo presso i rivenditori partecipanti. I prezzi possono variare.","keyRecurrenceCopy": "Prezzo più basso degli ultimi 30 giorni: PLACEHOLDER"
        },
        "ja-jp": {
            "keyPreorder": "予約","keyAddtocart": "カートに追加する","keyPriceformat": "# 円","keyHasdecimal": false,"keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": " (税込)","keyAvailablenow": "発売中","keyInterstitial": "","keyJumpdown": "免責事項に移動して価格設定の詳細をご覧ください","keyErptext": " 推定小売価格*","keyPriceAria": "**, 移動して価格に関する免責事項を読む","keyLimitedTimeCopy": "**特定の販売店にて期間限定で提供しています 実際の販売価格は販売店により決定されます。","keyRecurrenceCopy": ""
        },
        "ko-kr": {
            "keyPreorder": "미리 주문하기","keyAddtocart": "카트에 추가","keyPriceformat": "₩#","keyHasdecimal": false,"keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "지금 구매 가능","keyInterstitial": "","keyJumpdown": "법적 고지 사항으로 이동하여 가격에 대해 자세히 알아보십시오.","keyErptext": " 예상 소매 가격*","keyPriceAria": "**, 가격 고지 사항으로 이동하여 읽기","keyLimitedTimeCopy": "**가맹 판매점에서 기간 한정 혜택 가격은 변동될 수 있습니다.","keyRecurrenceCopy": ""
        },
        "nb-no": {
            "keyPreorder": "Forhåndsbestill","keyAddtocart": "LEGG I HANDLEKURV","keyPriceformat": "# kr","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " (anbefalt utsalgspris)","keyAvailablenow": "Tilgjengelig nå","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Hopp ned til den juridiske ansvarsfraskrivelsen for å lære mer om priser","keyErptext": " ERP*","keyPriceAria": "**, Gå til for å lese ansvarsfraskrivelse om priser","keyLimitedTimeCopy": "**Tidsbegrenset tilbud hos deltagende forhandlere. Prisene kan variere.","keyRecurrenceCopy": ""
        },
        "nl-be": {
            "keyPreorder": "Reserveer","keyAddtocart": "TOEVOEGEN AAN WINKELWAGEN","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " (aanbevolen verkoopprijs)","keyAvailablenow": "Nu beschikbaar","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Ga naar de juridische disclaimer om meer te weten te komen over de prijzen","keyErptext": " ERP*","keyPriceAria": "**, Ga naar de disclaimer over prijzen","keyLimitedTimeCopy": "**Tidsbegrenset tilbud hos deltagende forhandlere. Prisene kan variere.","keyRecurrenceCopy": "Laagste prijs in de afgelopen 30 dagen: PLACEHOLDER"
        },
        "nl-nl": {
            "keyPreorder": "Reserveer","keyAddtocart": "TOEVOEGEN AAN WINKELWAGEN","keyPriceformat": "€ #","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " (aanbevolen verkoopprijs)","keyAvailablenow": "Nu beschikbaar","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Ga naar de juridische disclaimer om meer te weten te komen over de prijzen","keyErptext": " ERP*","keyPriceAria": "**, Ga naar de disclaimer over prijzen","keyLimitedTimeCopy": "**Tidsbegrenset tilbud hos deltagende forhandlere. Prisene kan variere.","keyRecurrenceCopy": "Laagste prijs in de afgelopen 30 dagen: PLACEHOLDER"
        },
        "pl-pl": {
            "keyPreorder": "Zamów w przedsprzedaży","keyAddtocart": "DODAJ DO KOSZYKA","keyPriceformat": "# zł","keyHasdecimal": "TRUE","keyThousandcharacter": " ","keyMsrpbefore": "","keyMsrpafter": " MSRP","keyAvailablenow": "Dostępny już teraz","keyInterstitial": "X1SGenericInterstitial","keyJumpdown": "Przejdź w dół i przeczytaj zastrzeżenia prawne, aby dowiedzieć się więcej na temat cen","keyErptext": " ERP*","keyPriceAria": "**, Przejdź, aby przeczytać zastrzeżenie dotyczące cennika","keyLimitedTimeCopy": "**Oferta ograniczona czasowo dostępna u uczestniczących w programie sprzedawców. Ceny mogą się różnić.","keyRecurrenceCopy": "Sprzedawano w cenie PLACEHOLDER w ciągu ostatnich 30 dni"
        },
        "pt-br": {
            "keyPreorder": "Pré-venda","keyAddtocart": "","keyPriceformat": "R$ #","keyHasdecimal": false,"keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Disponível agora","keyInterstitial": "","keyJumpdown": "Acesse a isenção de responsabilidade jurídica para saber mais sobre os preços","keyErptext": " ERP*","keyPriceAria": "**, Navegue para ler o aviso de isenção de responsabilidade dos preços","keyLimitedTimeCopy": "**Oferta de tempo limitado nas lojas participantes. Os preços podem variar.","keyRecurrenceCopy": "Vendido para PLACEHOLDER nos últimos 30 dias"
        },
        "pt-pt": {
            "keyPreorder": "Pré-encomendar","keyAddtocart": "ADICIONAR AO CARRINHO","keyPriceformat": "#€","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " PRVP","keyAvailablenow": "Já Disponível","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Aceder à exclusão de responsabilidades legais para obter mais informações sobre preços","keyErptext": " ERP*","keyPriceAria": "**, Navega para leres a exclusão de responsabilidade sobre os preços","keyLimitedTimeCopy": "**Oferta de duração limitada nos revendedores participantes. Os preços podem variar","keyRecurrenceCopy": "Vendido para PLACEHOLDER nos últimos 30 dias"
        },
        "ru-ru": {
            "keyPreorder": "Предзаказ","keyAddtocart": "","keyPriceformat": "# ₽","keyHasdecimal": "FALSE","keyThousandcharacter": "","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Уже в продаже","keyInterstitial": "","keyJumpdown": "Перейти к заявлению об отказе от ответственности, чтобы узнать больше о ценообразовании","keyErptext": " ERP*","keyPriceAria": "**, Перейдите, чтобы прочитать заявление об отказе от ответственности в отношении цен","keyLimitedTimeCopy": "**Предложение действует ограниченное время и доступно через участвующих в акции розничных продавцов. Цены могут отличаться.","keyRecurrenceCopy": ""
        },
        "sk-sk": {
            "keyPreorder": "Rezervovať","keyAddtocart": "","keyPriceformat": "# €","keyHasdecimal": "TRUE","keyThousandcharacter": ".","keyMsrpbefore": "","keyMsrpafter": " (odporúčaná maloobchodná cena výrobcu)","keyAvailablenow": "Teraz k dispozícii","keyInterstitial": "","keyJumpdown": "Ak sa chcete dozvedieť viac o cenách, prejdite dole na právne vyhlásenie","keyErptext": " OMC*","keyPriceAria": "**, Prejdite na vyhlásenie o cenách a prečítajte si ho","keyLimitedTimeCopy": "**U participujúcich maloobchodníkov môže byť k dispozícii ďalšia časovo obmedzená ponuka. Ceny sa môžu líšiť.","keyRecurrenceCopy": "Predané za PLACEHOLDER za posledných 30 dní"
        },
        "sv-se": {
            "keyPreorder": "Förbeställ","keyAddtocart": "LÄGG TILL I KUNDVAGN","keyPriceformat": "# kr","keyHasdecimal": "TRUE","keyThousandcharacter": "","keyMsrpbefore": "Rek. pris ","keyMsrpafter": "","keyAvailablenow": "Finns nu","keyInterstitial": "XboxOneSInterstitial","keyJumpdown": "Gå till ansvarsfriskrivningen för att läsa mer om prissättning","keyErptext": " rek-pris*","keyPriceAria": "**, Navigera för att läsa ansvarsfriskrivning om priser","keyLimitedTimeCopy": "**Begränsat erbjudande hos deltagande återförsäljare. Priserna kan variera.","keyRecurrenceCopy": "Sålts för PLACEHOLDER under de senaste 30 dagarna"
        },
        "tr-tr": {
            "keyPreorder": "Ön sipariş verin","keyAddtocart": "","keyPriceformat": "","keyHasdecimal": "TRUE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "Şimdi Satışta","keyInterstitial": "","keyJumpdown": "Fiyatlandırma hakkında daha fazla bilgi edinmek için yasal uyarı bölümüne gidin","keyErptext": " ERP*","keyPriceAria": "**, Fiyatlar hakkındaki yasal uyarıyı okumak için gidin","keyLimitedTimeCopy": "**Sınırlı süreli teklif, katılan satıcılarda geçerlidir. Fiyatlar değişiklik gösterebilir.","keyRecurrenceCopy": ""
        },
        "zh-cn": {
            "keyPreorder": "预订","keyAddtocart": "","keyPriceformat": "undefined","keyHasdecimal": "undefined","keyThousandcharacter": "undefined","keyMsrpbefore": "undefined","keyMsrpafter": "undefined","keyAvailablenow": "","keyInterstitial": "","keyJumpdown": "向下跳到法律免責聲明，以深入了解定價","keyErptext": " ERP*","keyPriceAria": "**, 瀏覽以閱讀關於價格的免責聲明","keyLimitedTimeCopy": "**限時優惠由合作零售商發售。價格或有差異。","keyRecurrenceCopy": ""
        },
        "zh-hk": {
            "keyPreorder": "預先訂購","keyAddtocart": "","keyPriceformat": "HK$#","keyHasdecimal": "FALSE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "現已推出","keyInterstitial": "","keyJumpdown": "向下跳到法律免責聲明，以深入了解定價","keyErptext": " ERP*","keyPriceAria": "**, 瀏覽以閱讀關於價格的免責聲明","keyLimitedTimeCopy": "**限時優惠由合作零售商發售。價格或有差異。","keyRecurrenceCopy": ""
        },
        "zh-tw": {
            "keyPreorder": "預購","keyAddtocart": "","keyPriceformat": "NT$#","keyHasdecimal": "FALSE","keyThousandcharacter": ",","keyMsrpbefore": "","keyMsrpafter": "","keyAvailablenow": "現已推出","keyInterstitial": "","keyJumpdown": "向下跳至法律免責聲明，以深入了解定價","keyErptext": " ERP*","keyPriceAria": "**, 瀏覽以閱讀有關價格的免責聲明","keyLimitedTimeCopy": "**限時優惠只在參與的零售商提供。售價可能不同。","keyRecurrenceCopy": ""
        }
    }
}

var globalSoldout = {
    "locales": {
        "en-us": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "ar-ae": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "ar-sa": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "cs-cz": {
            "keySoldout": " Vyprodáno","keyComingsoon": "Již brzy k předobjednání"
        },
        "da-dk": {
            "keySoldout": "Udsolgt","keyComingsoon": "Kommer snart"
        },
        "de-at": {
            "keySoldout": " Ausverkauft","keyComingsoon": "Demnächst verfügbar"
        },
        "de-ch": {
            "keySoldout": " Ausverkauft","keyComingsoon": "Demnächst verfügbar"
        },
        "de-de": {
            "keySoldout": " Ausverkauft","keyComingsoon": "Demnächst verfügbar"
        },
        "el-gr": {
            "keySoldout": " Έχει εξαντληθεί","keyComingsoon": "Προσεχώς προπαραγγελίες"
        },
        "en-au": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "en-ca": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "en-gb": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "en-hk": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "en-ie": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "en-in": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "en-nz": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "en-sg": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "en-za": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "es-ar": {
            "keySoldout": "Agotado","keyComingsoon": "Reservas disponibles próximamente"
        },
        "es-cl": {
            "keySoldout": "Agotado","keyComingsoon": "Reservas disponibles próximamente"
        },
        "es-co": {
            "keySoldout": "Agotado","keyComingsoon": "Reservas disponibles próximamente"
        },
        "es-es": {
            "keySoldout": " Agotado","keyComingsoon": "Próximamente"
        },
        "es-mx": {
            "keySoldout": "Agotado","keyComingsoon": "Reservas disponibles próximamente"
        },
        "fi-fi": {
            "keySoldout": " Loppuunmyyty","keyComingsoon": "Tulossa pian"
        },
        "fr-be": {
            "keySoldout": "Épuisé","keyComingsoon": "Bientôt en précommande"
        },
        "fr-ca": {
            "keySoldout": "En rupture de stock","keyComingsoon": "Précommande bientôt offerte"
        },
        "fr-ch": {
            "keySoldout": " Épuisé","keyComingsoon": "Bientôt en précommande"
        },
        "fr-fr": {
            "keySoldout": " Épuisé","keyComingsoon": "Bientôt en précommande"
        },
        "he-il": {
            "keySoldout": "Sold Out","keyComingsoon": "Pre-order coming soon"
        },
        "hu-hu": {
            "keySoldout": "Elfogyott","keyComingsoon": "Hamarosan előrendelhető"
        },
        "it-it": {
            "keySoldout": "Esaurito","keyComingsoon": "Disponibile a breve",
        },
        "ja-jp": {
            "keySoldout": " 完売","keyComingsoon": "間もなく予約開始"
        },
        "ko-kr": {
            "keySoldout": "품절","keyComingsoon": "사전 주문이 곧 시작됩니다."
        },
        "nb-no": {
            "keySoldout": "Utsolgt","keyComingsoon": "Kommer snart"
        },
        "nl-be": {
            "keySoldout": "Uitverkocht","keyComingsoon": "Binnenkort beschikbaar"
        },
        "nl-nl": {
            "keySoldout": "Uitverkocht","keyComingsoon": "Binnenkort beschikbaar"
        },
        "pl-pl": {
            "keySoldout": " Wyprzedane","keyComingsoon": "Wkrótce w sprzedaży"
        },
        "pt-br": {
            "keySoldout": "Esgotado","keyComingsoon": "Pré-venda em breve"
        },
        "pt-pt": {
            "keySoldout": "Esgotado","keyComingsoon": "Brevemente disponível"
        },
        "ru-ru": {
            "keySoldout": " Распродано","keyComingsoon": "Скоро в продаже"
        },
        "sk-sk": {
            "keySoldout": " Vypredané","keyComingsoon": "Pripravujeme"
        },
        "sv-se": {
            "keySoldout": " Utsåld","keyComingsoon": "Kan snart förbeställas"
        },
        "tr-tr": {
            "keySoldout": " Tükendi","keyComingsoon": "Çok yakında"
        },
        "zh-hk": {
            "keySoldout": "售罄","keyComingsoon": "即將推出預購"
        },
        "zh-tw": {
            "keySoldout": "售罄","keyComingsoon": "即將推出預購"
        }
    }
}
  
var lmCopy = {
    "locales": {
        "en-us": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "ar-ae": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "ar-sa": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "cs-cz": {"keyLearnmore": "DALŠÍ INFORMACE","keyCheckAvail": "ZKONTROLOVAT DOSTUPNOST","keyRetailerText": "NAJDĚTE PRODEJCE"},
        "da-dk": {"keyLearnmore": "FÅ MERE AT VIDE","keyCheckAvail": "SE TILGÆNGELIGHED","keyRetailerText": "FIND EN FORHANDLER"},
        "de-at": {"keyLearnmore": "MEHR ERFAHREN","keyCheckAvail": "VERFÜGBARKEIT PRÜFEN","keyRetailerText": "HÄNDLER FINDEN"},
        "de-ch": {"keyLearnmore": "MEHR ERFAHREN","keyCheckAvail": "VERFÜGBARKEIT PRÜFEN","keyRetailerText": "HÄNDLER FINDEN"},
        "de-de": {"keyLearnmore": "MEHR ERFAHREN","keyCheckAvail": "VERFÜGBARKEIT PRÜFEN","keyRetailerText": "HÄNDLER FINDEN"},
        "el-gr": {"keyLearnmore": "ΜΑΘΕΤΕ ΠΕΡΙΣΣΟΤΕΡΑ","keyCheckAvail": "ΕΛΕΓΧΟΣ ΔΙΑΘΕΣΙΜΟΤΗΤΑΣ","keyRetailerText": "ΕΠΙΛΕΞΤΕ ΚΑΤΑΣΤΗΜΑ ΛΙΑΝΙΚΗΣ"},
        "en-au": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-ca": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-gb": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-hk": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-ie": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-in": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-nz": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-sg": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-za": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "es-ar": {"keyLearnmore": "MÁS INFORMACIÓN","keyCheckAvail": "COMPROBAR DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "es-cl": {"keyLearnmore": "MÁS INFORMACIÓN","keyCheckAvail": "COMPROBAR DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "es-co": {"keyLearnmore": "MÁS INFORMACIÓN","keyCheckAvail": "COMPROBAR DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "es-es": {"keyLearnmore": "DESCUBRE MÁS","keyCheckAvail": "COMPROBAR LA DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "es-mx": {"keyLearnmore": "MÁS INFORMACIÓN","keyCheckAvail": "COMPROBAR DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "fi-fi": {"keyLearnmore": "LUE LISÄÄ","keyCheckAvail": "TARKISTA SAATAVUUS","keyRetailerText": "ETSI JÄLLEENMYYJÄ"},
        "fr-be": {"keyLearnmore": "EN SAVOIR PLUS","keyCheckAvail": "VOIR LES DISPONIBILITÉS","keyRetailerText": "TROUVER UN DISTRIBUTEUR"},
        "fr-ca": {"keyLearnmore": "EN SAVOIR PLUS","keyCheckAvail": "VÉRIFIER LA DISPONIBILITÉ","keyRetailerText": "TROUVER UN DÉTAILLANT"},
        "fr-ch": {"keyLearnmore": "EN SAVOIR PLUS","keyCheckAvail": "VOIR LES DISPONIBILITÉS","keyRetailerText": "TROUVER UN DISTRIBUTEUR"},
        "fr-fr": {"keyLearnmore": "EN SAVOIR PLUS","keyCheckAvail": "VOIR LES DISPONIBILITÉS","keyRetailerText": "TROUVER UN DISTRIBUTEUR"},
        "he-il": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "hu-hu": {"keyLearnmore": "TOVÁBBI INFORMÁCIÓ","keyCheckAvail": "AZ ELÉRHETŐSÉG ELLENŐRZÉSE","keyRetailerText": "VISZONTELADÓ KERESÉSE"},
        "it-it": {"keyLearnmore": "SCOPRI DI PIÙ","keyCheckAvail": "VERIFICA LA DISPONIBILITÀ","keyRetailerText": "TROVA UN RIVENDITORE"},
        "ja-jp": {"keyLearnmore": "詳細について","keyCheckAvail": "利用可能か確認する","keyRetailerText": "販売店を見つける"},
        "ko-kr": {"keyLearnmore": "자세한 정보","keyCheckAvail": "플레이 가능성 확인","keyRetailerText": "매장 찾기"},
        "nb-no": {"keyLearnmore": "FINN UT MER","keyCheckAvail": "SJEKK TILGJENGELIGHET","keyRetailerText": "FINN EN FORHANDLER"},
        "nl-be": {"keyLearnmore": "MEER INFO","keyCheckAvail": "BESCHIKBAARHEID CONTROLEREN","keyRetailerText": "ZOEK EEN VERKOPER"},
        "nl-nl": {"keyLearnmore": "MEER INFO","keyCheckAvail": "BESCHIKBAARHEID CONTROLEREN","keyRetailerText": "ZOEK EEN VERKOPER"},
        "pl-pl": {"keyLearnmore": "DOWIEDZ SIĘ WIĘCEJ","keyCheckAvail": "SPRAWDŹ DOSTĘPNOŚĆ","keyRetailerText": "ZNAJDŹ SPRZEDAWCĘ"},
        "pt-br": {"keyLearnmore": "SAIBA MAIS","keyCheckAvail": "VERIFICAR DISPONIBILIDADE","keyRetailerText": "LOCALIZAR UM VAREJISTA"},
        "pt-pt": {"keyLearnmore": "SABER MAIS","keyCheckAvail": "VERIFICAR DISPONIBILIDADE","keyRetailerText": "LOCALIZAR UM REVENDEDOR"},
        "ru-ru": {"keyLearnmore": "ПОДРОБНОСТИ","keyCheckAvail": "ПРОВЕРКА ДОСТУПНОСТИ","keyRetailerText": "НАЙТИ ПРОДАВЦА"},
        "sk-sk": {"keyLearnmore": "ZISTIŤ VIAC","keyCheckAvail": "OVERIŤ DOSTUPNOSŤ","keyRetailerText": "VYHĽADAŤ PREDAJCU"},
        "sv-se": {"keyLearnmore": "LÄS MER","keyCheckAvail": "KOLLA TILLGÄNGLIGHETEN","keyRetailerText": "HITTA EN ÅTERFÖRSÄLJARE"},
        "tr-tr": {"keyLearnmore": "DAHA FAZLA BILGI EDININ","keyCheckAvail": "ERİŞİLEBİLİRLİĞİ KONTROL EDİN","keyRetailerText": "SATICI BULUN"},
        "zh-hk": {"keyLearnmore": "詳細介紹","keyCheckAvail": "檢查可用性","keyRetailerText": "尋找零售商"},
        "zh-tw": {"keyLearnmore": "詳細介紹","keyCheckAvail": "查看供應情形","keyRetailerText": "尋找零售商"
        }
    }
} 