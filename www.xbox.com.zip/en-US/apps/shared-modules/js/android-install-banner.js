document.addEventListener('DOMContentLoaded', function() {
    // Grab all meta tags whose names start with "android-google-play-app:" and make an object of their values
    const metaTags = document.getElementsByTagName('meta');
    let androidApp = {};
    for (var i = 0; i < metaTags.length; i++) {
        if (metaTags[i].name.indexOf('android-google-play-app:') === 0) {
            androidApp[metaTags[i].name.replace('android-google-play-app:', '')] = metaTags[i].content;
        }
    }
    
    // Populate banner via data-android-app-* attributes
    const attributes = [
        { selector: 'img[data-android-app-img]', action: (el, value) => el.src = value },
        { selector: 'img[data-android-app-alt]', action: (el, value) => el.setAttribute("alt", value) },
        { selector: 'a[data-android-app-url]', action: (el, value) => el.href = value },
        { selector: 'a[data-android-app-aria]', action: (el, value) => el.setAttribute("aria-label", value) },
        { selector: '[data-android-app-copy]', action: (el, value) => el.innerHTML = value }
    ];
    
    const androidAppBanner = document.querySelector('.android-install-banner-container .android-install-banner');
    
    for (var i = 0; i < attributes.length; i++) {
        var elements = androidAppBanner.querySelectorAll(attributes[i].selector);
        for (var j = 0; j < elements.length; j++) {
            var attribute = elements[j].getAttribute(attributes[i].selector.split('[')[1].split(']')[0]);
            attributes[i].action(elements[j], androidApp[attribute]);
        }
    }

    // Build app manifest for Native App Install Prompt on Google devices
    let manifest = {
        name: androidApp["title"],
        short_name: androidApp["title"],
        icons: [
          {
            src: androidApp["icon"],
            sizes: "192x192",
            type: "image/png"
          },
          {
            src: androidApp["icon"],
            sizes: "512x512",
            type: "image/png"
          }
        ],
        start_url: window.location.origin,
        prefer_related_applications: true,
        display: "standalone",
        related_applications: [
          {
            platform: "play",
            id: androidApp["url"].split("?id=")[1].split("&")[0],
            url: androidApp["url"],
          }
        ]
    };

    let manifest_content = encodeURIComponent(JSON.stringify(manifest));
    let manifest_url = "data:application/manifest+json," + manifest_content;
    let manifest_element = document.createElement("link");
    manifest_element.setAttribute("rel", "manifest");
    manifest_element.setAttribute("href", manifest_url);
    
    // Add manifest, show banner, and move page to compensate if user is on Android and required meta tags are present
    if (/Android/i.test(navigator.userAgent) && androidApp["url"]) {
        document.head.appendChild(manifest_element);
        document.getElementsByClassName('android-install-banner-container')[0].classList.remove('notAndroid');
        document.getElementsByTagName('html')[0].classList.add('install-banner-visible');

        // Set up Native App Install Prompt where available
        let deferredPrompt, nativeAppInstallButton, bannerExitButton;
 
        window.addEventListener("beforeinstallprompt", (e) => {
            // Prevent older versions of Chrome from automatically showing the prompt
            e.preventDefault();
            // Stash the event so it can be triggered by banner button
            deferredPrompt = e;
            // console.warn("beforeinstallprompt has fired and event is stashed");
            // Reassign banner button to Native App Install prompt instead of standard link behavior
            nativeAppInstallButton = document.querySelector('.app-button');
            bannerExitButton = document.querySelector('.banner-close');
            nativeAppInstallButton.addEventListener('click', callDeferredPrompt);
        });

        async function callDeferredPrompt(e) {
            // console.warn("prompt called - checking event validity");
            if (deferredPrompt) {
                e.preventDefault();
                deferredPrompt.prompt();
                // console.warn("awaiting user response");
                const result = await deferredPrompt.userChoice;
                if (result.outcome === "accepted") {
                    // console.warn("user has accepted the prompt, removing banner");
                    nativeAppInstallButton.removeEventListener("click", callDeferredPrompt);
                    bannerExitButton.click();
                    deferredPrompt = null;
                }
            }
        }
    }

    // Dismiss banner
    document.querySelector('.android-install-banner-container .android-install-banner .banner-close').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementsByClassName('android-install-banner-container')[0].remove();
        document.getElementsByTagName('html')[0].classList.remove('install-banner-visible');
    });
});