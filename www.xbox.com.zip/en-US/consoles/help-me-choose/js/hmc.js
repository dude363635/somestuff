$(document).ready(function() {
  const xaaLocales = ["da-dk", "de-ch", "de-de", "en-au", "en-ca", "en-gb", "en-sg", "en-nz", "en-us", "es-es", "es-mx", "fi-fi", "fr-ca", "fr-ch", "fr-fr", "it-it", "nb-no", "pl-pl", "pt-pt", "sv-se"];
  const xaa_xss1tb_locales = ["en-gb", "fr-fr", "pl-pl", "es-es", "de-de"];
  const standaloneOnly = ["en-us", "en-ca", "en-au", "en-nz", "fr-fr"];
  const xss1tbMarkets = ["en-us", "en-ca", "en-gb", "en-au", "en-nz", "fr-fr"];

  // Legal
   var HMC = (function() {
  // Anchor Links
  // setTimeout(function() {
  //     var docurl = document.URL.toLowerCase();
  //     if (docurl.indexOf("caret") > -1) {
  //         var topofshop = $("#caret").offset().top;
  //         $("HTML, BODY").animate({
  //           scrollTop: topofcaret
  //         }, 300);
  //     }
  // }, 1500)
    var aaRegions = "en-us, en-au, en-ca, en-nz, en-gb, fr-fr";
    setTimeout(function() {
     scrolltotop();
    }, 750)
    var urlRegion = document.URL.split("/")[3].toLowerCase();
    // dev area
    $(".showxsx").click(function() {
     $(".questions").hide();
     $(".recs").show();
     $(".xss").remove();
     $(".xsx").removeClass("hidden");
     $(".metext").removeClass("hidden");
     purchSetup();
    })
    $(".showxss").click(function() {
     $(".questions").hide();
     $(".recs").show();
     $(".xsx").remove();
     $(".xss").removeClass("hidden");
     $(".metext").removeClass("hidden");
     purchSetup();
    })
    $(".showanim").click(function() {
     $(".questions").hide();
     $(".metext").removeClass("hidden");
     $(".gifttext").addClass("hidden");
     $(".calculating").show();
      var q1response = "forme";
      var q2response = [];
      var q3response = "a";
      var q4response = "a";
      var q5response = [];
      var q6response = "a";
      var q7response = "a";
     calculate();
    })
    //////////////////////
    // high contrast accessibility
    $(".question .c-select-button").addClass("high-contrast");
    $(".welcomearea").fadeIn(1200);
    var changedelay = 800;
    var q1response = "";
    var q2response = [];
    var q3response = "";
    var q4response = "";
    var q5response = [];
    var q6response = "";
    var q7response = "";
    var score_x = 0;
    var score_s = 0;
    var score_s1tb = 0;
    if (!xss1tbMarkets.includes(urlRegion)) {
      score_s1tb-= 1000;
    }
    var score_hvg = 0;
    var score_ntc = 0;
  
    highestq = 0;
  
    $(".qoption").attr("aria-pressed", "false").attr("aria-live", "assertive")//.attr("role", "alert");
    $(".qoption").closest("div").each(function() {
      var ariatomove = $(this).attr("aria-label");
      $(this).removeAttr("role");
      $(this).find(".qoption").attr("aria-label", ariatomove).attr("role", "button");
    })
  
    function scrolltotop() {
     var winwidth = $(window).width();  
     if (winwidth > 199) { // was 1299
      if ($(window).scrollTop() > 0) {
         $("HTML, BODY").animate({
             scrollTop: 0
         }, 500);
      }
     }
    }
  
    function continuecheck() {
      var newqnum = parseInt($(".qfooterarea").attr("data-currentq"));
      if ($("#question" + newqnum + " [aria-pressed='true']").length > 0) {
        $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
      } else {
        $(".qcontinue").addClass("f-disabled").attr("aria-disabled", "true").attr("tabindex", "-1");
      }
    }
  
    function animatein(question) {
      $(".qfooterarea").attr("data-currentq", parseInt(question[9]));
      continuecheck();
     $(".bouncedfast").removeClass("bouncedfast");
     setTimeout(function() {
      $(question).find(".textbounce.bounced").removeClass("bounced");
     }, 50);
     setTimeout(function() {
      $(question).find(".buttonbounce.bounced").removeClass("bounced");
      $(question).find(".imgbounce.bounced").removeClass("bounced");
      $(".qfooterarea").removeClass("bounced");
     }, 250);
     var newq = "#question" + parseInt(question[9]);
      // setTimeout(function() {
        $(newq).find(".qprognumber").focus();
      // }, 550)
    }
    function animateout(question) {
     setTimeout(function() {
      $(question).find(".textbounce").addClass("bouncedfast").addClass("bounced");
     }, 50);
     setTimeout(function() {
      $(question).find(".buttonbounce").addClass("bouncedfast").addClass("bounced");
      $(question).find(".imgbounce").addClass("bouncedfast").addClass("bounced");
     }, 150);
    }
  
    // $(document).on("click", "[data-currentq=1] .qbackbutton", function(e) {
    // })
  
    $(".startquestions").on("click", function(e) {
     e.preventDefault()
     // $("#headerArea").hide();
     var btttop = $(".welcomearea").offset().top;
       $("HTML, BODY").animate({
           scrollTop: btttop
       }, 500);
      $(".welcomearea").fadeOut(700, function() {
        $("#question1").show();
        $(".qfooterarea").show();
        animatein("#question1");
      });
     setTimeout(function() {
      $(".proghider").removeClass("phbegin");
     }, 1250)
    })
    $(".progressarea a").on("click", function(e) {
     e.preventDefault();
     var thisq = $(this).closest(".question").attr("id");
     var target = $(this).data("target");
     scrolltotop();
     animateout("#" + thisq);
     setTimeout(function() {
      $("#" + thisq).hide();
      $("#" + target).show();
      animatein("#" + target);
     }, changedelay);
    })
  
    $(".qbackbutton").on("click", function(e) {
      e.preventDefault();
      var thisq = $(".qfooterarea").attr("data-currentq");
      var target = parseInt(thisq) - 1;
      if (target === 0) {
        e.preventDefault();
        $(".question").hide();
        $(".qfooterarea").hide();
        //$(".qfooterarea").addClass("bounced");
        $(".welcomearea").fadeIn(700);
        var toout = $(".qfooterarea").attr("data-currentq");
        animateout("#question" + toout)
        // $("#headerArea").show();
        setTimeout(function() {
          $(".qfooterarea").addClass("bounced");
          $(".startquestions").focus();
        }, 1200);
        target = 1
      } else {
        scrolltotop();
        animateout("#question" + thisq);
        setTimeout(function() {
          $("#question" + thisq).hide();
          $("#question" + target.toString()).show();
          animatein("#question" + target.toString());
        }, changedelay);
      }
    })
  
    $(".qcontinue").on("click", function(e) {
      e.preventDefault();
      var thisq = $(".qfooterarea").attr("data-currentq");
      var thisqnum = parseInt(thisq);
      if (thisqnum === 1) {
        q1response = "";
        $("#question1 button[aria-pressed='true']").each(function() {
          var ans = $(this).data("answer");
          q1response = ans;
        })
        if (q1response === "forme") {
          $(".gifttext").addClass("hidden");
          $(".metext").removeClass("hidden");
         } else {
          $(".metext").addClass("hidden");
          $(".gifttext").removeClass("hidden");
         }
        scrolltotop();
        animateout("#question1");
        setTimeout(function() {
          $("#question1").hide();
          $("#question2").show();
          animatein("#question2");
        }, changedelay);
      } else if (thisqnum === 2) {
        q2response = [];
        $("#question2 button[aria-pressed='true']").each(function() {
          var ans = $(this).data("answer");
          q2response.push(ans);
        })
        scrolltotop();
        animateout("#question2");
        setTimeout(function() {
          $("#question2").hide();
          $("#question3").show();
          animatein("#question3");
        }, changedelay);
      } else if (thisqnum === 3) {
        q3response = "";
        $("#question3 button[aria-pressed='true']").each(function() {
          var ans = $(this).data("answer");
          q3response = ans;
        })
        scrolltotop();
        animateout("#question3");
        setTimeout(function() {
          $("#question3").hide();
          $("#question4").show();
          animatein("#question4");
        }, changedelay);
      } else if (thisqnum === 4) {
        q4response = "";
        $("#question4 button[aria-pressed='true']").each(function() {
          var ans = $(this).data("answer");
          q4response = ans;
        })  
        scrolltotop();
        animateout("#question4");
        setTimeout(function() {
          $("#question4").hide();
          $("#question5").show();
          animatein("#question5");
        }, changedelay);
      } else if (thisqnum === 5) {
        q5response = [];
        $("#question5 button[aria-pressed='true']").each(function() {
          var ans = $(this).data("answer");
          q5response.push(ans);
        })
       scrolltotop();
       animateout("#question5");
       setTimeout(function() {
        $("#question5").hide();
        $("#question6").show();
        animatein("#question6");
       }, changedelay);
      } else if (thisqnum === 6) {
        q6response = "";
        $("#question6 button[aria-pressed='true']").each(function() {
          var ans = $(this).data("answer");
          q6response = ans;
        })  
        scrolltotop();
        animateout("#question6");
        if (aaRegions.indexOf(urlRegion) !== -1) {
          setTimeout(function() {
            $("#question6").hide();
            $("#question7").show();
            animatein("#question7");
          }, changedelay);
        } else {
          setTimeout(function() {
          $(".questions").fadeOut(700, function() {
            $(".calculating").show();
            calculate();
          });
          }, changedelay);
        }
        
      } else if (thisqnum === 7) {
        q7response = "";
        $("#question7 button[aria-pressed='true']").each(function() {
          var ans = $(this).data("answer");
          q7response = ans;
        })  
        scrolltotop();
        animateout("#question7");
        setTimeout(function() {
          $(".questions").fadeOut(700, function() {
            $(".calculating").show();
            setTimeout(function() {
              $(".bbptLarge h2").focus();
              console.log("tha man")
            }, 4000);

            calculate();
          });
         }, changedelay);
  
  
        // setTimeout(function() {
        //   $("#question7").hide();
        //   $("#question8").show();
        //   animatein("#question8");
        // }, changedelay);
      // } else if (thisqnum === 8) {
      //   q8response = "";
      //   $("#question8 .qoption.optionSelected").each(function() {
      //     var ans = $(this).data("answer");
      //     q8response = ans;
      //   })
      //   scrolltotop();
      //   animateout("#question8");
      //   setTimeout(function() {
      //     $("#question8").hide();
      //     $("#question9").show();
      //     animatein("#question9");
      //   }, changedelay);
      // } else if (thisqnum === 9) {
      //   e.preventDefault();
      //   scrolltotop();
      //   animateout("#question9");
      //   setTimeout(function() {
      //     $(".questions").hide();
      //     $(".calculating").show();
      //     calculate();
      //   }, changedelay);
      } else {
        var nextq = thisqnum + 1;
        scrolltotop();
        animateout("#question" + thisq);
        setTimeout(function() {
          $("#question" + thisq).hide();
          $("#question" + nextq.toString()).show();
          animatein("#question" + nextq.toString());
        }, changedelay);
      }
    })
  
    $(".question .buttons-singleselect button").click(function() {
      $(this).closest(".buttons-singleselect").find("button").attr("aria-pressed", "false");
      $(this).attr("aria-pressed", "true");
    })
    $(".question .buttons-checkboxes button").click(function() {
      $(this).closest(".buttons-checkboxes").find("button").attr("aria-pressed", "false");
      $(this).attr("aria-pressed", "true");
    })
    // $(".question .buttons-multiselect button").click(function() {
    //   $(this).closest(".buttons-singleselect").find("button").attr("aria-pressed", "false");
    //   $(this).attr("aria-pressed", "true");
    // })
  
    $("#question1 .qoption").on("click", function(e) {
      setTimeout(function() {
       if ($("#question1 [aria-pressed='true']").length > 0) {
        $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
       } 
     }, 150)
    })
  
    $("#question2 .qoption").on("click", function(e) {
      setTimeout(function() {
        if ($("#question2 [aria-pressed='true']").length > 0) {
          $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
        } else {
          $(".qcontinue").addClass("f-disabled").attr("aria-disabled", "true").attr("tabindex", "-1");
        }
      }, 50)
    })
  
    $("#question3 .qoption").on("click", function(e) {
      setTimeout(function() {
       if ($("#question3 [aria-pressed='true']").length > 0) {
        $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
       } 
      }, 150)
    })
  
    $("#question4 .qoption").on("click", function(e) {
      setTimeout(function() {
       if ($("#question4 [aria-pressed='true']").length > 0) {
        $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
       } 
      }, 150)
    })
  
    $("#question5 .qoption").on("click", function(e) {
      setTimeout(function() {
        if ($("#question5 [aria-pressed='true']").length > 0) {
          $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
        } else {
          $(".qcontinue").addClass("f-disabled").attr("aria-disabled", "true").attr("tabindex", "-1");
        }
      }, 50)
    })
  
    $("#question6 .qoption").on("mousedown", function(e) {
      setTimeout(function() {
       if ($("#question6 [aria-pressed='true']").length > 0) {
        $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
       } 
      }, 150)
    })
  
    $("#question7 .qoption").on("mousedown", function(e) {
      setTimeout(function() {
       if ($("#question7 [aria-pressed='true']").length > 0) {
        $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
       }
      }, 150) 
    })
  
    // $("#question7 .qcontinue").on("click", function(e) {
    //  e.preventDefault();
    //  scrolltotop();
    //  animateout("#question7");
    //  setTimeout(function() {
    //   $(".questions").fadeOut(700, function() {
    //     $(".calculating").show();
    //     calculate();
    //   });
    //  }, changedelay);
    // })
  
    // $("#question8 .qoption").on("mousedown", function(e) {
    //  e.preventDefault();
    //  if ($("#question8 .optionSelected").length === 0) {
    //   $(this).addClass("optionSelected").attr("aria-pressed", "true");
    //   $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
    //  } else {
    //   $("#question8 .qoption").removeClass("optionSelected").attr("aria-pressed", "false");
    //   $(this).addClass("optionSelected").attr("aria-pressed", "true").attr("aria-pressed", "true");
    //   $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
    //  };
    // })
  
    // $("#question9 .qoption").on("mousedown", function(e) {
    //  e.preventDefault();
    //  if ($(this).hasClass("optionSelected")) {
    //   $(this).removeClass("optionSelected").attr("aria-pressed", "false");
    //   q9response = "";
    //  } else {
    //   $("#question9 .qoption").removeClass("optionSelected").attr("aria-pressed", "false");
    //   $(this).addClass("optionSelected").attr("aria-pressed", "true");
    //   q9response = $("#question9 .optionSelected").data("answer");
    //  }
    //  if ($("#question9 .optionSelected").length > 0) {
    //   $(".qcontinue").removeClass("f-disabled").attr("aria-disabled", "false").attr("tabindex", "0");
    //  } else {
    //   $(".qcontinue").addClass("f-disabled").attr("aria-disabled", "true").attr("tabindex", "-1");
    //  }
    // })
    // $("#question9 .skipfinish").on("click", function(e) {
    //  e.preventDefault();
    //  q9response = "";
    //  scrolltotop();
    //  animateout("#question9");
    //  setTimeout(function() {
    //   $(".questions").fadeOut(700, function() {
    //     $(".calculating").show();
    //     calculate();
    //   });
    //  }, changedelay);
    // })
    // $("#question9 .finish").on("click", function(e) {
     
    // })
  
    // $(".qstartover").on("click", function(e) {
    //   e.preventDefault();
    //   q1response = "";
    //   q2response = [];
    //   q3response = "";
    //   q4response = "";
    //   q5response = [];
    //   q6response = "";
    //   q7response = "";
    //   q8response = "";
    //   q9response = "";
    //   highestq = 0;
    //   $(".optionSelected").removeClass("optionSelected");
    //   $(".qoption").attr("aria-pressed", "false");
    //   var thisq = $(".qfooterarea").attr("data-currentq");
    //   var hideq = "#question" + thisq;
    //   scrolltotop();
    //   animateout(hideq);
    //   setTimeout(function() {
    //     $(".qfooterarea").addClass("bounced");
    //   }, 100);
    //   setTimeout(function() {
    //     $(hideq).hide();
    //     $(".welcomearea").fadeIn(700);
    //     // $("#headerArea").show();
    //     target = 1
    //   }, changedelay);
    // })
  
    $(".qoption").on("keydown", function(event) {
      if((event.keyCode == 13) || (event.keyCode== 32)){
        // event.preventDefault();
        $(this).trigger("mousedown");
      }
    });
  
    // dev area #2 //////////
    if (document.URL.toLowerCase().indexOf("origin-int") !== -1) { // only in preview
      var keyh = 0;
      var keym = 0;
      var keyc = 0;
      var keyx = 0;
      $(document).on("keydown", function(e) {
        if (e.which == 72) {
          if (keyh === 0) {keyh++}
        } else if (e.which == 77) {
          if (keym === 0) {keym++}
        } else if (e.which == 67) {
          if (keyc === 0) {keyc++}
        } else if (e.which == 88) {
          if (keyx === 0) {keyx++}
        }
  
        if (keyh + keym + keyc + keyx === 4) {
          console.log("Opening QA tool");
          qabegin();
        }
      })
      $(document).on("keyup", function(e) {
        if (e.which == 72) {
          if (keyh === 1) {keyh--}
        } else if (e.which == 77) {
          if (keym === 1) {keym--}
        } else if (e.which == 67) {
          if (keyc === 1) {keyc--}
        } else if (e.which == 88) {
          if (keyx === 1) {keyx--}
        }
      })
      function qabegin() {
        $("body").append('<div class="qatool" style="position:fixed; display: block; left: 0; right: 0; margin: 0 auto; top: 150px; text-align: center;' + 
          'z-index: 5; background-color: #eeeeee; width: 70%; padding: 12px; border: 2px darkblue solid">' +
            '<h2>QA Quick Picks</h2>' +
            '<p style="color: brown;">Instructions: In the text box below, enter the question numbers and responses as indicated by the summary below. Press "Submit" to load results screen.<p><br>' +
            '<p>Question 1: A - for me ::: B - gift</p>' +
            '<p>Question 2: A - kids ::: B - teens ::: C - adults (MULTI)</p>' +
            '<p>Question 3: A - want it all ::: B - best value ::: C - speed & storage ::: D - don\'t know</p>' +
            '<p>Question 4: A - physical ::: B - digital ::: C - either</p>' +
            '<p>Question 5: A - action & adventure ::: B - family & kids ::: C - fighting ::: D - racing & flying ::: E - roleplaying ::: F - shooter ::: G - sports ::: H - strategy ::: S - skip (MULTI)</p>' +
            '<p>Question 6: A - couple games ::: B - handful of games ::: C - ton of games ::: D - don\'t know</p>' +
            '<p>Question 7: A - yes xaa ::: B - no xaa ::: C - don\'t know</p><br><br>' +
            '<textarea class="qaenter" style="display: inline-block; margin-left: 8px; width:280px; height: 26px;"></textarea><br><br>' +
            '<button class="qaenterbutton">Submit</button>' +
          '</div>'
          )
        $(".qaenter").val("1A-2A-3A-4A-5A-6A-7A");
        $(".qaenterbutton").click(function() {
          qaentered();
        })
      }
      function qaentered() {
        var qaentryraw = $(".qaenter").val().toLowerCase();
        var qaentry = qaentryraw.split("-");
        qaentry.forEach(function(ent) {
          var entryraw = ent.trim();
          var thenumber = parseInt(entryraw);
          if (thenumber === 1) {
            entryraw = entryraw.replace("1", "");
            if (entryraw.indexOf("a") !== -1) {
              q1response = "forme";
            } else {
              q1response = "gift";
            }
          }
          if (thenumber === 2) {
            entryraw = entryraw.replace("2", "");
            if (entryraw.indexOf("a") !== -1) {
              q2response.push("kids");
            } 
            if (entryraw.indexOf("b") !== -1) {
              q2response.push("teens");
            } 
            if (entryraw.indexOf("c") !== -1) {
              q2response.push("adults");
            }
          }
          if (thenumber === 3) {
            entryraw = entryraw.replace("3", "");
            if (entryraw.indexOf("a") !== -1) {
              q3response = "wantitall";
            } else if (entryraw.indexOf("b") !== -1) {
              q3response = "bestvalue";
            } else if (entryraw.indexOf("c") !== -1) {
              q3response = "speedstorage";
            } else {
              q3response = "dontknowvalue";
            }
          }
          if (thenumber === 4) {
            entryraw = entryraw.replace("4", "");
            if (entryraw.indexOf("a") !== -1) {
              q4response = "physical";
            } else if (entryraw.indexOf("b") !== -1) {
              q4response = "digital";
            } else {
              q4response = "either";
            }
          }
          if (thenumber === 5) {
            entryraw = entryraw.replace("5", "");
            if (entryraw.indexOf("s") === -1) {
              if (entryraw.indexOf("a") !== -1) {
                q5response.push("actionadventure");
              } 
              if (entryraw.indexOf("b") !== -1) {
                q5response.push("familykids");
              } 
              if (entryraw.indexOf("c") !== -1) {
                q5response.push("fighting");
              }
              if (entryraw.indexOf("d") !== -1) {
                q5response.push("racingflying");
              } 
              if (entryraw.indexOf("e") !== -1) {
                q5response.push("roleplaying");
              } 
              if (entryraw.indexOf("f") !== -1) {
                q5response.push("shooter");
              }
              if (entryraw.indexOf("g") !== -1) {
                q5response.push("sports");
              } 
              if (entryraw.indexOf("h") !== -1) {
                q5response.push("strategy");
              }
            }
          }
          if (thenumber === 6) {
            entryraw = entryraw.replace("6", "");
            if (entryraw.indexOf("a") !== -1) {
              q6response = "couple";
            } else if (entryraw.indexOf("b") !== -1) {
              q6response = "handful";
            } else if (entryraw.indexOf("c") !== -1) {
              q6response = "ton";
            } else {
              q6response = "notsure";
            }
          }
          if (thenumber === 7) {
            entryraw = entryraw.replace("7", "");
            if (entryraw.indexOf("a") !== -1) {
              q7response = "yesaa";
            } else if (entryraw.indexOf("b") !== -1) {
              q7response = "noaa";
            } else {
              q7response = "dontknowaa";
            }
          }
        })
        if (q1response === "forme") {
          $(".gifttext").addClass("hidden");
          $(".metext").removeClass("hidden");
        } else {
          $(".metext").addClass("hidden");
          $(".gifttext").removeClass("hidden");
        }
        console.log("q1response:" + q1response);
        console.log("q2response:" + q2response);
        console.log("q3response:" + q3response);
        console.log("q4response:" + q4response);
        console.log("q5response:" + q5response);
        console.log("q6response:" + q6response);
        console.log("q7response:" + q7response);
  
        calculate("qa");
        $(".questions").hide();
        $(".qatool").remove();
      }
    }
    /////////////////////////
  
    var attributes_x = [];
    var attributes_s = [];
    var attributes_s1tb = [];
    var showxaa = false;
    function calculate(mode) {
     // calculate scores question by question
     if (q3response === "wantitall") {
      score_x += 50;
      attributes_x.push("mostpowerful");
     } else if (q3response === "speedstorage") {
      score_s1tb += 50;
      // attributes_s1tb.push("upgrading");
     } else if (q3response === "bestvalue") {
      score_s += 3;
      attributes_s.push("upgrading");
     }
     if (q4response === "physical") {
      score_x += 50;
      attributes_x.push("discdrive");
     } else if (q4response === "digital") {
      score_s += 3;
      score_s1tb += 3;
      attributes_s.push("alldigital");
      attributes_s1tb.push("alldigital");
     }
     if (q6response === "couple" || q6response === "notsure") {
      score_s += 1;
     } else if (q6response === "ton") {
      score_x += 3;
      score_s1tb += 4;
      attributes_x.push("1tb");
      attributes_s1tb.push("1tb");
     }
     if (q7response === "yesaa") {
      score_x += 2;
      if (standaloneOnly.includes(urlRegion)) {
        score_s1tb-= 100;
      }
      showxaa = true;
     } else if (q7response === "noaa") {
      score_s += 1;
     }
  
     // populating consoles
     var xors = "xsx";
     if (score_s > score_x) {
      xors = "xss";
     }
     if (score_s1tb > score_x && score_s1tb > score_s) {
      xors = "xss1tb"
     }
     console.log("score_s: " + score_s + " score_x: " + score_x + " score_s1tb: " + score_s1tb);
     // if (score_m > 1) {
     //  xors = "x1m";
     // }
  
     // if (xors !== "x1m") {
     //   if (q3response.length === 0 || q3response.indexOf("kids") !== -1) {
     //    var ratingsort = "all";
     //   } else {
     //    var ratingsort = "teen";
     //   }
     //   regConsoles = [];
     //   var starterConsole = {};
     //   var regConsolesRaw = allConsoles.locales[urlRegion];
     //   for (var i = 0; i < regConsolesRaw.length; i++) {
     //    if (regConsolesRaw[i].hmc.toLowerCase() === "true" && regConsolesRaw[i].product.toLowerCase().indexOf(xors) !== -1) {
     //     regConsoles.push(regConsolesRaw[i]);
     //    } else if (regConsolesRaw[i].hmc.toLowerCase() === "starter" && regConsolesRaw[i].product.toLowerCase().indexOf(xors) !== -1) {
     //     starterConsole = regConsolesRaw[i];
     //    }
     //   }
       
     //   var storageans = "low";
     //   if (q9response === "6-10" || q9response === "eleven") {
     //    storageans = "high";
     //   }
     //   var sortedConsoles = regConsoles.sort(function(a,b) {
     //    var agenrematch = 0;
     //    var bgenrematch = 0;
     //    for (var i = 0; i < q5response.length; i ++) {
     //     if (a.genres.toLowerCase().indexOf(q5response[i]) !== -1) {
     //      agenrematch = 1;
     //     }
     //     if (b.genres.toLowerCase().indexOf(q5response[i]) !== -1) {
     //      bgenrematch = 1;
     //     }
     //    }
     //    var astoragematch = 0;
     //    var bstoragematch = 0;
     //    if (storageans === "low" && a.storage.toLowerCase() === "500gb") {
     //     astoragematch = 1;
     //    }
     //    if (storageans === "high" && a.storage.toLowerCase() !== "500gb") {
     //     astoragematch = 1;
     //    }
     //    if (storageans === "low" && b.storage.toLowerCase() === "500gb") {
     //     bstoragematch = 1;
     //    }
     //    if (storageans === "high" && b.storage.toLowerCase() !== "500gb") {
     //     bstoragematch = 1;
     //    }
     //    if (ratingsort === "teen") {
     //     return bgenrematch - agenrematch || bstoragematch - astoragematch || parseInt(a.position) - parseInt(b.position)
     //    } else {
     //     return b.rating.toLowerCase().indexOf(ratingsort) - a.rating.toLowerCase().indexOf(ratingsort) || bgenrematch - agenrematch || bstoragematch - astoragematch || parseInt(a.position) - parseInt(b.position)
     //    }
        
     //   })
  
     //    var nostarterlocales = "en-gb,en-us";
     //   if (q2response === "firstconsole" && nostarterlocales.indexOf(urlRegion) === -1) {
     //    sortedConsoles.unshift(starterConsole);
     //   }
  
     //   var bundlenum = 3;
     //   if (sortedConsoles.length < 3) {
     //    bundlenum = sortedConsoles.length;
     //   }
     //   var giftpost = "-me";
     //   if (q1response !== "forme") {
     //    giftpost = "-gift";
     //   }
     //   for (var i = 0; i < bundlenum; i++) {
     //    if (sortedConsoles[i].tprPriceText === "####") {
     //     var theprice = '<span itemprop="price">' + sortedConsoles[i].priceText + '</span>';
     //    } else {
     //     var theprice = '<span itemprop="price" style="text-decoration: line-through;">' + sortedConsoles[i].priceText + 
     //                    '</span><span itemprop="price" style="margin-left: 8px;">' + sortedConsoles[i].tprPriceText + '</span>';
     //    }
  
     //    var thebadge = "";
     //    console.log(sortedConsoles[i])
     //    if (sortedConsoles[i].genres.length > 0) {
     //     for (var j = 0; j < q5response.length; j++) {
     //      if (sortedConsoles[i].genres.indexOf(q5response[j]) !== -1) {
     //       var thebadge = $(".phrases [data-because='" + q5response[j] + giftpost + "']").text();
     //      }
     //     }
     //    }
     //    if (i === 0 && q2response === "firstconsole") {
     //     var thebadge = $(".phrases [data-because='new" + giftpost + "']").text();
     //    }
        
     //    $(".thebundles").append('<div data-grid="col-4 pad-6x"><div data-grid="col-12">' +
     //                 '<section class="m-content-placement-item f-size-medium">' +
     //                   '<a href="' + sortedConsoles[i].detailsURL + '" target="_blank" aria-label="learn more about ' + sortedConsoles[i].headline + '">' +
     //                     '<picture>' +
     //                         //<source srcset="http://placehold.it/491x276" media="(min-width:0)">
     //                         '<img srcset="' + sortedConsoles[i].image + '" src="' + sortedConsoles[i].image + '" alt="' + sortedConsoles[i].headline + '">' +
     //                     '</picture>' +
     //                     '</a>' +
     //                     '<div>' +
     //                         '<p class="c-paragraph-3" style="font-weight: 600;">' + thebadge + '</p>' +
     //                         '<h3 class="c-heading">' + sortedConsoles[i].headline + '</h3>' +
     //                         '<div class="c-price" itemprop="offers" itemscope itemtype="http://schema.org/Offer">' +
     //                      theprice +
     //                   '</div>' +
     //                         '<a href="' + sortedConsoles[i].detailsURL + '" target="_blank" class="c-call-to-action c-glyph" aria-label="learn more about ' + sortedConsoles[i].headline + '">' +
     //                             '<span>' + sortedConsoles[i].detailsCTA + '</span>' +
     //                         '</a>' +
     //                     '</div></section></div></div>')
     //   }
  
     // }
  
     // remove the badge if not all 3 have them
     // $(".thebundles .c-paragraph-3").each(function() {
     //  if ($(this).text() === "") {
     //   $(".thebundles .c-paragraph-3").remove();
     //   return false;
     //  }
     // })
     // fill in x1s, x1x blurb
     var attstoshow = [];
     var mainblurb = "";
     console.log("xors: " + xors);
     if (xors === "xsx") {
      attstoshow = attributes_x;
      if (q1response === "forme") {
        if (attstoshow.length > 0) {
          mainblurb = $(".phrases [data-blurb='xsx-me']").text();
        } else {
          mainblurb = $(".phrases [data-blurb='xsx-me-noatt']").text();
        }
      } else {
        if (attstoshow.length > 0) {
          mainblurb = $(".phrases [data-blurb='xsx-gift']").text();
        } else {
          mainblurb = $(".phrases [data-blurb='xsx-gift-noatt']").text();
        }
      }
     } else if (xors === "xss") {
      attstoshow = attributes_s;
      if (q1response === "forme") {
        if (attstoshow.length > 0) {
          mainblurb = $(".phrases [data-blurb='xss-me']").text();
        } else {
          mainblurb = $(".phrases [data-blurb='xss-me-noatt']").text();
        }
      } else {
        if (attstoshow.length > 0) {
          mainblurb = $(".phrases [data-blurb='xss-gift']").text();
        } else {
          mainblurb = $(".phrases [data-blurb='xss-gift-noatt']").text();
        }
      }
     } else { //xss1tb
      attstoshow = attributes_s1tb;
      if (q1response === "forme") {
        mainblurb = $(".phrases [data-blurb='xss1tb-me']").text();
      } else {
        mainblurb = $(".phrases [data-blurb='xss1tb-gift']").text();
      }
     }
  
     var numphrase = "";
     if (attstoshow.length > 2) {
      numphrase = $(".phrases [data-attributes='threeattributes']").text().replace("--PLACEHOLDER1--", $("[data-attribute='" + attstoshow[0] + "']").text())
                                                                 .replace("--PLACEHOLDER2--", $("[data-attribute='" + attstoshow[1] + "']").text())
                                                                 .replace("--PLACEHOLDER3--", $("[data-attribute='" + attstoshow[2] + "']").text());
     } else if (attstoshow.length === 2) {
      numphrase = $(".phrases [data-attributes='twoattributes']").text().replace("--PLACEHOLDER1--", $("[data-attribute='" + attstoshow[0] + "']").text())
                                                                 .replace("--PLACEHOLDER2--", $("[data-attribute='" + attstoshow[1] + "']").text());
     } else if (attstoshow.length === 1) {
      numphrase = $(".phrases [data-attributes='oneattribute']").text().replace("--PLACEHOLDER1--", $("[data-attribute='" + attstoshow[0] + "']").text());
     }
     else if (attstoshow.length === 0) {
      numphrase = $(".phrases [data-attributes='oneattribute']").text().replace("--PLACEHOLDER1--", $("[data-attribute='" + attstoshow[0] + "']").text());
     }
     mainblurb = mainblurb.replace("--PLACEHOLDER1--", numphrase);
  
     if (showxaa === false || (xors === "xss1tb" && standaloneOnly.includes(urlRegion))) {
      mainblurb = mainblurb.replace("--PLACEHOLDER2--", "");
     } else {
      if (xors === "xsx") {
        var xaatext = $(".phrases [data-attribute='xsx-xaa']").html();
      } else {
        var xaatext = $(".phrases [data-attribute='xss-xaa']").html();
      }
      mainblurb = mainblurb.replace("--PLACEHOLDER2--", xaatext);
     }
     $(".dynamicText").html(mainblurb);
     console.log(mainblurb)  
  
     // animation
     for (var i = 0; i < 6; i++) {
      (function() {
       var time = (i * 3500);
       setTimeout(function() {
        $(".bottomglow").removeClass("botglowfade");
       }, time)
      })();
     }
     for (var i = 1; i < 7; i++) {
      (function() {
       var time = (i * 3500) - 1750;
       setTimeout(function() {
        $(".bottomglow").addClass("botglowfade");
       }, time)
      })();
     }
     for (var i = 1; i < 4; i++) {
      (function() {
       var theclass = ".calcphrase" + i;
       var time = (i * 3000) - 3000;
       setTimeout(function() {
        $(theclass).not(".hidden").fadeIn(600);
        setTimeout(function() {
         $(theclass).not(".hidden").fadeOut(700);
        }, 1699)
       }, time)
      })();
     }
   
     $(".gotoresults").click(function() {
      $(".calculating").hide();
      $(".recs").show();
      if (xors === "xsx") {
       $(".xsx").removeClass("hidden");
       $(".xss").remove();
       $(".xss1tb").remove();
       purchSetup();
      } else if (xors === "xss") {
       $(".xss").removeClass("hidden");
       $(".xsx").remove();
       $(".xss1tb").remove();
       purchSetup();
      } else { //xss1tb
       $(".xss").remove();
       $(".xsx").remove();
       $(".xss1tb").removeClass("hidden");
       purchSetup();
      }
     })
  
      // seconds to rec screen
      if (xors === "xsx") {
       $(".xsx").removeClass("hidden");
       $(".xss").remove();
       $(".xss1tb").remove();
       purchSetup();
      } else if (xors === "xss") {
       $(".xss").removeClass("hidden");
       $(".xsx").remove();
       $(".xss1tb").remove();
       purchSetup();
      } else { //xss1tb
       $(".xss").remove();
       $(".xsx").remove();
       $(".xss1tb").removeClass("hidden");
       purchSetup();
      }
      if (mode === "qa") { var delaytime = 0 } else { delaytime = 0 }
     setTimeout(function() {
      $(".calculating").fadeOut(700, function() {
        $(".recs").fadeIn(400);
        // $("#headerArea").slideDown();
        // $("#headerArea").css("overflow", "initial");
      })
      var currenturl = window.location.href;
      var tempurl = currenturl.split("#")[0]
      var btttoprec = $(".recs").offset().top;
        $("HTML, BODY").animate({
            scrollTop: btttoprec
        }, 500);
        console.log("q1response:" + q1response);
        console.log("q2response:" + q2response);
        console.log("q3response:" + q3response);
        console.log("q4response:" + q4response);
        console.log("q5response:" + q5response);
        console.log("q6response:" + q6response);
        console.log("q7response:" + q7response);
      if (score_x > score_s && score_x > score_s1tb) {
       $(".xsx").removeClass("hidden");
       var newurl = tempurl + "#x";
       window.history.replaceState(currenturl, "Xbox Series X", newurl);
      } else if (score_s > score_x && score_s > score_s1tb) {
       $(".xss").removeClass("hidden");
       var newurl = tempurl + "#s";
       window.history.replaceState(currenturl, "Xbox Series S", newurl);
      } else { //xss1tb
       $(".xss1tb").removeClass("hidden");
       var newurl = tempurl + "#s1tb";
       window.history.replaceState(currenturl, "Xbox Series S - 1 TB (Black)", newurl);
      }
     }, delaytime)
      if (xors === "xss1tb" && standaloneOnly.includes(urlRegion)) {
        $(".purchBoxR").remove();
        $("#standalonePurch-s1tb").remove();
        $(".bbpurchDesc").remove();
        $(".xss1tb").addClass("onlyStandalone");
      } else {
        $("#standalonePurch-s1tb-noXAA").remove();
      }
  
    }
  
    })();
  
   // purchase section
   function purchSetup() {
   $(document).ready(function() {
      consSoldOut = "f";
        var API_pop = (function() {
            var urlRegion = document.URL.split("/")[3].toLowerCase();
            // page bar price
            var startingatLocales = "en-us, en-gb, en-au, en-nz"
            if ($(".price-callout").length === 0) {
                $(".m-in-page-navigation .CTAdiv").prepend('<span class="price-callout"> <span class="price-msrp"></span></span>');
            }
            $(".price-callout").clone().appendTo(".heroPrice");
    
            var stripQueryString = document.URL.split("?");
            var currentUrl = stripQueryString[0].split("/");
            var countryCode = urlRegion.split("-")[1].toUpperCase();
            var prodId = $(".standalonePurchBox").attr("data-productId") || $("#standalonePurch-s1tb-noXAA").attr("data-productId");
            var prodIdUpd = $(".standalonePurchBox").attr("data-updated-productId") || $("#standalonePurch-s1tb-noXAA").attr("data-updated-productId");
            var specIdBig = $(".standalonePurchBox").attr("data-special-productId") || $("#standalonePurch-s1tb-noXAA").attr("data-special-productId");
            if (specIdBig === undefined)
                var specIdBig = "";
            var psSku = $(".price-spider .ps-widget").attr("ps-sku");
            var currencyFormat = priceFormat.locales[urlRegion];
            var regionSoldout = globalSoldout.locales[urlRegion];
            var sheetDataLoc = allConsoles.locales[urlRegion];
            var pageId = currentUrl[currentUrl.length - 1];
               pageId = pageId.split("#")[0];
            var consoleVersion = currentUrl[currentUrl.length - 2];
            if (pageId.toLowerCase() === "home" || pageId == "") {
                pageId = currentUrl[currentUrl.length - 2];
                consoleVersion = currentUrl[currentUrl.length - 3];
            }
            console.log(consoleVersion);
            var apiMSRPPrice = "";
            var apiListPrice = "";
            if (psSku !== "") {
                $(".price-spider").css("display", "inline-block");
            }
    
            //Grab the product ID from the sheet
            for (var i = 0; i < sheetDataLoc.length; i++) {
                var splitCurrentProductURL = sheetDataLoc[i].detailsURL.split("/");
                var currentProductPageId = splitCurrentProductURL[splitCurrentProductURL.length - 1];
                var currentProductConsoleVersion = splitCurrentProductURL[splitCurrentProductURL.length - 2];
                if (currentProductPageId.toLowerCase() === "home" || currentProductPageId == "") {
                    currentProductPageId = splitCurrentProductURL[splitCurrentProductURL.length - 2];
                    currentProductConsoleVersion = splitCurrentProductURL[splitCurrentProductURL.length - 3];
                }
                console.log("console version from sheet: " + currentProductConsoleVersion.toLowerCase());
                console.log("actual console version: " + consoleVersion.toLowerCase())
                //prodId = undefined;
                if (sheetDataLoc[i].itemId.toLowerCase() === pageId.toLowerCase() && consoleVersion.toLowerCase() === currentProductConsoleVersion.toLowerCase()) {
                    console.log("using id from sheet");
                    currentProduct = sheetDataLoc[i];
                    if (currentProduct.poPid.indexOf("/") !== -1) {
                        prodId = currentProduct.poPid.toUpperCase();
                    }
                    if (currentProduct.gaPid.indexOf("/") !== -1) {
                        prodIdUpd = currentProduct.gaPid.toUpperCase();
                        console.log("FOUND UPDATED PRODUCT ID upd id= " + prodIdUpd);
                    }
                    if (currentProduct.specPid.length > 0) {
                        specIdBig = currentProduct.specPid.toUpperCase();
                        console.log("FOUND SPECIAL PRODUCT ID upd id= " + specIdBig);
                    }
    
                    break;
                }
            }
            if (prodId === undefined) { throw ("New Product ID " + pageId + " not found in Console Hub JSON. Please check spreadsheet.") }
            //console.log("upd id= " + prodIdUpd);
            //console.log("spec id= " + specIdBig);
    
            // detect daylight saving
            Date.prototype.stdTimezoneOffset = function() {
                var jan = new Date(this.getFullYear(), 0, 1);
                var jul = new Date(this.getFullYear(), 6, 1);
                return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
            }
            Date.prototype.dst = function() {
                return this.getTimezoneOffset() < this.stdTimezoneOffset();
            }
            var pacificoffset = 8;
            var dsttest = new Date();
            var usertzhours = dsttest.getTimezoneOffset() / 60;
            if (dsttest.dst()) {
                pacificoffset = 7;
            }
            console.log(prodId + " - " + prodIdUpd + "-" + specIdBig);
            // check to see if updated bigid is live
            if (prodIdUpd !== undefined && prodIdUpd !== "") {
                if (prodIdUpd.length === 12 && prodIdUpd.indexOf("-") === -1) {
                    var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + prodIdUpd + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
                    console.log(apiUrlTest);
                    if (specIdBig !== "") {
                        var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + specIdBig + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                    }
                    $.get(apiUrlTest)
                        .done(function(responseData) {
                            apiDataTest = responseData;
                            if (apiDataTest.Products.length === 0) {
                                idFound();
                            } else {
                                prodId = prodIdUpd;
                                idFound("true");
                            }
                        })
                        .fail(function() {
                            idFound();
                        })
                } else {
                    var testSku = prodIdUpd.split("/")[1];
                    var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + prodIdUpd.split("/")[0] + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
                    console.log(apiUrlTest);
                    if (specIdBig !== "") {
                        var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + specIdBig + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                    }
    
                    $.get(apiUrlTest)
                        .done(function(responseData) {
                            apiDataTest = responseData;
                            if (apiDataTest.Products.length === 0) {
                                idFound();
                            } else {
                                var skuFound = false;
                                apiDataTest.Products[0].DisplaySkuAvailabilities.forEach(function(y) {
                                    var stillLooking = true;
                                    y.Availabilities.forEach(function(z) {
                                        if ((z.SkuId === testSku.toUpperCase()) && stillLooking) {
                                            console.log("sku= " + testSku);
                                            skuFound = true;
                                            apiMSRPPrice = z.OrderManagementData.Price.MSRP;
                                            apiListPrice = z.OrderManagementData.Price.ListPrice;
                                            stillLooking = false; //Leave loop, there may be multiple matches but the first one is ususally the one you want.
                                        }
                                    })
                                })
                                if (skuFound === false) {
                                    idFound();
                                } else {
                                    var ispreorder = responseData.Products[0].DisplaySkuAvailabilities[0].Sku.Properties.IsPreOrder;
                                    if (ispreorder.toString().toLowerCase() === "true") {
                                        var potext = preordertext.locales[urlRegion].keyPreorder.toUpperCase();
                                        $(".purchButton span").text(potext);
                                        $(".purchButton").attr("aria-label", potext + ", " + responseData.Products[0].LocalizedProperties[0].ShortTitle);
                                        $(".purchButtonPB span").text(potext);
                                        // $(".purchRow1 .addToCartBtn").removeClass("hiddenImp");
                                        if (prodIdUpd !== undefined && prodIdUpd !== "") {
                                            prodId = prodIdUpd;
                                            idFound("true");
                                        } else {
                                            idFound();
                                        }
                                    } else {
                                        prodId = prodIdUpd;
                                        idFound("true");
                                    }
    
                                }
                            }
                        })
                        .fail(function() {
                            idFound();
                        })
                }
            } else {
                var testSku = prodId.split("/")[1];
                var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + prodId.split("/")[0] + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
                if (specIdBig !== "") {
                    var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + specIdBig + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                }
                $.get(apiUrlTest)
                    .done(function(responseData) {
                        apiDataTest = responseData;
                        if (apiDataTest.Products.length === 0) {
                            idFound();
                        } else {
                            var skuFound = false;
                            apiDataTest.Products[0].DisplaySkuAvailabilities.forEach(function(y) {
                                var stillLooking = true;
                                y.Availabilities.forEach(function(z) {
                                    if ((z.SkuId === testSku.toUpperCase()) && stillLooking) {
                                        console.log("sku= " + testSku);
                                        skuFound = true;
                                        apiMSRPPrice = z.OrderManagementData.Price.MSRP;
                                        apiListPrice = z.OrderManagementData.Price.ListPrice;
                                        stillLooking = false; //Leave loop, there may be multiple matches but the first one is ususally the one you want.
                                    }
                                })
                            })
                            if (skuFound === false) {
                                idFound();
                            } else {
                              var sheetDataLoc = allConsoles.locales[urlRegion];
                              var sheetProdInd;
                              for (var i = 0; i < sheetDataLoc.length; i++) {
                                  if (sheetDataLoc[i].poPid.toLowerCase() === prodId.toLowerCase()) {
                                      sheetProdInd = i;
                                  }
                              }
                              if (sheetProdInd === undefined) { throw ("New Product ID " + prodId + " not found in Console Hub JSON. Please check spreadsheet.") }
                              sheetProductInfo = sheetDataLoc[sheetProdInd];
                              
                              var ispreorder = responseData.Products[0].DisplaySkuAvailabilities[0].Sku.Properties.IsPreOrder;
                              if (ispreorder.toString().toLowerCase() === "true") {
                                  var potext = preordertext.locales[urlRegion].keyPreorder.toUpperCase();
                                  // $(".addToCartBtn").text(potext);
                                  // $(".purchRow1 .addToCartBtn").removeClass("hiddenImp");
                                  $(".purchButton span").text(potext);
                                  $(".purchButton").attr("aria-label", potext + ", " + sheetProductInfo.product);
                                  $(".purchButtonPB span").text(potext);
                              }
                              idFound();
                            }
                        }
                    })
                    .fail(function() {
                        idFound();
                    })
            }
            //Check to see if there is legal, and if there is append it to the legal section of the page.
            // if (sheetDataLoc[i].legal1 !== ""){addLegal();}
    
            function idFound(useupdated) {
                var customATC = $(".standalonePurchBox").attr("data-custom-addtocart-url");
                if (customATC === undefined) { customATC = ""; }
                var sheetDataLoc = allConsoles.locales[urlRegion];
                var sheetProdInd;
    
                if (useupdated === "true") {
                    console.log("Using new Product ID.")
                    for (var i = 0; i < sheetDataLoc.length; i++) {
                        if (sheetDataLoc[i].gaPid.toLowerCase() === prodId.toLowerCase()) {
                            sheetProdInd = i;
                        }
                    }
                    if (sheetProdInd === undefined) { throw ("New Product ID " + prodId + " not found in Console Hub JSON. Please check spreadsheet.") }
                    sheetProductInfo = sheetDataLoc[sheetProdInd];
                } else {
                    for (var i = 0; i < sheetDataLoc.length; i++) {
                        if (sheetDataLoc[i].poPid.toLowerCase() === prodId.toLowerCase()) {
                            sheetProdInd = i;
                        }
                    }
                    sheetProductInfo = sheetDataLoc[sheetProdInd];
                }
                consSoldOut = sheetProductInfo.soldOut;
                if (consSoldOut === "t") {
          console.log("console sold out " + consSoldOut)
          var lm = lmCopy.locales[urlRegion].keyLearnmore;
          var consText = $(".c-in-page-navigation .c-heading-6").first().text();
          $(".CTAdiv button span").text(lm);
          $(".CTAdiv button span").attr("aria-label", lm + ", " + consText)
          $(".CTAdiv button span").css("visibility", "visible");
          $(".page-hero .fade-in .heroPrice").remove();
          $(".page-hero .fade-in [href='#purchase']").remove();
          $(".buy-group").replaceWith('<div class="buy-group" style="visibility:visible">' + tempOos.locales[urlRegion].keyTemporarilyoutofstock + '</div>');
        }
                var prodIdBig = sheetProductInfo.gaPid.split("/")[0];
                var apiUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + prodIdBig + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
                if (specIdBig !== "") {
                    apiUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + specIdBig + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                }
                var guidIds = [];
                var apiData;
                var useAPIPrice = true; // Using a '!' character at the beginning of the priceText in the allConsoles.js price to override the API price.
                // console.log(sheetProductInfo.priceText)
                if (sheetProductInfo.priceText.charAt(0) === "!") {
                    useAPIPrice = false;
                    sheetProductInfo.priceNumber = sheetProductInfo.priceText.replace("!", "");
                    sheetProductInfo.priceText = sheetProductInfo.priceText.replace("!", "");
                    console.log(sheetProductInfo.priceText);
                    if (sheetProductInfo.tprPriceText.charAt(0) === "!") {
                        sheetProductInfo.tprPriceNumber = sheetProductInfo.tprPriceText.replace("!", "");
                        sheetProductInfo.tprPriceText = formatCurrency(sheetProductInfo.tprPriceText.replace("!", ""), currencyFormat);
                    }
                }
                // Add to Cart if in new store
                if (prodIdBig.length > 10) {
                    $.get(apiUrl)
                        .done(function(responseData) {
                            apiData = responseData;
                            populate();
                        })
                    //$(".purchRow1 .addToCartBtn").removeClass("hiddenImp");
                } else {
                    //$(".purchRow1 .f-heavyweight.retailerLB").removeClass("hiddenImp");
    
                }
    
                if (sheetProductInfo === undefined) {
                    throw ("The ProductID " + prodId + " is not found in the console JSON. Please check the spreadsheet.");
                }
                var buytext = sheetProductInfo.buyText; // USE THIS ONE
                //var buytext = "TEMPORARY TEXT ABOVE PURCHASE AREA";
                //var buyTextLoc = buyText.locales[urlRegion];
                //var buytext = buyTextLoc[Object.keys(buyTextLoc)[0]];
                $(".buyText").text(buytext);
    
                if ($(".buyText").text() === "####") {
                    $(".buyText").hide();
                }
    
                if (sheetProductInfo.priceText.length !== 0) {
                    var priceText = formatCurrency(sheetProductInfo.priceText, currencyFormat);
                    // var priceText = sheetProductInfo.priceText;
                    $(".price-msrp").text(priceText);
                } else {
                    $(".monthlyPrice").remove();
                }
                if (sheetProductInfo.priceAA.indexOf("#") === -1 && sheetProductInfo.priceAA.length > 1) {
                    var aaText = sheetProductInfo.priceAA.split(" ")[0];
                    // var priceText = sheetProductInfo.priceText;
                    $(".price-xaa-lc").text(aaText);
                } 
    
                // if (document.URL.toLowerCase().indexOf("xbox-series-x") !== -1) {
                //   var xsxString = "xbox-series-x";
                // } else {
                //   var xsxString = "xbox-series-s";
                // }
    
                var preorderURL = 'https://xbox.com/' + urlRegion + '/configure/' + sheetProductInfo.specPid.split("/")[0];
                // var preorderURL = 'https://www.microsoft.com/' + urlRegion + '/store/configure/' + xsxString + '-console/' + sheetProductInfo.specPid.split("/")[0];
                if (sheetProductInfo.gaPid.indexOf("#") === -1 && sheetProductInfo.gaPid.length > 1) {
                    preorderURL = 'https://xbox.com/' + urlRegion + '/configure/' + sheetProductInfo.gaPid.split("/")[0];
                    // preorderURL = 'https://www.microsoft.com/' + urlRegion + '/store/configure/' + xsxString + '-console/' + sheetProductInfo.gaPid.split("/")[0];
                }
                $(".purchButton").attr("href", preorderURL);
    
                if (sheetProductInfo.specPid.split("/")[0].length < 12 && sheetProductInfo.gaPid.split("/")[0].length < 12) {
                  $(".purchButton").remove();
                }
    
                var canUseAPI_MSRP = (apiMSRPPrice !== "" && apiMSRPPrice != "0" && apiMSRPPrice != "100000" && useAPIPrice);
    
                if (canUseAPI_MSRP) { //added
                    $(".price-msrp").text(formatCurrency(apiMSRPPrice, currencyFormat));
                    console.log("msrp price= " + apiMSRPPrice);
                    console.log("list price = " + apiListPrice);
                } else {
                    if (priceText === "####") {
                        $(".price-msrp").siblings().hide();
                        $(".price-msrp").hide();
                    }
                }
    
                var discountedPriceText = sheetProductInfo.tprPriceText;
    
                if (canUseAPI_MSRP && apiListPrice !== "" && (apiListPrice < apiMSRPPrice)) { //added
                    discountedPriceText = formatCurrency(apiListPrice, currencyFormat);
                    console.log("discount price = " + discountedPriceText);
                }
    
                if (discountedPriceText !== "####") {
                    $(".price-msrp").before('<span class="x-screen-reader">' + 'Regularly'+ '</span>');
                    $(".price-msrp").closest("strong").css("text-decoration", "line-through").css("margin-right", "12px");
                    $(".price-msrp").closest(".c-caption").append('<strong><span class="price-msrp">' + discountedPriceText + '</span></strong>');
                // $(".price-msrp").closest(".c-caption").append('<strong><span class="price-msrp">$250.00</span></strong>'); for testing
                    $(".price-msrp").closest(".c-caption").css("margin-bottom", "12px");
    
                    // XAA
                    // $(".consolePurchase .price-msrp").closest("span").css("text-decoration", "line-through").css("margin-right", "12px");
                    // $(".consolePurchase .price-msrp").after('<span class="price-msrp">' + discountedPriceText + '</span>');
                }
    
                var clickTitle = sheetProductInfo.itemId;
                //$(".addToCartBtn").attr("aria-label", $(".addToCartBtn").attr("aria-label").replace("consoleName", clickTitle));
    
    
                // XAA Controls
                // if (sheetProductInfo.switchAA === "TRUE") {
                //     $(".hero-pricing p:nth-child(1)").remove();
                //     $(".hero-pricing .addToCartBtn").remove();
                //     $(".buyText").remove();
                //     $(".gotoRetailer").remove();
                //     } else {
                //         $(".hero-pricing p:nth-child(2)").remove();
                //         $(".buttonAA").remove();
                //         $(".bannerAA").remove();
                //         $(".purchaseAA").remove();
                //         $("#caret-footnote").remove();
                //         $("#cross-footnote").remove();
                //     }
    
                if (urlRegion === "en-au") {
                    $(".purchaseAA").addClass("enAU");
                }
              
    
                function populate() {
                    if (prodId.split("/")[1] !== undefined) {
                        var sid = prodId.split("/")[1];
                    } else {
                        if (apiData.Products[0]) {
                            var sid = apiData.Products[0].DisplaySkuAvailabilities[0].Sku.SkuId;
                        } else {
                            outOfStock();
                            return false;
                        }
                    }
    
                    if (apiData.Products[0]) {
                        for (var t = 0; t < apiData.Products[0].DisplaySkuAvailabilities.length; t++) {
                            if (apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].SkuId === sid.toUpperCase()) {
                                var availId = apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].AvailabilityId;
                                var ispreorder = apiData.Products[0].DisplaySkuAvailabilities[t].Sku.Properties.IsPreOrder;
                                if (ispreorder.toString().toLowerCase() === "true") {
                                    buttonPreorder();
                                }
                                if (apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].Properties.PreOrderReleaseDate) {
                                    $(".buyText").before('<h3 class="c-heading-3 availableDate"></h3>');
    
                                    var releasedateraw = apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].Properties.PreOrderReleaseDate;
                                    releasedateraw = new Date(releasedateraw);
                                    releasedateraw.setHours(releasedateraw.getHours() + pacificoffset - usertzhours)
                                    var rdYear = releasedateraw.getYear() + 1900;
                                    var rdMonth = releasedateraw.getMonth() + 1;
                                    var rdDay = releasedateraw.getDate();
                                    var zhArray = ["zh-hk", "zh-tw"];
                                    var frArray = ["fr-ca", "fr-be", "fr-ch", "fr-fr"];
                                    var deArray = ["de-at", "de-ch", "de-de"];
                                    var nlArray = ["nl-be", "nl-nl"];
                                    var esArray = ["es-ar", "es-cl", "es-co", "es-mx"];
    
                                    // Available and date groups
                                    var esAvailArray = ["es-ar", "fr-be", "es-cl", "es-co", "es-es", "fr-fr", "es-mx", "fr-ch"];
                                    var engDMAvailArray = ["en-ie", "he-il", "en-nz", "ar-sa", "en-za", "ar-ae", "en-gb"];
                                    var singAvailArray = ["en-hk", "en-in", "en-sg"];
    
                                    if (esAvailArray.indexOf(urlRegion) > -1) {
                                        availConvert("Disponible ", "daymonth");
                                    } else if (engDMAvailArray.indexOf(urlRegion) > -1) {
                                        availConvert("Available ", "daymonth");
                                    } else if (urlRegion === "en-us" || urlRegion === "en-ca") {
                                        availConvert("Available ", "monthday");
                                    } else if (singAvailArray.indexOf(urlRegion) > -1) {
                                        availConvert("Available ", "daymonth");
                                    } else if (urlRegion === "zh-cn") {
                                        availConvert("发布日期", "daymonth");
                                    } else if (urlRegion === "fr-ca") {
                                        availConvert("Disponible ", "monthday");
                                    } else if (urlRegion === "tr-tr") {
                                        availConvert("Satışta ", "daymonth");
                                    } else if (urlRegion === "zh-tw") {
                                        availConvert("金會員免費遊戲 ", "monthday");
                                    }
    
                                    if (deArray.indexOf(urlRegion) > -1) {
                                        availConvert("Erhältlich ", "daymonth");
                                    } else if (nlArray.indexOf(urlRegion) > -1) {
                                        availConvert("Beschikbaar ", "daymonth");
                                    } else if (urlRegion === "ko-kr") {
                                        availConvert("멤버에게 무료 증정", "monthday");
                                    } else if (urlRegion === "cs-cz") {
                                        availConvert("Dostupné ", "daymonth");
                                    } else if (urlRegion === "da-dk") {
                                        availConvert("Tilgængelig ", "daymonth");
                                    } else if (urlRegion === "el-gr") {
                                        availConvert("Διαθέσιμα ", "daymonth");
                                    } else if (urlRegion === "fi-fi") {
                                        availConvert("Saatavilla ", "daymonth");
                                    } else if (urlRegion === "hu-hu") {
                                        availConvert("Elérhető ", "daymonth");
                                    } else if (urlRegion === "it-it") {
                                        availConvert("Disponibile ", "daymonth");
                                    } else if (urlRegion === "nb-no") {
                                        availConvert("Tilgængelig ", "daymonth");
                                    } else if (urlRegion === "pl-pl") {
                                        availConvert("Dostępne ", "daymonth");
                                    } else if (urlRegion === "pt-pt") {
                                        availConvert("Disponível ", "daymonth");
                                    } else if (urlRegion === "ru-ru") {
                                        availConvert("В продаже ", "daymonth");
                                    } else if (urlRegion === "sk-sk") {
                                        availConvert("K dispozícii ", "daymonth");
                                    } else if (urlRegion === "sv-se") {
                                        availConvert("Tillgängligt ", "daymonth");
                                    } else if (urlRegion === "ja-jp") {
                                        availConvert("発売日: ", "ja");
                                    } else if (urlRegion === "pt-br") {
                                        availConvert("Disponível ", "daymonth");
                                    }
    
                                    function availConvert(word, monthday) {
                                        if (monthday === "daymonth") {
                                            var slashdate = rdDay + "/" + rdMonth + "/" + rdYear;
                                        } else if (monthday === "monthday") {
                                            var slashdate = rdMonth + "/" + rdDay + "/" + rdYear;
                                        } else { // for ja-jp
                                            var slashdate = releasedateraw.toLocaleDateString(monthday);
                                        }
                                        var nowDate = new Date();
                                        if (releasedateraw < nowDate) {
                                            hideDate();
                                        }
                                        $(".availableDate").text(word + slashdate);
                                    }
                                } else {
                                    hideDate();
                                }
    
    
                            }
                        }
                    } else {
                        outOfStock();
                        return false;
                    }
    
                    var cartURL = "https://www.microsoft.com/" + urlRegion + "/store/buy?pid=" + prodIdBig + "&sid=" + sid;
                    var interstitial = interstitialText.locales[urlRegion].KeyInterstitial;
                    if (interstitial !== "") {
                        cartURL = cartURL + "&aid=" + availId + "&crosssellid=" + interstitial;
                    }
                    if (sheetProductInfo.switchPurchase === "TRUE") {
                       cartURL =  "https://www.microsoft.com/" + urlRegion + "/p" + "/xbox-one-offer/" + prodIdBig + "/" + sid;
                       }
                    if (specIdBig !== "" && specIdBig !== undefined) {
                        cartURL = "https://www.microsoft.com/" + urlRegion + "/store/build/" + "xbox-one-s-bundle" + "/" + specIdBig;
                    }
                    if (specIdBig !== "" && specIdBig !== undefined && sheetProductInfo.switchPurchase === "TRUE") {
                       cartURL =  "https://www.microsoft.com/" + urlRegion + "/p" + "/xbox-one-offer/" + specIdBig;
                    }
                    if (customATC !== "") {
                        cartURL = customATC;
                    }
                    // $(".purchButton a").attr("href", cartURL);
    
                    var stockUrl = "https://inv.mp.microsoft.com/v2.0/inventory/" + countryCode + "/" + prodIdBig + "/" + sid + "/" + availId;
                    if (specIdBig !== "") {
                        stockUrl = "https://inv.mp.microsoft.com/v2.0/inventory/" + countryCode + "/" + specIdBig + "/" + sid + "/" + availId;
                    }
                    console.log(stockUrl);
                    $.get(stockUrl)
                        .done(function(stockData) {
                            var shipTimes = Object.keys(stockData.futureLots);
                            var futureInstock = "";
                            if (shipTimes.length > 0) {
                                $.each(shipTimes, function() { // Cycles through all future lots to see if in stock.
                                    futureInstock = stockData.futureLots[this]["9000000013"].inStock;
                                    if (futureInstock.toLowerCase() === "true") {
                                        false; // This breaks out of the foreach loop
                                    }
                                });
                            }
                            var instock = stockData.availableLots["0001-01-01T00:00:00.0000000Z"]["9000000013"].inStock;
                            console.log("instock= " + instock);
                            console.log("future instock= " + futureInstock.toString());
                            console.log("pre-order sold out, removing Store button");
                            if (futureInstock.toString().toLowerCase() === "false") {
                              $(".purchButton").remove();
                            }
                            //console.log("ispreorder= " + ispreorder)
    
                            //MAY NEED TO UPDATE THIS CODE THE NEXT TIME THERE IS  A PRE-ORDER CONSOLE BUNDLE
                            if ((instock.toLowerCase() !== "true" /*&& ispreorder.toString().toLowerCase() !== "true" */ ) && (futureInstock.toString().toLowerCase() !== "true" /*&& ispreorder.toString().toLowerCase() === "true"*/ )) {
                                console.log("OOS")
                                outOfStock();
                            }
                        })
                        .fail(function() {
                            outOfStock();
                        })
                    $(".addToCartBtn").css("visibility", "visible").removeClass("hiddenImp");
                    
                }
    
                function outOfStock() {
    
                    if (customATC === "") {
                        $(".addToCartBtn").addClass("hiddenImp");
                        $(".ps-widget").removeClass("ps-theme-1");
                    // All Digital Edition
                         $(".triggerMain").addClass("hiddenImp");
                    }
    
                    if (sheetProductInfo.soldOut === "t") {
                        $(".hero-pricing .c-caption").hide();
                        $(".gotoRetailer").hide();
                        $(".purchRow2").append('<h3 class="c-heading-3">' + regionSoldout["keySoldout"] + '</h3>');
                    }
                }
    
                function hideDate() {
                    $(".availableDate").remove();
                }
    
                function buttonPreorder() {
                    var text = preordertext.locales[urlRegion].keyPreorder.toUpperCase();
                    $(".addToCartBtn").text(text);
                }
    
                // clone to bottom purchase section
                // $(".purchRow1").clone().appendTo(".duplicateBuy");
                // $(".purchRow2").clone().appendTo(".duplicateBuy");
                $(".purchButton").show();
                $(".purchButtonPB").show();
    
            }
            
            var preordertext = {
                "locales": {
                    "en-us": {
                        "keyPreorder": "Pre-order"
                    },
                    "ar-ae": {
                        "keyPreorder": "Pre-order"
                    },
                    "ar-sa": {
                        "keyPreorder": "Pre-order"
                    },
                    "cs-cz": {
                        "keyPreorder": "Předobjednat"
                    },
                    "da-dk": {
                        "keyPreorder": "Forudbestil"
                    },
                    "de-at": {
                        "keyPreorder": "Vorbestellen"
                    },
                    "de-ch": {
                        "keyPreorder": "Vorbestellen"
                    },
                    "de-de": {
                        "keyPreorder": "Vorbestellen"
                    },
                    "el-gr": {
                        "keyPreorder": "Προπαραγγελία"
                    },
                    "en-au": {
                        "keyPreorder": "Pre-order"
                    },
                    "en-ca": {
                        "keyPreorder": "Pre-order"
                    },
                    "en-gb": {
                        "keyPreorder": "Pre-order"
                    },
                    "en-hk": {
                        "keyPreorder": "Pre-order"
                    },
                    "en-ie": {
                        "keyPreorder": "Pre-order"
                    },
                    "en-in": {
                        "keyPreorder": "Pre-order"
                    },
                    "en-nz": {
                        "keyPreorder": "Pre-order"
                    },
                    "en-sg": {
                        "keyPreorder": "Pre-order"
                    },
                    "en-za": {
                        "keyPreorder": "Pre-order"
                    },
                    "es-ar": {
                        "keyPreorder": "Reservar"
                    },
                    "es-cl": {
                        "keyPreorder": "Reservar"
                    },
                    "es-co": {
                        "keyPreorder": "Reservar"
                    },
                    "es-es": {
                        "keyPreorder": "Reservar"
                    },
                    "es-mx": {
                        "keyPreorder": "Reservar"
                    },
                    "fi-fi": {
                        "keyPreorder": "Tilaa ennakkoon"
                    },
                    "fr-be": {
                        "keyPreorder": "Précommander"
                    },
                    "fr-ca": {
                        "keyPreorder": "Précommander"
                    },
                    "fr-fr": {
                        "keyPreorder": "Précommander"
                    },
                    "fr-ch": {
                        "keyPreorder": "Précommander"
                    },
                    "he-il": {
                        "keyPreorder": "Pre-order"
                    },
                    "hu-hu": {
                        "keyPreorder": "Előrendelés"
                    },
                    "it-it": {
                        "keyPreorder": "Preordina"
                    },
                    "ja-jp": {
                        "keyPreorder": "予約"
                    },
                    "ko-kr": {
                        "keyPreorder": "미리 주문하기"
                    },
                    "nb-no": {
                        "keyPreorder": "Forhåndsbestill"
                    },
                    "nl-be": {
                        "keyPreorder": "Reserveer"
                    },
                    "nl-nl": {
                        "keyPreorder": "Reserveer"
                    },
                    "pl-pl": {
                        "keyPreorder": "przedsprzedaż"
                    },
                    "pt-br": {
                        "keyPreorder": "Pré-venda"
                    },
                    "pt-pt": {
                        "keyPreorder": "Pré-encomendar"
                    },
                    "ru-ru": {
                        "keyPreorder": "Предзаказ"
                    },
                    "sk-sk": {
                        "keyPreorder": "Rezervovať"
                    },
                    "sv-se": {
                        "keyPreorder": "Förbeställ"
                    },
                    "tr-tr": {
                        "keyPreorder": "Ön sipariş verin"
                    },
                    "zh-cn": {
                        "keyPreorder": "预订"
                    },
                    "zh-hk": {
                        "keyPreorder": "預先訂購"
                    },
                    "zh-tw": {
                        "keyPreorder": "預購"
                    }
                }
            }
    
            var interstitialText = {
                "locales": {
                    "en-us": {
                        "KeyInterstitial": "XboxOneInterstitial"
                    },
                    "ar-ae": {
                        "KeyInterstitial": ""
                    },
                    "ar-sa": {
                        "KeyInterstitial": ""
                    },
                    "cs-cz": {
                        "KeyInterstitial": "X1SGenericInterstitial"
                    },
                    "da-dk": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "de-at": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "de-ch": {
                        "KeyInterstitial": "x1sgenericinterstitial"
                    },
                    "de-de": {
                        "KeyInterstitial": "X1XInterstitial"
                    },
                    "el-gr": {
                        "KeyInterstitial": ""
                    },
                    "en-au": {
                        "KeyInterstitial": "Xboxoneconsoles500gbinterstitial"
                    },
                    "en-ca": {
                        "KeyInterstitial": "xboxoneconsolenonrefurbinterstitial "
                    },
                    "en-gb": {
                        "KeyInterstitial": "X1GenericInterstitial"
                    },
                    "en-hk": {
                        "KeyInterstitial": ""
                    },
                    "en-ie": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "en-in": {
                        "KeyInterstitial": ""
                    },
                    "en-nz": {
                        "KeyInterstitial": "Xboxoneconsoles500gbinterstitial"
                    },
                    "en-sg": {
                        "KeyInterstitial": "XboxInterstitial"
                    },
                    "en-za": {
                        "KeyInterstitial": ""
                    },
                    "es-ar": {
                        "KeyInterstitial": ""
                    },
                    "es-cl": {
                        "KeyInterstitial": ""
                    },
                    "es-co": {
                        "KeyInterstitial": ""
                    },
                    "es-es": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "es-mx": {
                        "KeyInterstitial": ""
                    },
                    "fi-fi": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "fr-be": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "fr-ca": {
                        "KeyInterstitial": "xboxoneconsolenonrefurbinterstitial "
                    },
                    "fr-fr": {
                        "KeyInterstitial": "X1SGenericInterstitial"
                    },
                    "fr-ch": {
                        "KeyInterstitial": "x1sgenericinterstitial"
                    },
                    "he-il": {
                        "KeyInterstitial": ""
                    },
                    "hu-hu": {
                        "KeyInterstitial": ""
                    },
                    "it-it": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "ja-jp": {
                        "KeyInterstitial": ""
                    },
                    "ko-kr": {
                        "KeyInterstitial": ""
                    },
                    "nb-no": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "nl-be": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "nl-nl": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "pl-pl": {
                        "KeyInterstitial": "X1SGenericInterstitial"
                    },
                    "pt-br": {
                        "KeyInterstitial": ""
                    },
                    "pt-pt": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "ru-ru": {
                        "KeyInterstitial": ""
                    },
                    "sk-sk": {
                        "KeyInterstitial": ""
                    },
                    "sv-se": {
                        "KeyInterstitial": "XboxOneSInterstitial"
                    },
                    "tr-tr": {
                        "KeyInterstitial": ""
                    },
                    "zh-cn": {
                        "KeyInterstitial": ""
                    },
                    "zh-hk": {
                        "KeyInterstitial": ""
                    },
                    "zh-tw": {
                        "KeyInterstitial": ""
                    }
                }
            }
    
        })();
    
      // pre-order for x and s
      $(".buy-group a.purchButton").attr("target", "blank");
    
      var preorderLocales = "en-au, en-hk, en-in, en-nz, en-sg, zh-hk, zh-tw, ko-kr, •ar-ae, ar-sa, cs-cz, da-dk, de-at, de-ch, de-de, el-gr, en-gb, en-ie, es-es, fi-fi, fr-be, fr-ch, fr-fr, he-il, hu-hu, it-it, nb-no, nl-be, nl-nl, pl-pl, pt-pt, sk-sk, sv-se, tr-tr, en-us, en-ca, fr-ca, ja-jp, es-co, pt-br,es-ar";
      if (document.URL.toLowerCase().indexOf("xbox-series-x") !== -1) {
        preorderLocales = "en-au, en-hk, en-in, en-nz, en-sg, zh-hk, zh-tw, ko-kr, •ar-ae, ar-sa, cs-cz, da-dk, de-at, de-ch, de-de, el-gr, en-gb, en-ie, es-es, fi-fi, fr-be, fr-ch, fr-fr, he-il, hu-hu, it-it, nb-no, nl-be, nl-nl, pl-pl, pt-pt, sk-sk, sv-se, tr-tr, en-us, en-ca, fr-ca, es-co, ja-jp, pt-br,es-ar";
      }
    
      if (preorderLocales.indexOf(urlRegion) === -1) {
        var lm = lmCopy.locales[urlRegion].keyLearnmore;
        var consText = $(".c-in-page-navigation .c-heading-6").first().text();
        $(".CTAdiv button span").text(lm);
        $(".CTAdiv button span").attr("aria-label", lm + ", " + consText)
        $(".CTAdiv button span").css("visibility", "visible");
        $(".page-hero .fade-in .heroPrice").remove();
        $(".page-hero .fade-in [href='#purchase']").remove();
        $(".buy-group").remove();
      } else {
        $(".buy-group").removeClass("hidden");
        $(".CTAdiv button span").css("visibility", "visible");
        $(".page-hero .fade-in .heroPrice").css("visibility", "visible");
        $(".page-hero .fade-in [href='#purchase']").css("visibility", "visible");
        $(".buy-group").css("visibility", "visible");
      }

      if (document.URL.toLowerCase().indexOf("xbox-series-x") !== -1) {
        $(".buy-group a.c-call-to-action.f-lightweight").css("color", "#9bf00b");
      }
      var hidePricelocs = ["tr-tr","el-gr"];
      if (hidePricelocs.indexOf(urlRegion) !== -1) {
          $(".page-hero .fade-in .heroPrice").remove();
          $(".monthlyPrice.price-msrp").remove();
          $(".CTAdiv .price-callout").remove();
        }
    
    });
  
    
    
    //If you don't send in the format from the PriceFormat JSON, you're going to have a bad time.
    function formatCurrency(price, format) {
        var formattedPrice = "" + price;
        if (!format.keyHasDecimal) {
            formattedPrice = formattedPrice.split(".")[0];
        } else if (formattedPrice.indexOf(".99") === -1) {
            formattedPrice = formattedPrice.split(".")[0] + ".00";
        }
        if (formattedPrice.split(".")[0].length > 3) { // Needs to figure out thousands
            //console.log("splitting thousands");
            if (!format.keyHasDecimal) {
                formattedPrice = formattedPrice.substring(0, formattedPrice.length - 3) + "*" + formattedPrice.substring(formattedPrice.length - 3, formattedPrice.length);
            } else {
                formattedPrice = formattedPrice.substring(0, formattedPrice.length - 6) + "*" + formattedPrice.substring(formattedPrice.length - 6, formattedPrice.length);
            }
        }
        if (formattedPrice.split(".")[0].length > 7) { // Needs to figure out millions
            //console.log("splitting millions");
            if (!format.keyHasDecimal) {
                formattedPrice = formattedPrice.substring(0, formattedPrice.length - 7) + "MMM" + formattedPrice.substring(formattedPrice.length - 7, formattedPrice.length);
            } else {
                formattedPrice = formattedPrice.substring(0, formattedPrice.length - 10) + "MMM" + formattedPrice.substring(formattedPrice.length - 10, formattedPrice.length);
            }
        }
        
        if (format.keyThousandCharacter === ",") {
            //console.log("replacing thousand");
            formattedPrice = formattedPrice.replace("*", format.keyThousandCharacter);
            formattedPrice = formattedPrice.replace("MMM", format.keyThousandCharacter);
        } else {
            //console.log("replacing period");
            formattedPrice = formattedPrice.replace(".", ",");
            formattedPrice = formattedPrice.replace("*", format.keyThousandCharacter);
            formattedPrice = formattedPrice.replace("MMM", format.keyThousandCharacter);
        }
    
        formattedPrice = "" + format.keyPriceFormat.replace("#", formattedPrice);
    
        return formattedPrice;
    }
    
    }



      // SHARE button functionality 
  
      $(".shareLink").click(function() {
          shareboxTarget = "#" + $(this).attr("aria-controls");
          if ($(shareboxTarget).hasClass("open")) {
              $(shareboxTarget).removeClass("open").attr("aria-hidden", "true");
              $(".copy-block").removeClass("copied");
              $(".copy").each(function() {
                  $(this).attr("tabindex", "0").text($(this).attr("data-copy-default"));
              })
              $(this).attr("aria-expanded", "false");
          } else {
              $(shareboxTarget).addClass("open").attr("aria-hidden", "false");
              $(this).attr("aria-expanded", "true");
          }
      });
      $(".share-close").click(function() {
          parentLink = $(this).closest(".sharelink-wrapper").find(".shareLink");
          shareboxTarget = "#" + $(parentLink).attr("aria-controls");
          if ($(shareboxTarget).hasClass("open")) {
              $(shareboxTarget).removeClass("open").attr("aria-hidden", "true");
              $(".copy-block").removeClass("copied");
              $(".copy").each(function() {
                  $(this).attr("tabindex", "0").text($(this).attr("data-copy-default"));
              })
              $(parentLink).attr("aria-expanded", "false").focus();
          } else {
              $(shareboxTarget).addClass("open").attr("aria-hidden", "false");
              $(parentLink).attr("aria-expanded", "true");
          }
      });
      $(".copy").click(function() {
          $(".copy").each(function() {
            $(this).attr("aria-live" , "");
            $(this).attr("tabindex", "0").text($(this).attr("data-copy-default"));
          })
          $(this).attr("aria-live" , "assertive");
          $(this).attr("tabindex", "-1").text($(this).attr("data-copy-copied"));
     
          copiedText = "https://www." + $(this).prev(".share-textbox").find(".sharelink-link").text() + "\n" + $(this).prev(".share-textbox").find(".sharelink-text").text();
          console.log("copiedText " + copiedText);
          $(".copy-temp").text(copiedText);
          $(".copy-temp").select();
          document.execCommand("copy");
          //$(".copy-temp").text("");
          $(".copy-block").removeClass("copied");
          $(this).closest(".copy-block").addClass("copied");
          $(this).focus();
      
      });
  
  });
  
  priceFormat = {
        "locales": {
            "en-us": {
                "keyPriceFormat": "$# ",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "ar-ae": {
                "keyPriceFormat": "AED #",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "ar-sa": {
                "keyPriceFormat": "SR #",
                "keyHasDecimal": false,
                "keyThousandCharacter": "," //no decimal
            },
            "cs-cz": {
                "keyPriceFormat": "# Kč",
                "keyHasDecimal": false,
                "keyThousandCharacter": " " //space replace comma, no decimal
            },
            "da-dk": {
                "keyPriceFormat": "# kr",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "de-at": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "de-ch": {
                "keyPriceFormat": "CHF #",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "de-de": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "el-gr": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "en-au": {
                "keyPriceFormat": "$# ",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "en-ca": {
                "keyPriceFormat": "$# ",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "en-gb": {
                "keyPriceFormat": "£#",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "en-hk": {
                "keyPriceFormat": "HK$#",
                "keyHasDecimal": true,
                "keyThousandCharacter": "," //no decimal
            },
            "en-ie": {
                "keyPriceFormat": "€ #",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "en-in": {
                "keyPriceFormat": "₹ #",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "en-nz": {
                "keyPriceFormat": "$# ",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "en-sg": {
                "keyPriceFormat": "SG$#",
                "keyHasDecimal": false,
                "keyThousandCharacter": "," // no decimal
            },
            "en-za": {
                "keyPriceFormat": "R#",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "es-ar": {
                "keyPriceFormat": "$ #",
                "keyHasDecimal": false,
                "keyThousandCharacter": "."
            },
            "es-cl": {
                "keyPriceFormat": "$#",
                "keyHasDecimal": false,
                "keyThousandCharacter": "."
            },
            "es-co": {
                "keyPriceFormat": "$#",
                "keyHasDecimal": false,
                "keyThousandCharacter": "."
            },
            "es-es": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "es-mx": {
                "keyPriceFormat": "$#",
                "keyHasDecimal": false,
                "keyThousandCharacter": ","
            },
            "fi-fi": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": true,
                "keyThousandCharacter": "."
            },
            "fr-be": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": true,
                "keyThousandCharacter": "."
            },
            "fr-ca": {
                "keyPriceFormat": "# $",
                "keyHasDecimal": false,
                "keyThousandCharacter": "," //no decimal
            },
            "fr-ch": {
                "keyPriceFormat": "CHF #",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "fr-fr": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "he-il": {
                "keyPriceFormat": "₪‎#",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "hu-hu": {
                "keyPriceFormat": "# HUF",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "it-it": {
                "keyPriceFormat": "€#",
                "keyHasDecimal": true,
                "keyThousandCharacter": "."
            },
            "ja-jp": {
                "keyPriceFormat": "¥# (税抜)",
                "keyHasDecimal": false,
                "keyThousandCharacter": "," //no decimal
            },
            "ko-kr": {
                "keyPriceFormat": "₩#",
                "keyHasDecimal": false,
                "keyThousandCharacter": "," //no decimal
            },
            "nb-no": {
                "keyPriceFormat": "# kr",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "nl-be": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "nl-nl": {
                "keyPriceFormat": "€ #",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "pl-pl": {
                "keyPriceFormat": "# zł",
                "keyHasDecimal": true,
                "keyThousandCharacter": " " // comma replace period, space replace comma
            },
            "pt-br": {
                "keyPriceFormat": "R$ #",
                "keyHasDecimal": false,
                "keyThousandCharacter": "."
            },
            "pt-pt": {
                "keyPriceFormat": "#€",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." //period comma reversed
            },
            "ru-ru": {
                "keyPriceFormat": "# ₽",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "sk-sk": {
                "keyPriceFormat": "# €",
                "keyHasDecimal": false,
                "keyThousandCharacter": "," // no decimal
            },
            "sv-se": {
                "keyPriceFormat": "# kr",
                "keyHasDecimal": true,
                "keyThousandCharacter": "." // no comma
            },
            "tr-tr": {
                "keyPriceFormat": "# ₺",
                "keyHasDecimal": true,
                "keyThousandCharacter": ","
            },
            "zh-hk": {
                "keyPriceFormat": "HK$#",
                "keyHasDecimal": true,
                "keyThousandCharacter": "," //no decimal
            },
            "zh-tw": {
                "keyPriceFormat": "NT$#",
                "keyHasDecimal": false,
                "keyThousandCharacter": "," //no decimal
            }
        }
    }
    
    globalSoldout = {
      "locales": {
        "en-us": {
          "keySoldout": "Sold Out"
        },
        "ar-ae": {
          "keySoldout": "Sold Out"
        },
        "ar-sa": {
          "keySoldout": "Sold Out"
        },
        "cs-cz": {
          "keySoldout": " Vyprodáno"
        },
        "da-dk": {
          "keySoldout": "Udsolgt"
        },
        "de-at": {
          "keySoldout": " Ausverkauft"
        },
        "de-ch": {
          "keySoldout": " Ausverkauft"
        },
        "de-de": {
          "keySoldout": " Ausverkauft"
        },
        "el-gr": {
          "keySoldout": " Έχει εξαντληθεί"
        },
        "en-au": {
          "keySoldout": "Sold Out"
        },
        "en-ca": {
          "keySoldout": "Sold Out"
        },
        "en-gb": {
          "keySoldout": "Sold Out"
        },
        "en-hk": {
          "keySoldout": "Sold Out"
        },
        "en-ie": {
          "keySoldout": "Sold Out"
        },
        "en-in": {
          "keySoldout": "Sold Out"
        },
        "en-nz": {
          "keySoldout": "Sold Out"
        },
        "en-sg": {
          "keySoldout": "Sold Out"
        },
        "en-za": {
          "keySoldout": "Sold Out"
        },
        "es-ar": {
          "keySoldout": "Agotado"
        },
        "es-cl": {
          "keySoldout": "Agotado"
        },
        "es-co": {
          "keySoldout": "Agotado"
        },
        "es-es": {
          "keySoldout": " Agotado"
        },
        "es-mx": {
          "keySoldout": "Agotado"
        },
        "fi-fi": {
          "keySoldout": " Loppuunmyyty"
        },
        "fr-be": {
          "keySoldout": " Épuisé"
        },
        "fr-ca": {
          "keySoldout": " En rupture de stock"
        },
        "fr-ch": {
          "keySoldout": " Épuisé"
        },
        "fr-fr": {
          "keySoldout": " Épuisé"
        },
        "he-il": {
          "keySoldout": "Sold Out"
        },
        "hu-hu": {
          "keySoldout": "Elfogyott"
        },
        "it-it": {
          "keySoldout": " Esaurito"
        },
        "ja-jp": {
          "keySoldout": " 完売"
        },
        "ko-kr": {
          "keySoldout": " 품절"
        },
        "nb-no": {
          "keySoldout": "Utsolgt "
        },
        "nl-be": {
          "keySoldout": "Uitverkocht"
        },
        "nl-nl": {
          "keySoldout": "Uitverkocht"
        },
        "pl-pl": {
          "keySoldout": " Wyprzedane"
        },
        "pt-br": {
          "keySoldout": " Esgotado"
        },
        "pt-pt": {
          "keySoldout": " Esgotado"
        },
        "ru-ru": {
          "keySoldout": " Распродано"
        },
        "sk-sk": {
          "keySoldout": " Vypredané"
        },
        "sv-se": {
          "keySoldout": " Utsåld"
        },
        "tr-tr": {
          "keySoldout": " Tükendi"
        },
        "zh-hk": {
          "keySoldout": "售罄"
        },
        "zh-tw": {
          "keySoldout": "售罄"
        }
      }
    }
  
  lmCopy = {
      "locales": {
        "en-us": {
          "keyLearnmore": "LEARN MORE"
        },
        "ar-ae": {
          "keyLearnmore": "LEARN MORE"
        },
        "ar-sa": {
          "keyLearnmore": "LEARN MORE"
        },
        "cs-cz": {
          "keyLearnmore": "DALŠÍ INFORMACE"
        },
        "da-dk": {
          "keyLearnmore": "FÅ MERE AT VIDE"
        },
        "de-at": {
          "keyLearnmore": "MEHR ERFAHREN"
        },
        "de-ch": {
          "keyLearnmore": "MEHR ERFAHREN"
        },
        "de-de": {
          "keyLearnmore": "MEHR ERFAHREN"
        },
        "el-gr": {
          "keyLearnmore": "ΜΑΘΕΤΕ ΠΕΡΙΣΣΟΤΕΡΑ"
        },
        "en-au": {
          "keyLearnmore": "LEARN MORE"
        },
        "en-ca": {
          "keyLearnmore": "LEARN MORE"
        },
        "en-gb": {
          "keyLearnmore": "LEARN MORE"
        },
        "en-hk": {
          "keyLearnmore": "LEARN MORE"
        },
        "en-ie": {
          "keyLearnmore": "LEARN MORE"
        },
        "en-in": {
          "keyLearnmore": "LEARN MORE"
        },
        "en-nz": {
          "keyLearnmore": "LEARN MORE"
        },
        "en-sg": {
          "keyLearnmore": "LEARN MORE"
        },
        "en-za": {
          "keyLearnmore": "LEARN MORE"
        },
        "es-ar": {
          "keyLearnmore": "MÁS INFORMACIÓN"
        },
        "es-cl": {
          "keyLearnmore": "MÁS INFORMACIÓN"
        },
        "es-co": {
          "keyLearnmore": "MÁS INFORMACIÓN"
        },
        "es-es": {
          "keyLearnmore": "DESCUBRE MÁS"
        },
        "es-mx": {
          "keyLearnmore": "MÁS INFORMACIÓN"
        },
        "fi-fi": {
          "keyLearnmore": "LUE LISÄÄ"
        },
        "fr-be": {
          "keyLearnmore": "EN SAVOIR PLUS"
        },
        "fr-ca": {
          "keyLearnmore": "EN SAVOIR PLUS"
        },
        "fr-ch": {
          "keyLearnmore": "EN SAVOIR PLUS"
        },
        "fr-fr": {
          "keyLearnmore": "EN SAVOIR PLUS"
        },
        "he-il": {
          "keyLearnmore": "LEARN MORE"
        },
        "hu-hu": {
          "keyLearnmore": "TOVÁBBI INFORMÁCIÓ"
        },
        "it-it": {
          "keyLearnmore": "SCOPRI DI PIÙ"
        },
        "ja-jp": {
          "keyLearnmore": "詳細について"
        },
        "ko-kr": {
          "keyLearnmore": "자세한 정보"
        },
        "nb-no": {
          "keyLearnmore": "FINN UT MER"
        },
        "nl-be": {
          "keyLearnmore": "MEER INFO"
        },
        "nl-nl": {
          "keyLearnmore": "MEER INFO"
        },
        "pl-pl": {
          "keyLearnmore": "DOWIEDZ SIĘ WIĘCEJ"
        },
        "pt-br": {
          "keyLearnmore": "SAIBA MAIS"
        },
        "pt-pt": {
          "keyLearnmore": "SABER MAIS"
        },
        "ru-ru": {
          "keyLearnmore": "ПОДРОБНОСТИ"
        },
        "sk-sk": {
          "keyLearnmore": "ZISTIŤ VIAC"
        },
        "sv-se": {
          "keyLearnmore": "LÄS MER"
        },
        "tr-tr": {
          "keyLearnmore": "DAHA FAZLA BILGI EDININ"
        },
        "zh-hk": {
          "keyLearnmore": "詳細介紹"
        },
        "zh-tw": {
          "keyLearnmore": "詳細介紹"
        }
      }
      }
    
      tempOos = {
      "locales": {
        "en-us": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "ar-ae": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "ar-sa": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "cs-cz": {
          "keyTemporarilyoutofstock": "Dočasně není skladem."
        },
        "da-dk": {
          "keyTemporarilyoutofstock": "Midlertidigt udsolgt."
        },
        "de-at": {
          "keyTemporarilyoutofstock": "Vorübergehend nicht auf Lager."
        },
        "de-ch": {
          "keyTemporarilyoutofstock": "Vorübergehend nicht auf Lager."
        },
        "de-de": {
          "keyTemporarilyoutofstock": "Vorübergehend nicht auf Lager."
        },
        "el-gr": {
          "keyTemporarilyoutofstock": "Προσωρινά χωρίς απόθεμα."
        },
        "en-au": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "en-ca": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "en-gb": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "en-hk": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "en-ie": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "en-in": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "en-nz": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "en-sg": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "en-za": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "es-ar": {
          "keyTemporarilyoutofstock": "Temporalmente fuera de stock."
        },
        "es-cl": {
          "keyTemporarilyoutofstock": "Temporalmente fuera de stock."
        },
        "es-co": {
          "keyTemporarilyoutofstock": "Temporalmente fuera de stock."
        },
        "es-es": {
          "keyTemporarilyoutofstock": "Temporalmente agotado."
        },
        "es-mx": {
          "keyTemporarilyoutofstock": "Temporalmente fuera de stock."
        },
        "fi-fi": {
          "keyTemporarilyoutofstock": "Tilapäisesti loppu."
        },
        "fr-be": {
          "keyTemporarilyoutofstock": "Temporairement en rupture de stock."
        },
        "fr-ca": {
          "keyTemporarilyoutofstock": "Temporairement en rupture de stock."
        },
        "fr-ch": {
          "keyTemporarilyoutofstock": "Temporairement en rupture de stock."
        },
        "fr-fr": {
          "keyTemporarilyoutofstock": "Temporairement en rupture de stock."
        },
        "he-il": {
          "keyTemporarilyoutofstock": "Temporarily out of stock."
        },
        "hu-hu": {
          "keyTemporarilyoutofstock": "Jelenleg nincs raktáron."
        },
        "it-it": {
          "keyTemporarilyoutofstock": "Temporaneamente esaurito."
        },
        "ja-jp": {
          "keyTemporarilyoutofstock": "ただいま在庫はありません。"
        },
        "ko-kr": {
          "keyTemporarilyoutofstock": "일시적으로 재고가 없습니다."
        },
        "nb-no": {
          "keyTemporarilyoutofstock": "Midlertidig utsolgt."
        },
        "nl-be": {
          "keyTemporarilyoutofstock": "Tijdelijk niet op voorraad."
        },
        "nl-nl": {
          "keyTemporarilyoutofstock": "Tijdelijk niet op voorraad."
        },
        "pl-pl": {
          "keyTemporarilyoutofstock": "Tymczasowo niedostępny."
        },
        "pt-br": {
          "keyTemporarilyoutofstock": "Temporariamente fora de estoque."
        },
        "pt-pt": {
          "keyTemporarilyoutofstock": "Temporariamente esgotado."
        },
        "ru-ru": {
          "keyTemporarilyoutofstock": "Временно нет в наличии."
        },
        "sk-sk": {
          "keyTemporarilyoutofstock": "Dočasne nie je na sklade."
        },
        "sv-se": {
          "keyTemporarilyoutofstock": "Tillfälligt slut."
        },
        "tr-tr": {
          "keyTemporarilyoutofstock": "Geçici olarak stokta yok."
        },
        "zh-hk": {
          "keyTemporarilyoutofstock": "暫時缺貨。"
        },
        "zh-tw": {
          "keyTemporarilyoutofstock": "暫時缺貨。"
        }
      }
    } 