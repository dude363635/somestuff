// Series S Mutli Consoles Script
$(document).ready(function() {
    consSoldOut = "f";

    var urlRegion = document.URL.split("/")[3].toLowerCase();
    var countryCode = urlRegion.split("-")[1].toUpperCase();

    var currencyFormat = priceFormat.locales[urlRegion];
    var regionSoldout = globalSoldout.locales[urlRegion];
    var sheetDataLoc = allConsoles.locales[urlRegion];
    var retailerText = lmCopy.locales[urlRegion].keyRetailerText;
    var wtbURL = "https://www.xbox.com/" + urlRegion + "/where-to-buy";

    var nonStore = false;
    var nonStoreLocales = ["ar-ae", "ar-sa", "el-gr", "en-hk", "en-in", "en-za", "es-ar", "es-cl", "es-co", "es-mx", "he-il", "hu-hu", "ko-kr", "pt-br", "sk-sk", "ru-ru", "tr-tr", "zh-hk", "zh-tw"];

    if (nonStoreLocales.indexOf(urlRegion) !== -1) {
        nonStore = true;
    }
    
    let productsArray = [];

    var API_pop = (function() {
        // console.time("__DEBUG: Total execution time");
        for (let consoles_array_ind = 0; consoles_array_ind < consoles_array.length; ++consoles_array_ind) {

            var currentProductClassNum = class_array[consoles_array_ind];
            var currentProductClass = `.option${currentProductClassNum}`;

            // console.warn(`Going through the loop with ${consoles_array[consoles_array_ind]}`);
            // console.warn(`and we will be setting ${currentProductClass}`);

                // page bar price
                if ($(`${currentProductClass} .price-callout`).length === 0) {
                    $(`${currentProductClass}.CTAdiv`).prepend('<span class="price-callout"> <span class="price-msrp"></span><span class="text-erp"></span></span>');
                }

                // Set price
                $(`${currentProductClass} .heroPrice`).prepend('<span class="price-callout"> <span class="price-msrp"></span><span class="text-erp"></span></span>');

        
                // Able to set Product ID at page level
                var prodId = "";
                var prodIdUpd = $("#standalonePurch").attr("data-updated-productId");
                var specIdBig = $("#standalonePurch").attr("data-special-productId");

                var pageId = `${consoles_array[consoles_array_ind]}`;
                // console.warn(`pageId is ${pageId}`);
        
                var apiPrice = {
                    msrp: "",
                    list: "",
                    recurrence: ""
                };
                
                //Grab the product ID from the sheet
                for (var i = 0; i < sheetDataLoc.length; i++) {
                    var splitCurrentProductURL = sheetDataLoc[i].detailsURL.split("/");
                    var currentProductPageId = splitCurrentProductURL[splitCurrentProductURL.length - 1];
                    var currentProductConsoleVersion = splitCurrentProductURL[splitCurrentProductURL.length - 2];
                    if (currentProductPageId.toLowerCase() === "home" || currentProductPageId == "") {
                        currentProductPageId = splitCurrentProductURL[splitCurrentProductURL.length - 2];
                        currentProductConsoleVersion = splitCurrentProductURL[splitCurrentProductURL.length - 3];
                    }
                        
                    if (sheetDataLoc[i].itemId.toLowerCase() === pageId.toLowerCase()) {
                        currentProduct = sheetDataLoc[i];
                        if (currentProduct.poPid.indexOf("/") !== -1) {
                            prodId = currentProduct.poPid.toUpperCase();
                            // console.warn(`prodId is ${prodId}`);
                        }
                        if (currentProduct.gaPid.indexOf("/") !== -1) {
                            prodIdUpd = currentProduct.gaPid.toUpperCase();
                            // console.warn(`prodIdUpd is ${prodIdUpd}`);
                        }
                        if (currentProduct.specPid.length > 0) {
                            specIdBig = currentProduct.specPid.toUpperCase();
                            // console.warn(`specIdBig is ${specIdBig}`);
                        }

                        break;
                    }
                }

                // detect daylight saving
                Date.prototype.stdTimezoneOffset = function() {
                    var jan = new Date(this.getFullYear(), 0, 1);
                    var jul = new Date(this.getFullYear(), 6, 1);
                    return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
                }
                Date.prototype.dst = function() {
                    return this.getTimezoneOffset() < this.stdTimezoneOffset();
                }
                var pacificoffset = 8;
                var dsttest = new Date();
                var usertzhours = dsttest.getTimezoneOffset() / 60;
                if (dsttest.dst()) {
                    pacificoffset = 7;
                }

                if (nonStore === true) {
                    $(".purchase.store").remove();
                    $(".purchase.retailer a").removeClass("f-lightweight").addClass("buffer");
                } else {
                // Hiding Retailer CTA for Store
                    $(`${currentProductClass} .text-erp`).hide();
                    $(`${currentProductClass} .buy-group.retailer`).hide();
                    $(`${currentProductClass} .purchase.retailer p:not(.erp-disclaimer)`).hide();
                    $(`${currentProductClass}erp.buyBox .purchase.retailer`).css("padding-top", "5px");
                }
        
                var testSku = prodIdUpd.split("/")[1];
                var apiUrlTestBigID = specIdBig ? specIdBig : prodIdUpd.split("/")[0];
                var apiUrlTest = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + apiUrlTestBigID + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
                // console.warn(`apiUrlTest is ${apiUrlTest}`);
                if (nonStore === false) {
                    (function(apiUrlTest, apiUrlTestBigID, pageId, prodIdUpd, currentProductClass, apiPrice, testSku) {
                        fetch(apiUrlTest)
                        .then(response => {
                            if (response.ok) {
                                return response.json();
                            } else {
                                throw new Error('Network response was not ok.');
                            }
                        })
                        .then(responseData => {
                            // console.warn(`${apiUrlTest} returned some data`);
                            apiDataTest = responseData;
                            if (apiDataTest.Products.length === 0) {
                                // console.warn(`idFound is about to be called and ${currentProductClass} is happening`);
                                idFound(false, apiUrlTestBigID, pageId, currentProductClass, apiPrice);
                            } else {
                                var skuFound = false;
                                apiDataTest.Products[0].DisplaySkuAvailabilities.forEach(function(y) {
                                    var stillLooking = true;

                                    y.Availabilities.forEach(function(z) {
                                        if ((z.SkuId === testSku.toUpperCase()) && stillLooking) {
                                            skuFound = true;
                                            apiPrice.msrp = z.OrderManagementData.Price.MSRP;
                                            apiPrice.list = z.OrderManagementData.Price.ListPrice;
                                            stillLooking = false; //Leave loop, there may be multiple matches but the first one is usually the one you want.
                                            y.HistoricalBestAvailabilities.forEach(function(z) {
                                                apiPrice.recurrence = z.OrderManagementData.Price.ListPrice;
                                            })
                                        }
                                    });
                                });

                                if (skuFound === false) {
                                    // console.warn(`idFound is about to be called and ${currentProductClass} is happening`);
                                    idFound(false, apiUrlTestBigID, pageId, currentProductClass, apiPrice);
                                } else {
                                    var ispreorder = responseData.Products[0].DisplaySkuAvailabilities[0].Sku.Properties.IsPreOrder;
                                    if (ispreorder.toString().toLowerCase() === "true") {
                                        var potext = preordertext.locales[urlRegion].keyPreorder.toUpperCase();
                                        // Done in a function lower down
                                        // $(".purchButton span").text(potext);
                                        $(`${currentProductClass} .purchButton`).attr("aria-label", potext + ", " + responseData.Products[0].LocalizedProperties[0].ShortTitle);
                                        // Done in a funciton lower down
                                        // $(".purchButtonPB span").text(potext);
                                        // $(".purchRow1 .addToCartBtn").removeClass("hiddenImp");
                                        if (prodIdUpd !== undefined && prodIdUpd !== "") {
                                            prodId = prodIdUpd;
                                            // console.warn(`idFound is about to be called and ${currentProductClass} is happening`);
                                            idFound(true, prodId, pageId, currentProductClass, apiPrice);
                                        } else {
                                            // console.warn(`idFound is about to be called and ${currentProductClass} is happening`);
                                            idFound(false, apiUrlTestBigID, pageId, currentProductClass, apiPrice);
                                        }
                                    } else {
                                        prodId = prodIdUpd;
                                        // console.warn(`idFound is about to be called and ${currentProductClass} is happening`);
                                        idFound(false, prodId, pageId, currentProductClass, apiPrice);
                                    }

                                }
                            }
                        })
                        .catch(error => {
                            // console.warn(`idFound is about to be called and ${currentProductClass} is happening`);
                            idFound(false, apiUrlTestBigID, pageId, currentProductClass, apiPrice);
                        });
                    })(apiUrlTest, apiUrlTestBigID, pageId, prodIdUpd, currentProductClass, apiPrice, testSku);
                } else {
                    // console.warn(`idFound is about to be called and ${currentProductClass} is happening`);
                    idFound(false, apiUrlTestBigID, pageId, currentProductClass, apiPrice);
                }
        
                function idFound(useupdated, thisProductID, thisPageID, thisConsoleClass, thisApiPrice) {
                    var customATC = $("#standalonePurch").attr("data-custom-addtocart-url");
                    if (customATC === undefined) { customATC = ""; }
                    var sheetDataLoc = allConsoles.locales[urlRegion];
                    var sheetProdInd;
                    var sheetProductInfo;
                
                    if (useupdated === "true") {
                        for (var i = 0; i < sheetDataLoc.length; i++) {
                            if (sheetDataLoc[i].itemId.toLowerCase() === thisPageID.toLowerCase()) {
                                sheetProdInd = i;
                            }
                        }
                        if (sheetProdInd === undefined) { throw ("New Product ID " + thisPageID + " not found in Console Hub JSON. Please check spreadsheet.") }
                        sheetProductInfo = sheetDataLoc[sheetProdInd];
                    } else {
                        for (var i = 0; i < sheetDataLoc.length; i++) {
                            if (sheetDataLoc[i].itemId.toLowerCase() === thisPageID.toLowerCase()) {
                                sheetProdInd = i;
                            } 
                        }
                        sheetProductInfo = sheetDataLoc[sheetProdInd];
                    }

                    // Legal Check From Sheet
                    if (sheetProductInfo.legal1 !== "") {
                        addLegal();
                    }
                
                    // BCGG
                    var switchBCGG = sheetProductInfo.switchPurchase;
                    if (switchBCGG === "TRUE") {
                        $(`.buyBox:not(.bcgg)${thisConsoleClass} #gallery`).remove();
                        $(`.buyBox:not(.bcgg)${thisConsoleClass} .buyBoxPurchases`).remove();
                        $(`.buyBox:not(.bcgg)${thisConsoleClass}`).removeClass("buyBox").removeClass("erp");
                        $(`.pageHero${thisConsoleClass}`).before('<strong class="c-badge f-small f-highlight">' + $(".white .bcggText .c-heading-1a").text().slice(0, -1) + '</strong>');
                        
                    } else {
                        $(`.bcgg${thisConsoleClass} #gallery`).remove();
                        $(`.bcgg${thisConsoleClass} .buyBoxPurchases`).remove();
                        $(`.bcgg${thisConsoleClass}`).removeClass("buyBox").removeClass("erp");
                    }

                    var prodIdBig = sheetProductInfo.gaPid.split("/")[0];

                    var apiUrlBigID = specIdBig ? specIdBig : prodIdBig;
                    var apiUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + apiUrlBigID + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
                    var apiData;
                    var useAPIPrice = true; // Using a '!' character at the beginning of the priceText in the allConsoles.js price to override the API price.
                    if (sheetProductInfo.priceText.charAt(0) === "!") {
                        useAPIPrice = false;
                        sheetProductInfo.priceNumber = sheetProductInfo.priceText.replace("!", "");
                        sheetProductInfo.priceText = sheetProductInfo.priceText.replace("!", "");
                        if (sheetProductInfo.tprPriceText.charAt(0) === "!") {
                            sheetProductInfo.tprPriceNumber = sheetProductInfo.tprPriceText.replace("!", "");
                            sheetProductInfo.tprPriceText = formatCurrency(sheetProductInfo.tprPriceText.replace("!", ""), currencyFormat);
                        }
                    }
                    // Add to Cart if in new store
                    if (prodIdBig.length > 10) {
                        (function(thisProductID) {
                            fetch(apiUrl)
                                .then(response => response.json())
                                .then(responseData => {
                                    apiData = responseData;
                                    // console.warn("Before calling populate(), apiData is ");
                                    // console.warn(apiData);
                                    populate(thisProductID);
                                })
                                .catch(error => {
                                    console.error("Error fetching API data:", error);
                                });
                        })(thisProductID);
                    } else {
                        //
                    }
                
                    if (sheetProductInfo === undefined) {
                        throw ("The thisProductID " + thisProductID + " is not found in the console JSON. Please check the spreadsheet. THIRD");
                    }
                    
                    // Buy Text/CTA Text Strings
                    var ctaStates = sheetProductInfo.switchAA;
                    var preOrderCopy = preordertext.locales[urlRegion].keyPreorder.toUpperCase();
                    var buyNowCopy = preordertext.locales[urlRegion].keyBuynow.toUpperCase();

                    var buttonCopy = "";

                    if (ctaStates === "preorder") {
                        buttonCopy = preOrderCopy;
                    } else if (ctaStates === "buynow") {
                        buttonCopy = buyNowCopy;
                    } else if (ctaStates === "email") {
                        buttonCopy = "EMAIL";
                    } else if (ctaStates === "announce") {
                        buttonCopy = "";
                    }

                    $(".purchButton span").each(function() {
                        if ($(this).text() === "") {
                            $(this).parent().hide();
                        }
                    });
                    
                    $(`${thisConsoleClass} .buy-group`).removeClass("hidden");
                    $(`${thisConsoleClass} .buy-group`).css("visibility", "visible");
                    $(`${thisConsoleClass} .heroCTA span`).text(buttonCopy);
                    $(`${thisConsoleClass} .buy-group .purchButton span`).text(buttonCopy);
                    $(`${thisConsoleClass}.CTAdiv .purchButton`).removeClass("hidden");
                    $(`${thisConsoleClass}.CTAdiv .purchButton span`).css("visibility", "visible").text(buttonCopy);
                    $(`${thisConsoleClass} .purchButton`).attr("aria-label", buttonCopy + ", " + sheetProductInfo.product);
                    

                    if (ctaStates === "announce") {
                        $(`${thisConsoleClass}.CTAdiv .purchButton`).addClass("hidden");
                        $(`${thisConsoleClass} .heroCTA`).remove();
                    }

                    var hatchlocs = ["de-de", "en-au", "en-ie", "en-nz", "en-us", "en-ca", "en-gb", "es-co", "es-es", "es-mx", "fr-ca", "fr-fr", "it-it", "nl-nl", "sv-se", "pt-br", "pl-pl"];
                    if (hatchlocs.indexOf(urlRegion) === -1) {
                        $(".hatchProd").attr("href", "https://www.xbox.com/where-to-buy").removeClass("hatchProd");
                    }
            
                    var xaaLocales = [];
                    if (xaaLocales.indexOf(urlRegion) !== -1) {
                        $(".buy-group .hatchProd").removeClass("f-lightweight").addClass("f-heavyweight").css("color", "#054b16");
                        $(".buy-group .xaaButton").removeClass("f-lightweight").addClass("f-heavyweight").css("color", "#054b16");
                    }

                    var buytext = sheetProductInfo.buyText;
                    $(`${thisConsoleClass} .buyText`).text(buytext);
                    if ($(`${thisConsoleClass} .buyText`).text() === "####") {
                        $(`${thisConsoleClass} .buyText`).hide();
                    }

                    // Add to Cart addition
                    var preorderURL = 'https://www.xbox.com/' + urlRegion + '/configure/' + sheetProductInfo.specPid.split("/")[0];
                    if (sheetProductInfo.gaPid.indexOf("#") === -1 && sheetProductInfo.gaPid.length > 1) {
                        preorderURL = 'https://www.xbox.com/' + urlRegion + '/configure/' + sheetProductInfo.gaPid.split("/")[0];
                    }

                    // console.warn(`About to set ${thisConsoleClass} .purchButton to ${preorderURL}`);
                
                    $(`${thisConsoleClass} .purchButton`).attr("href", preorderURL).attr("data-cta-href", preorderURL).attr("data-retailer", "MS Store");

                    if (nonStore === true) {
                        $(`${thisConsoleClass}.pageHero a:not(.c-hyperlink)`).text(retailerText).attr("href", wtbURL).attr("aria-label", "");
                        $(`${thisConsoleClass}.CTAdiv button`).text(retailerText).attr("data-cta-href", wtbURL).attr("aria-label", "");
                    }

                    // Sold out through sheet
                    consSoldOut = sheetProductInfo.soldOut;

                    if (consSoldOut === "t") {
                        outOfStock();
                    }

                    // Use API Price?
                    const fullPriceText = priceFormat.locales[urlRegion].keyFullprice;
                    const newPriceText = priceFormat.locales[urlRegion].keyNewprice;
                    var canUseAPI_MSRP = (thisApiPrice.msrp !== "" && thisApiPrice.msrp != "0" && thisApiPrice.msrp != "100000" && useAPIPrice);

                    if (!canUseAPI_MSRP) {
                        if (sheetProductInfo.priceText.length !== 0) {
                            var priceText = formatCurrency(sheetProductInfo.priceText, currencyFormat);
                            $(`${thisConsoleClass} .price-msrp`).text(priceText);
                            // console.warn(`Setting ${thisConsoleClass} .price-msrp to ${priceText} from the sheet`);
                        } else {
                            $(`${thisConsoleClass} .monthlyPrice`).remove();
                        }
                    } else {
                        var priceText = formatCurrency(thisApiPrice.msrp, currencyFormat);
                    }

                    var discountedPriceText = sheetProductInfo.tprPriceText;
                    
                    if (canUseAPI_MSRP && thisApiPrice.list !== "" && (thisApiPrice.list < thisApiPrice.msrp)) {
                        discountedPriceText = formatCurrency(thisApiPrice.list, currencyFormat);
                    } else if (discountedPriceText !== "####") {
                        discountedPriceText = formatCurrency(discountedPriceText, currencyFormat);
                    }

                    if (discountedPriceText !== "####") {
                        $(`${thisConsoleClass} .price-msrp`).html('<span class="x-screen-reader">' + fullPriceText + '</span> ' + '<span class="strikethroughPrice">' + priceText + '</span>' 
                        + '<span class="x-screen-reader">' + newPriceText + '</span>' + '<span>' + discountedPriceText + '</span>');
                        $(`${thisConsoleClass} .price-msrp`).closest(".c-caption").css("margin-bottom", "12px");
                        // console.warn(`Setting ${thisConsoleClass} .price-msrp to ${discountedPriceText} from discountedPriceText, down from ${priceText}`);
                    } else {
                        if (canUseAPI_MSRP) {
                            $(`${thisConsoleClass} .price-msrp`).text(priceText);
                            // console.warn(`Setting ${thisConsoleClass} .price-msrp to ${priceText} from thisApiPrice.msrp`);
                        } else {
                            if (priceText === "####") {
                                $(`${thisConsoleClass} .price-msrp`).siblings().hide();
                                $(`${thisConsoleClass} .price-msrp`).hide();
                            }
                        }
                    }

                    
                    //Locale-specific priceAA formatting
                    if (sheetProductInfo.priceAA.indexOf("#") === -1 && sheetProductInfo.priceAA.length > 1) {
                        var oddLocales = ["fi-fi","nb-no","pl-pl","it-it","de-de","pt-pt","de-ch","fr-fr","fr-ch","fr-be","nl-be"];
                
                        var aaText = sheetProductInfo.priceAA.split(" ")[0];
                
                        if (oddLocales.indexOf(urlRegion) !== -1) {
                            var aaText = sheetProductInfo.priceAA.split(" ")[0] + " " + sheetProductInfo.priceAA.split(" ")[1] + " " + sheetProductInfo.priceAA.split(" ")[2];
                            if ((urlRegion === "it-it") || (urlRegion === "de-de") || (urlRegion === "pt-pt") || (urlRegion === "de-ch") || (urlRegion === "fr-ch") || (urlRegion === "fr-fr") || (urlRegion === "fr-be") || (urlRegion === "nl-be")) {
                                var aaText = sheetProductInfo.priceAA.split(" ")[0] + " " + sheetProductInfo.priceAA.split(" ")[1] + " ";
                            }
                        }
                        if ((urlRegion === "da-dk") || (urlRegion === "sv-se" ) || (urlRegion === "es-mx")) {
                            var aaText = " " + sheetProductInfo.priceAA.split(" ")[0] + " " + sheetProductInfo.priceAA.split(" ")[1];
                        
                        }
                        if (urlRegion === "pt-br") {
                            var aaText = " " + sheetProductInfo.priceAA.split(" ")[0] + " " + sheetProductInfo.priceAA.split(" ")[1] + " " + sheetProductInfo.priceAA.split(" ")[2] + " " + sheetProductInfo.priceAA.split(" ")[3];
                        }
                
                        if (urlRegion === "ko-kr") {
                            var aaText = " " + sheetProductInfo.priceAA.split(" ")[4] + " " + sheetProductInfo.priceAA.split(" ")[5] + " " + sheetProductInfo.priceAA.split(" ")[6];
                            $(`${thisConsoleClass} .purchase.store`).remove();
                            $(`${thisConsoleClass} .purchase.retailer a`).removeClass("f-lightweight").addClass("buffer");
                            
                        }
                        // var priceText = sheetProductInfo.priceText;
                        $(`${thisConsoleClass} .price-xaa-lc, .all-inclusive .price-xaa-lc`).text(aaText);
                    }
                
                    // EU Locales
                    var euchangeArray = ["cs-cz", "da-dk", "de-at", "de-de", "el-gr", "en-ie", "es-es", "fi-fi", "fr-be", "fr-fr", "hu-hu", "it-it", "nl-be", "nl-nl", "pl-pl", "pt-pt", "sk-sk", "sv-se"];
                    
                    // ERP
                    var erpPricing = sheetProductInfo.estimatedPrice;
                    var erpText = priceFormat.locales[urlRegion].keyErptext;
                    var priceDisclamierAria = priceFormat.locales[urlRegion].keyPriceAria;
                    var keyLimitedTimeCopy = priceFormat.locales[urlRegion].keyLimitedTimeCopy;
                    var recurrenceCopy = priceFormat.locales[urlRegion].keyRecurrenceCopy;
                
                    // $(".erp-disclaimer").attr("id", "prices");
                
                    erpText = erpText.replace("*", "<a href='#prices' class='c-hyperlink' aria-label='" + priceDisclamierAria + "'><sup>*</sup></a>");
                
                    $(`${thisConsoleClass} .text-erp`).html(erpText);
                
                    // EU Changes 
                    // Lowest 30 Day Price
                    if (euchangeArray.indexOf(urlRegion) !== -1) {
                        if (thisApiPrice.msrp !== thisApiPrice.list) {
                            thisApiPrice.recurrence = formatCurrency(thisApiPrice.recurrence, currencyFormat);
                            recurrenceCopy = recurrenceCopy.replace("PLACEHOLDER", thisApiPrice.recurrence);
                            $(`${thisConsoleClass} .store .purchase-intro`).append('<p class="c-paragraph-2 f-lean" style="padding-bottom: 24px">' + recurrenceCopy + '</p>');
                            $(`${thisConsoleClass} .heroPrice`).append('<p class="c-paragraph-2 f-lean"  style="padding-top: 3px">' + recurrenceCopy + '</p>');
                        }
                    }
                
                    if (erpPricing !== "####") {
                        if (erpPricing.indexOf(",") !== -1) {
                            var erpPrices = erpPricing.split(",");
                            var erpPriceTpr = formatCurrency(erpPrices[0], currencyFormat);
                            var erpPriceList = formatCurrency(erpPrices[1], currencyFormat);
                
                            $(`${thisConsoleClass} .price-erp`).html('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through; line-height: 1.5">' + erpPriceTpr + ' </span> ' + '<span style="margin: 0 5px 0;"> ' + erpText + '</span>' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + erpPriceList);
                            $(`${thisConsoleClass} .text-erp`).remove();
                            
                        } else if (erpPricing.toLowerCase() === "match") {
                            if (discountedPriceText !== "####") {
                                $(`${thisConsoleClass} .price-erp`).html('<span class="x-screen-reader">' + 'Full price was' + '</span>' + '<span style="text-decoration: line-through;">' + priceText + '</span>' + '<span style="margin: 0 5px 0;"> ' + erpText + '</span>' + '<span class="x-screen-reader">' + 'New price is' + '</span>' + discountedPriceText);
                            } else {
                                $(`${thisConsoleClass} .price-erp`).text(priceText);
                            }
                        } else {
                            var erpPrices = formatCurrency(erpPricing, currencyFormat);
                            $(`${thisConsoleClass} .price-erp`).text(erpPrices);
                        }
                    } else if (erpPricing === "####") { 
                        $(`${thisConsoleClass} .price-erp`).remove();
                        $(`${thisConsoleClass} .purchase.retailer .c-heading-1a-pre`).remove();
                        $(`${thisConsoleClass} .purchase.retailer .erp-disclaimer`).remove();
                        $(`${thisConsoleClass}.CTAdiv .price-callout`).remove();
                        $(`${thisConsoleClass} .heroPrice .price-callout`).remove();
                    }

                // Form JSON-LD Product data using sheet data for the current console
                (function(sheetProductInfo, apiData, thisApiPrice, preorderURL, consoles_array_ind) {
                    popProductSchema(sheetProductInfo, false, thisApiPrice, preorderURL, consoles_array_ind);
                })(sheetProductInfo, apiData, thisApiPrice, preorderURL, consoles_array_ind);
                
                    function populate(thisProductID) {
                        if (thisProductID.split("/")[1] !== undefined) {
                            var sid = thisProductID.split("/")[1];
                        } else {
                            if (apiData.Products[0]) {
                                var sid = apiData.Products[0].DisplaySkuAvailabilities[0].Sku.SkuId;
                            } else {
                                console.warn(`No api data found for ${thisPageID} which would be applied to ${thisConsoleClass}`);
                                return false;
                            }
                        }
                
                        if (apiData.Products[0]) {
                            for (var t = 0; t < apiData.Products[0].DisplaySkuAvailabilities.length; t++) {
                                if (apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].SkuId === sid.toUpperCase()) {
                                    var availId = apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].AvailabilityId;
                                    var ispreorder = apiData.Products[0].DisplaySkuAvailabilities[t].Sku.Properties.IsPreOrder;
                                    if (ispreorder.toString().toLowerCase() === "true") {
                                        buttonPreorder();
                                    }
                                    if (apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].Properties.PreOrderReleaseDate) {
                                        // $(`${thisConsoleClass} .buyText`).before('<h3 class="c-heading-3 availableDate"></h3>');
                
                                        var releasedateraw = apiData.Products[0].DisplaySkuAvailabilities[t].Availabilities[0].Properties.PreOrderReleaseDate;
                                        releasedateraw = new Date(releasedateraw);
                                        releasedateraw.setHours(releasedateraw.getHours() + pacificoffset - usertzhours)
                                        var rdYear = releasedateraw.getYear() + 1900;
                                        var rdMonth = releasedateraw.getMonth() + 1;
                                        var rdDay = releasedateraw.getDate();
                                        var zhArray = ["zh-hk", "zh-tw"];
                                        var frArray = ["fr-ca", "fr-be", "fr-ch", "fr-fr"];
                                        var deArray = ["de-at", "de-ch", "de-de"];
                                        var nlArray = ["nl-be", "nl-nl"];
                                        var esArray = ["es-ar", "es-cl", "es-co", "es-mx"];
                
                                        // Available and date groups
                                        var esAvailArray = ["es-ar", "fr-be", "es-cl", "es-co", "es-es", "fr-fr", "es-mx", "fr-ch"];
                                        var engDMAvailArray = ["en-ie", "he-il", "en-nz", "ar-sa", "en-za", "ar-ae", "en-gb"];
                                        var singAvailArray = ["en-hk", "en-in", "en-sg"];
                
                                        if (esAvailArray.indexOf(urlRegion) > -1) {
                                            availConvert("Disponible ", "daymonth");
                                        } else if (engDMAvailArray.indexOf(urlRegion) > -1) {
                                            availConvert("Available ", "daymonth");
                                        } else if (urlRegion === "en-us" || urlRegion === "en-ca") {
                                            availConvert("Available ", "monthday");
                                        } else if (singAvailArray.indexOf(urlRegion) > -1) {
                                            availConvert("Available ", "daymonth");
                                        } else if (urlRegion === "zh-cn") {
                                            availConvert("发布日期", "daymonth");
                                        } else if (urlRegion === "fr-ca") {
                                            availConvert("Disponible ", "monthday");
                                        } else if (urlRegion === "tr-tr") {
                                            availConvert("Satışta ", "daymonth");
                                        } else if (urlRegion === "zh-tw") {
                                            availConvert("金會員免費遊戲 ", "monthday");
                                        }
                
                                        if (deArray.indexOf(urlRegion) > -1) {
                                            availConvert("Erhältlich ", "daymonth");
                                        } else if (nlArray.indexOf(urlRegion) > -1) {
                                            availConvert("Beschikbaar ", "daymonth");
                                        } else if (urlRegion === "ko-kr") {
                                            availConvert("멤버에게 무료 증정", "monthday");
                                        } else if (urlRegion === "cs-cz") {
                                            availConvert("Dostupné ", "daymonth");
                                        } else if (urlRegion === "da-dk") {
                                            availConvert("Tilgængelig ", "daymonth");
                                        } else if (urlRegion === "el-gr") {
                                            availConvert("Διαθέσιμα ", "daymonth");
                                        } else if (urlRegion === "fi-fi") {
                                            availConvert("Saatavilla ", "daymonth");
                                        } else if (urlRegion === "hu-hu") {
                                            availConvert("Elérhető ", "daymonth");
                                        } else if (urlRegion === "it-it") {
                                            availConvert("Disponibile ", "daymonth");
                                        } else if (urlRegion === "nb-no") {
                                            availConvert("Tilgængelig ", "daymonth");
                                        } else if (urlRegion === "pl-pl") {
                                            availConvert("Dostępne ", "daymonth");
                                        } else if (urlRegion === "pt-pt") {
                                            availConvert("Disponível ", "daymonth");
                                        } else if (urlRegion === "ru-ru") {
                                            availConvert("В продаже ", "daymonth");
                                        } else if (urlRegion === "sk-sk") {
                                            availConvert("K dispozícii ", "daymonth");
                                        } else if (urlRegion === "sv-se") {
                                            availConvert("Tillgängligt ", "daymonth");
                                        } else if (urlRegion === "ja-jp") {
                                            availConvert("発売日: ", "ja");
                                        } else if (urlRegion === "pt-br") {
                                            availConvert("Disponível ", "daymonth");
                                        }
                
                                        function availConvert(word, monthday) {
                                            if (monthday === "daymonth") {
                                                var slashdate = rdDay + "/" + rdMonth + "/" + rdYear;
                                            } else if (monthday === "monthday") {
                                                var slashdate = rdMonth + "/" + rdDay + "/" + rdYear;
                                            } else { // for ja-jp
                                                var slashdate = releasedateraw.toLocaleDateString(monthday);
                                            }
                                            var nowDate = new Date();
                                            if (releasedateraw < nowDate) {
                                                // hideDate();
                                            }
                                            // $(".availableDate").text(word + slashdate);
                                        }
                                    } else {
                                        // hideDate();
                                    }
                
                
                                }
                            }
                        } else {
                            outOfStock();
                            return false;
                        }

                        // Cart Handled Above 344
                        // $(".purchButton a").attr("href", cartURL);
                        var cartURL = "https://www.microsoft.com/" + urlRegion + "/store/buy?pid=" + prodIdBig + "&sid=" + sid;
                        var interstitial = interstitialText.locales[urlRegion].KeyInterstitial;
                        if (interstitial !== "") {
                            cartURL = cartURL + "&aid=" + availId + "&crosssellid=" + interstitial;
                        }
                        if (sheetProductInfo.switchPurchase === "TRUE") {
                            cartURL = "https://www.microsoft.com/" + urlRegion + "/p" + "/xbox-one-offer/" + prodIdBig + "/" + sid;
                        }
                        if (specIdBig !== "" && specIdBig !== undefined) {
                            cartURL = "https://www.microsoft.com/" + urlRegion + "/store/build/" + "xbox-one-s-bundle" + "/" + specIdBig;
                        }
                        if (specIdBig !== "" && specIdBig !== undefined && sheetProductInfo.switchPurchase === "TRUE") {
                            cartURL = "https://www.microsoft.com/" + urlRegion + "/p" + "/xbox-one-offer/" + specIdBig;
                        }
                        if (customATC !== "") {
                            cartURL = customATC;
                        }
                
                        var stockUrlBigID = specIdBig ? specIdBig : prodIdBig;
                        var stockUrl = "https://inv.mp.microsoft.com/v2.0/inventory/" + countryCode + "/" + stockUrlBigID + "/" + sid + "/" + availId;
                        (function(stockUrl, thisConsoleClass) {
                            return fetch(stockUrl)
                                .then(response => response.json())
                                .then(stockData => {
                                    var shipTimes = Object.keys(stockData.futureLots);
                                    var futureInstock = "";
                                    if (shipTimes.length > 0) {
                                        shipTimes.forEach(key => {
                                            futureInstock = stockData.futureLots[key]["9000000013"].inStock;
                                            if (futureInstock.toLowerCase() === "true") {
                                                return; // This breaks out of the forEach loop
                                            }
                                        });
                                    }
                                    var instock = stockData.availableLots["0001-01-01T00:00:00.0000000Z"]["9000000013"].inStock;
                                    if (futureInstock.toString().toLowerCase() === "false") {
                                        $(`${thisConsoleClass} .hatchProd`).removeClass("f-lightweight").addClass("f-heavyweight").css("color", "#054b16");
                                    }
                                    if ((instock.toLowerCase() !== "true") && (futureInstock.toString().toLowerCase() !== "true")) {
                                        console.log("OOS");
                                        apiData.Products[0].outOfStock = true;
                                        outOfStock();
                                    }
                                })
                                .catch(() => {
                                    apiData.Products[0].outOfStock = true;
                                    outOfStock();
                                });
                        })(stockUrl, thisConsoleClass).then(() => {
                            // Form JSON-LD Product data using API data for the current console
                            (function(sheetProductInfo, apiData, thisApiPrice, preorderURL, consoles_array_ind) {
                                popProductSchema(sheetProductInfo, apiData, thisApiPrice, preorderURL, consoles_array_ind);
                            })(sheetProductInfo, apiData, thisApiPrice, preorderURL, consoles_array_ind); 
                        });

                        $(`${thisConsoleClass} .addToCartBtn`).css("visibility", "visible").removeClass("hiddenImp");

                    }
                
                    function outOfStock() {
                        $(`${thisConsoleClass}.buyBox .purchButton`).attr("aria-label", "").removeAttr("href").removeAttr("data-retailer").addClass("disabled").attr("tabindex", "-1").attr("aria-disabled", "true").attr("role", "button").text(regionSoldout["keySoldout"].toUpperCase());

                        $(`${thisConsoleClass}.pageHero a:not(.c-hyperlink)`).attr("href", wtbURL).attr("aria-label", "").removeAttr("data-retailer");
                        $(`${thisConsoleClass}.pageHero a:not(.c-hyperlink) span`).text(retailerText);
                        
                        $(`${thisConsoleClass}.CTAdiv button`).attr("data-cta-href", wtbURL).attr("aria-label", "").removeAttr("data-retailer");
                        $(`${thisConsoleClass}.CTAdiv button span`).text(retailerText);

                        // Add back in retailer
                        $(`${thisConsoleClass} .text-erp`).show();
                        $(`${thisConsoleClass} .buy-group.retailer`).show();
                        $(`${thisConsoleClass}.buyBox p:not(.erp-disclaimer)`).show();
                        $(`${thisConsoleClass}.buyBox .purchase.retailer`).css("padding-top", "48px");
                    }
                
                    function hideDate() {
                        $(".availableDate").remove();
                    }
                
                    function buttonPreorder() {
                        var text = preordertext.locales[urlRegion].keyPreorder.toUpperCase();
                        $(".addToCartBtn").text(text);
                    }
                
                    $(`${thisConsoleClass} .purchButton`).show();
                    $(`${thisConsoleClass} .purchButtonPB`).show();
                
                }
        
                function addLegal() {
                    console.log("adding first legal");
                    if (sheetProductInfo.legal1.indexOf('*') !== -1) {
                            $(".legal div div").first().prepend('<p class="c-caption-1" id="price-legal"><i>' + sheetProductInfo.legal1 + '</i></p>');
                    } else {
                        $(".legal div div").after().append('<p class="c-caption-1" id="bcgg"><i>' + sheetProductInfo.legal1 + '</i></p>');
                    }
        
                    // if (sheetDataLoc[i].legal2 !== "") {
                    //     console.log("adding second legal");
                    //     $(".legal div div").first().append('<p class="c-caption-1"><i>' + sheetDataLoc[i].legal2 + '</i></p>');
                    // }
                    // if (sheetDataLoc[i].legal3 !== "") {
                    //     console.log("adding third legal");
                    //     $(".legal div div").first().append('<p class="c-caption-1"><i>' + sheetDataLoc[i].legal3 + '</i></p>');
                    // }
            }

            function popProductSchema(sheetProductInfo, apiData, apiPrice, preorderURL, consoles_array_ind) {

                var schemaAPIData = false;
                if (apiData) {
                    schemaAPIData = apiData.Products[0] ? true : false; // Check if API response is usable, otherwise we will use sheet and document data
                    productsArray[consoles_array_ind] = "";
                    // console.warn(`Adding API data for ${consoles_array[consoles_array_ind]}`);
                }

                // console.warn(`schemaAPIData is ${schemaAPIData} and apiData is: `);
                // console.warn(apiData);
       
                var productData = "";
       
                var productName = sheetProductInfo.product;
       
                var productImage = !sheetProductInfo.image.startsWith("#") ? sheetProductInfo.image : "";
       
                var productDescription = $("meta[name='description']")[0].content;
                if (schemaAPIData) {
                    productDescription = apiData.Products[0].LocalizedProperties[0].ShortDescription || apiData.Products[0].LocalizedProperties[0].ProductDescription || "";
                }
                
                var productURL = sheetProductInfo.detailsURL || window.location.href;
                if ((sheetProductInfo.gaPid.indexOf("#") === -1 && sheetProductInfo.gaPid.length > 1 && !sheetProductInfo.gaPid.startsWith("XXXXX")) || (sheetProductInfo.specPid.indexOf("#") === -1 && sheetProductInfo.specPid.length > 1  && !sheetProductInfo.specPid.startsWith("XXXXX"))) {
                    productURL = preorderURL;
                }
                 
                var productCurrency = priceFormat ? priceFormat.locales[urlRegion].keyCurrencyCode : countryCode;
                if (schemaAPIData) {
                    productCurrency = apiData.Products[0].DisplaySkuAvailabilities[0].Availabilities[0].OrderManagementData.Price.CurrencyCode || "";
                }
       
                var productPrice = apiPrice.list || sheetProductInfo.priceText;
                if (isNaN(productPrice)) {
                    productPrice = "";
                }

                var productAvailability = "https://schema.org/InStock";
                productAvailability = sheetProductInfo.soldOut === "t" ? "https://schema.org/SoldOut" : productAvailability;
                if (schemaAPIData) {
                    productAvailability = apiData.Products[0].outOfStock ? "https://schema.org/SoldOut" : productAvailability;
                }
       
                var isPreorder = false;
                if (schemaAPIData) {
                    isPreorder = apiData.Products[0].DisplaySkuAvailabilities[0].Sku.Properties.IsPreOrder || "false";
                } else if (sheetProductInfo.releaseDate) {
                    var releaseDate = new Date(sheetProductInfo.releaseDate);
                    var currentDate = new Date();
                    if (releaseDate > currentDate) {
                        isPreorder = true;
                    }
                }  
      
                if (isPreorder.toString().toLowerCase() === "true") {
                    productAvailability = "https://schema.org/PreOrder";
                }

                productData =
                        '{' + 
                            '"@type": "Product",' +
                            '"name": "' + productName + '",' +
                            '"image": "' + productImage + '",' +
                            '"description": "' + productDescription + '",' +
                            '"brand": {' +
                                '"@type": "Brand",' +
                                '"name": "Xbox"' +
                            '},' +
                            '"offers": {' +
                                '"@type": "Offer",' +
                                '"url": "' + productURL + '",' +
                                '"priceCurrency": "' + productCurrency + '",' +
                                '"price": "' + productPrice + '",' +
                                '"availability": "' + productAvailability + '"' +
                            '}' +
                        '}';

                productsArray[consoles_array_ind] = productData;

                // console.warn(`productsArray length is ${productsArray.length} and consoles_array length is ${consoles_array.length}`);
                // console.warn(productsArray);
                
                if(productsArray.length === consoles_array.length && !productsArray.includes(undefined)) {
                    // console.warn("All products have been added to the array, adding schema");
                    var popProductStructuredData = (function() {
                        // Use static schema for US -- use ignoreApi class if manually adding to the DOM
                        if (urlRegion === 'en-us') {
                            productsArray = [
                                '{' +
                                '"@type": "Product",' +
                                '"@id": "https://www.xbox.com/en-US/consoles/xbox-series-s-512gb-all-digital-robot-white",' +
                                '"name": "Xbox Series S - 512GB All-Digital Robot White",' +
                                '"description": "Xbox Series S is designed for disc-free gaming at 1440p (with the ability to upscale to 4K) and you can choose between 512GB SSD or 1TB SSD.",' +
                                '"url": "https://www.xbox.com/en-US/consoles/xbox-series-s",' +
                                '"image": "https://assets.xboxservices.com/assets/bf/b0/bfb06f23-4c87-4c58-b4d9-ed25d3a739b9.png?n=389964_Hero-Gallery-0_A1_857x676.png",' +
                                '"brand": {' +
                                    '"@type": "Thing",' +
                                    '"name": "Xbox"' +
                                '},' +
                                '"offers": {' +
                                    '"@type": "Offer",' +
                                    '"url": "https://www.xbox.com/en-US/consoles/xbox-series-s",' +
                                    '"priceCurrency": "USD",' +
                                    '"price": "299.99",' +
                                    '"availability": "http://schema.org/InStock",' +
                                    '"shippingDetails": {' +
                                    '"@type": "OfferShippingDetails",' +
                                    '"deliveryTime": {' +
                                        '"@type": "ShippingDeliveryTime",' +
                                        '"businessDays": {' +
                                        '"@type": "OpeningHoursSpecification",' +
                                        '"dayOfWeek": [' +
                                            '"https://schema.org/Monday",' +
                                            '"https://schema.org/Tuesday",' +
                                            '"https://schema.org/Wednesday",' +
                                            '"https://schema.org/Thursday",' +
                                            '"https://schema.org/Friday"' +
                                        ']' +
                                        '},' +
                                        '"transitTime": {' +
                                        '"@type": "QuantitativeValue",' +
                                        '"minValue": 2,' +
                                        '"maxValue": 3,' +
                                        '"unitCode": "d"' +
                                        '}' +
                                    '}' +
                                    '}' +
                                '}' +
                                '}',
                                '{' +
                                '"@type": "Product",' +
                                '"@id": "https://www.xbox.com/en-US/consoles/xbox-series-s-1tb-all-digital-carbon-black",' +
                                '"name": "Xbox Series S - 1TB All-Digital Carbon Black",' +
                                '"description": "Xbox Series S is designed for disc-free gaming at 1440p (with the ability to upscale to 4K) and you can choose between 512GB SSD or 1TB SSD.",' +
                                '"url": "https://www.xbox.com/en-US/consoles/xbox-series-s#black1tb",' +
                                '"image": "https://assets.xboxservices.com/assets/35/37/353787c2-dc6c-4005-bec5-5a67317e3436.png?n=389964_Hero-Gallery-0_B1_857x676.png",' +
                                '"brand": {' +
                                    '"@type": "Thing",' +
                                    '"name": "Xbox"' +
                                '},' +
                                '"offers": {' +
                                    '"@type": "Offer",' +
                                    '"url": "https://www.xbox.com/en-US/consoles/xbox-series-s",' +
                                    '"priceCurrency": "USD",' +
                                    '"price": "349.99",' +
                                    '"availability": "http://schema.org/InStock",' +
                                    '"shippingDetails": {' +
                                    '"@type": "OfferShippingDetails",' +
                                    '"deliveryTime": {' +
                                        '"@type": "ShippingDeliveryTime",' +
                                        '"businessDays": {' +
                                        '"@type": "OpeningHoursSpecification",' +
                                        '"dayOfWeek": [' +
                                            '"https://schema.org/Monday",' +
                                            '"https://schema.org/Tuesday",' +
                                            '"https://schema.org/Wednesday",' +
                                            '"https://schema.org/Thursday",' +
                                            '"https://schema.org/Friday"' +
                                        ']' +
                                        '},' +
                                        '"transitTime": {' +
                                        '"@type": "QuantitativeValue",' +
                                        '"minValue": 2,' +
                                        '"maxValue": 3,' +
                                        '"unitCode": "d"' +
                                        '}' +
                                    '}' +
                                    '}' +
                                '}' +
                                '}',
                                '{' +
                                '"@type": "Product",' +
                                '"@id": "https://www.xbox.com/en-US/consoles/xbox-series-s-1tb-all-digital-robot-white",' +
                                '"name": "Xbox Series S - 1TB All-Digital Robot White",' +
                                '"description": "Xbox Series S is designed for disc-free gaming at 1440p (with the ability to upscale to 4K) and you can choose between 512GB SSD or 1TB SSD.",' +
                                '"url": "https://www.xbox.com/en-US/consoles/xbox-series-s#white1tb",' +
                                '"image": "https://assets.xboxservices.com/assets/92/29/9229d987-5159-4ff9-aa2d-17ae117234f1.png?n=389964_Hero-Gallery-0_C1_857x676.png",' +
                                '"brand": {' +
                                    '"@type": "Thing",' +
                                    '"name": "Xbox"' +
                                '},' +
                                '"offers": {' +
                                    '"@type": "Offer",' +
                                    '"url": "https://www.xbox.com/en-US/consoles/xbox-series-s",' +
                                    '"priceCurrency": "USD",' +
                                    '"price": "349.99",' +
                                    '"availability": "http://schema.org/InStock",' +
                                    '"shippingDetails": {' +
                                    '"@type": "OfferShippingDetails",' +
                                    '"deliveryTime": {' +
                                        '"@type": "ShippingDeliveryTime",' +
                                        '"businessDays": {' +
                                        '"@type": "OpeningHoursSpecification",' +
                                        '"dayOfWeek": [' +
                                            '"https://schema.org/Monday",' +
                                            '"https://schema.org/Tuesday",' +
                                            '"https://schema.org/Wednesday",' +
                                            '"https://schema.org/Thursday",' +
                                            '"https://schema.org/Friday"' +
                                        ']' +
                                        '},' +
                                        '"transitTime": {' +
                                        '"@type": "QuantitativeValue",' +
                                        '"minValue": 2,' +
                                        '"maxValue": 3,' +
                                        '"unitCode": "d"' +
                                        '}' +
                                    '}' +
                                    '}' +
                                '}' +
                                '}'
                            ];
                        }
                        
                        const fullSchema = '{"@context": "http://schema.org","@graph": [' + 
                                            productsArray.join(",") + 
                                            ']}';
                        
                        const schemaElem = $("#product-schema")[0] || $('<sc' + 'ript type="application/ld+json" id="product-schema">' + '</sc' + 'ript>').appendTo("body");
                        
                        $(schemaElem).not(".ignoreApi").html(fullSchema);
                        
                    })();
                }
                }

        }
        
        // console.timeEnd("__DEBUG: Total execution time");
  
    })();

});

// Price Formatter
function formatCurrency(price, format) {
    var formattedPrice = "" + price;
    if (!format.keyHasDecimal) {
        formattedPrice = formattedPrice.split(".")[0];
    } else if (formattedPrice.split(".")[1] == null) {
        // Function Change 1/10/23
        formattedPrice = formattedPrice.split(".")[0] + ".00";
    }
    if (formattedPrice.split(".")[0].length > 3) { // Needs to figure out thousands
        //console.log("splitting thousands");
        if (!format.keyHasDecimal) {
            formattedPrice = formattedPrice.substring(0, formattedPrice.length - 3) + "*" + formattedPrice.substring(formattedPrice.length - 3, formattedPrice.length);
        } else {
            formattedPrice = formattedPrice.substring(0, formattedPrice.length - 6) + "*" + formattedPrice.substring(formattedPrice.length - 6, formattedPrice.length);
        }
    }
    if (formattedPrice.split(".")[0].length > 7) { // Needs to figure out millions
        //console.log("splitting millions");
        if (!format.keyHasDecimal) {
            formattedPrice = formattedPrice.substring(0, formattedPrice.length - 7) + "MMM" + formattedPrice.substring(formattedPrice.length - 7, formattedPrice.length);
        } else {
            formattedPrice = formattedPrice.substring(0, formattedPrice.length - 10) + "MMM" + formattedPrice.substring(formattedPrice.length - 10, formattedPrice.length);
        }
    }

    if (format.keyThousandCharacter === ",") {
        //console.log("replacing thousand");
        formattedPrice = formattedPrice.replace("*", format.keyThousandCharacter);
        formattedPrice = formattedPrice.replace("MMM", format.keyThousandCharacter);
    } else {
        //console.log("replacing period");
        formattedPrice = formattedPrice.replace(".", ",");
        formattedPrice = formattedPrice.replace("*", format.keyThousandCharacter);
        formattedPrice = formattedPrice.replace("MMM", format.keyThousandCharacter);
    }

    if (urlRegion === "en-sg") {
        if (formattedPrice.split(".")[1].length <= 1) {
            formattedPrice = formattedPrice + "0"
        }
    }

    formattedPrice = "" + format.keyPriceFormat.replace("#", formattedPrice);

    return formattedPrice;
}

// Strings
var preordertext = {
    "locales": {
        "en-us": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "ar-ae": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "ar-sa": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "cs-cz": {
            "keyPreorder": "Předobjednat","keyBuynow": "KOUPIT"
        },
        "da-dk": {
            "keyPreorder": "Forudbestil","keyBuynow": "KØB NU"
        },
        "de-at": {
            "keyPreorder": "Vorbestellen","keyBuynow": "JETZT KAUFEN"
        },
        "de-ch": {
            "keyPreorder": "Vorbestellen","keyBuynow": "JETZT KAUFEN"
        },
        "de-de": {
            "keyPreorder": "Vorbestellen","keyBuynow": "JETZT KAUFEN"
        },
        "el-gr": {
            "keyPreorder": "Προπαραγγελία","keyBuynow": "ΑΓΟΡΑ ΤΩΡΑ"
        },
        "en-au": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "en-ca": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "en-gb": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "en-hk": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "en-ie": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "en-in": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "en-nz": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "en-sg": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "en-za": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "es-ar": {
            "keyPreorder": "Reservar","keyBuynow": "COMPRAR AHORA"
        },
        "es-cl": {
            "keyPreorder": "Reservar","keyBuynow": "COMPRAR AHORA"
        },
        "es-co": {
            "keyPreorder": "Reservar","keyBuynow": "COMPRAR AHORA"
        },
        "es-es": {
            "keyPreorder": "Reservar","keyBuynow": "COMPRAR AHORA"
        },
        "es-mx": {
            "keyPreorder": "Reservar","keyBuynow": "COMPRAR AHORA"
        },
        "fi-fi": {
            "keyPreorder": "Tilaa ennakkoon","keyBuynow": "OSTA HETI"
        },
        "fr-be": {
            "keyPreorder": "Précommander","keyBuynow": "ACHETER MAINTENANT"
        },
        "fr-ca": {
            "keyPreorder": "Précommander","keyBuynow": "MAGASINER TOUT"
        },
        "fr-fr": {
            "keyPreorder": "Précommander","keyBuynow": "ACHETER MAINTENANT"
        },
        "fr-ch": {
            "keyPreorder": "Précommander","keyBuynow": "ACHETER MAINTENANT"
        },
        "he-il": {
            "keyPreorder": "Pre-order","keyBuynow": "BUY NOW"
        },
        "hu-hu": {
            "keyPreorder": "Előrendelés","keyBuynow": "VÁSÁRLÁS MOST"
        },
        "it-it": {
            "keyPreorder": "Preordina","keyBuynow": "ACQUISTA ORA"
        },
        "ja-jp": {
            "keyPreorder": "予約","keyBuynow": "今すぐ購入"
        },
        "ko-kr": {
            "keyPreorder": "미리 주문하기","keyBuynow": "지금 구매"
        },
        "nb-no": {
            "keyPreorder": "Forhåndsbestill","keyBuynow": "KJØP NÅ"
        },
        "nl-be": {
            "keyPreorder": "Reserveer","keyBuynow": "KOOP NU"
        },
        "nl-nl": {
            "keyPreorder": "Reserveer","keyBuynow": "KOOP NU"
        },
        "pl-pl": {
            "keyPreorder": "przedsprzedaż","keyBuynow": "KUP TERAZ"
        },
        "pt-br": {
            "keyPreorder": "Pré-venda","keyBuynow": "COMPRE AGORA"
        },
        "pt-pt": {
            "keyPreorder": "Pré-encomendar","keyBuynow": "COMPRAR AGORA"
        },
        "ru-ru": {
            "keyPreorder": "Предзаказ","keyBuynow": "КУПИТЬ"
        },
        "sk-sk": {
            "keyPreorder": "Rezervovať","keyBuynow": "KÚPIŤ"
        },
        "sv-se": {
            "keyPreorder": "Förbeställ","keyBuynow": "KÖP NU"
        },
        "tr-tr": {
            "keyPreorder": "Ön sipariş verin","keyBuynow": "ŞİMDİ ALIN"
        },
        "zh-cn": {
            "keyPreorder": "预订","keyBuynow": "立即購買"
        },
        "zh-hk": {
            "keyPreorder": "預先訂購","keyBuynow": "立即購買"
        },
        "zh-tw": {
            "keyPreorder": "預購","keyBuynow": "立即購買"
        }
    }
}

var interstitialText = {
    "locales": {
        "en-us": {
            "KeyInterstitial": "XboxOneInterstitial"
        },
        "ar-ae": {
            "KeyInterstitial": ""
        },
        "ar-sa": {
            "KeyInterstitial": ""
        },
        "cs-cz": {
            "KeyInterstitial": "X1SGenericInterstitial"
        },
        "da-dk": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "de-at": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "de-ch": {
            "KeyInterstitial": "x1sgenericinterstitial"
        },
        "de-de": {
            "KeyInterstitial": "X1XInterstitial"
        },
        "el-gr": {
            "KeyInterstitial": ""
        },
        "en-au": {
            "KeyInterstitial": "Xboxoneconsoles500gbinterstitial"
        },
        "en-ca": {
            "KeyInterstitial": "xboxoneconsolenonrefurbinterstitial "
        },
        "en-gb": {
            "KeyInterstitial": "X1GenericInterstitial"
        },
        "en-hk": {
            "KeyInterstitial": ""
        },
        "en-ie": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "en-in": {
            "KeyInterstitial": ""
        },
        "en-nz": {
            "KeyInterstitial": "Xboxoneconsoles500gbinterstitial"
        },
        "en-sg": {
            "KeyInterstitial": "XboxInterstitial"
        },
        "en-za": {
            "KeyInterstitial": ""
        },
        "es-ar": {
            "KeyInterstitial": ""
        },
        "es-cl": {
            "KeyInterstitial": ""
        },
        "es-co": {
            "KeyInterstitial": ""
        },
        "es-es": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "es-mx": {
            "KeyInterstitial": ""
        },
        "fi-fi": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "fr-be": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "fr-ca": {
            "KeyInterstitial": "xboxoneconsolenonrefurbinterstitial "
        },
        "fr-fr": {
            "KeyInterstitial": "X1SGenericInterstitial"
        },
        "fr-ch": {
            "KeyInterstitial": "x1sgenericinterstitial"
        },
        "he-il": {
            "KeyInterstitial": ""
        },
        "hu-hu": {
            "KeyInterstitial": ""
        },
        "it-it": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "ja-jp": {
            "KeyInterstitial": ""
        },
        "ko-kr": {
            "KeyInterstitial": ""
        },
        "nb-no": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "nl-be": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "nl-nl": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "pl-pl": {
            "KeyInterstitial": "X1SGenericInterstitial"
        },
        "pt-br": {
            "KeyInterstitial": ""
        },
        "pt-pt": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "ru-ru": {
            "KeyInterstitial": ""
        },
        "sk-sk": {
            "KeyInterstitial": ""
        },
        "sv-se": {
            "KeyInterstitial": "XboxOneSInterstitial"
        },
        "tr-tr": {
            "KeyInterstitial": ""
        },
        "zh-cn": {
            "KeyInterstitial": ""
        },
        "zh-hk": {
            "KeyInterstitial": ""
        },
        "zh-tw": {
            "KeyInterstitial": ""
        }
    }
}

priceFormat = {
    "locales": {
        "en-us": {
            "keyPriceFormat": "$# ","keyHasDecimal": true,"keyCurrencyCode": "USD", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "ar-ae": {
            "keyPriceFormat": "AED #","keyHasDecimal": true,"keyCurrencyCode": "AED", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "ar-sa": {
            "keyPriceFormat": "SR #","keyHasDecimal": false,"keyCurrencyCode": "SAR", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "cs-cz": {
            "keyPriceFormat": "# Kč","keyHasDecimal": false,"keyCurrencyCode": "CZK", 
            "keyThousandCharacter": " ","keyErptext": " OMC*","keyPriceAria": "Přejděte na přečtení prohlášení o vyloučení odpovědnosti ohledně cen","keyLimitedTimeCopy": "*Časově omezená nabídka u vybraných prodejců. Ceny se mohou lišit.","keyRecurrenceCopy": "Prodáno za PLACEHOLDER v posledních 30 dnech", "keyFullprice": "Plná cena byla", "keyNewprice": "Nová cena je"
        },
        "da-dk": {
            "keyPriceFormat": "# kr","keyHasDecimal": true,"keyCurrencyCode": "DKK", 
            "keyThousandCharacter": ".","keyErptext": " ERP*","keyPriceAria": "Gå til juridisk ansvarsfraskrivelse for at få mere at vide om priser","keyLimitedTimeCopy": "*Andre tidsbegrænsede tilbud er tilgængelige hos deltagende forhandlere. Priserne kan variere.","keyRecurrenceCopy": "Solgt til PLACEHOLDER inden for de sidste 30 dage", "keyFullprice": "Fuld pris var", "keyNewprice": "Den nye pris er"
        },
        "de-at": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " Geschätzter Ladenpreis*","keyPriceAria": "Navigieren, um den Haftungsausschluss für Preise zu lesen","keyLimitedTimeCopy": "*Zeitlich begrenztes Angebot, bei teilnehmenden Händlern. Preise können variieren.","keyRecurrenceCopy": "Der niedrigste Preis der letzten 30 Tage war PLACEHOLDER", "keyFullprice": "Der volle Preis betrug", "keyNewprice": "Neuer Preis:"
        },
        "de-ch": {
            "keyPriceFormat": "CHF #","keyHasDecimal": true,"keyCurrencyCode": "CHF", 
            "keyThousandCharacter": ",","keyErptext": " Geschätzter Ladenpreis*","keyPriceAria": "Navigieren, um den Haftungsausschluss für Preise zu lesen","keyLimitedTimeCopy": "*Zeitlich begrenztes Angebot, bei teilnehmenden Händlern. Preise können variieren.","keyRecurrenceCopy": "In den letzten 30 Tagen für PLACEHOLDER verkauft", "keyFullprice": "Der volle Preis betrug", "keyNewprice": "Neuer Preis:"
        },
        "de-de": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " Geschätzter Ladenpreis*","keyPriceAria": "Navigieren, um den Haftungsausschluss für Preise zu lesen","keyLimitedTimeCopy": "*Zeitlich begrenztes Angebot, bei teilnehmenden Händlern. Preise können variieren.","keyRecurrenceCopy": "Der niedrigste Preis der letzten 30 Tage war PLACEHOLDER", "keyFullprice": "Der volle Preis betrug", "keyNewprice": "Neuer Preis:"
        },
        "el-gr": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " ERP*","keyPriceAria": "Πλοηγηθείτε για να διαβάσετε την αποποίηση ευθυνών σχετικά με τις τιμές","keyLimitedTimeCopy": "*Προσφορά περιορισμένης χρονικής διάρκειας σε καταστήματα λιανικής που συμμετέχουν στο πρόγραμμα. Οι τιμές ενδέχεται να διαφέρουν.","keyRecurrenceCopy": "Πωλήσεις για PLACEHOLDER τις τελευταίες 30 ημέρες", "keyFullprice": "Προηγούμενη τιμή:", "keyNewprice": "Η νέα τιμή είναι"
        },
        "en-au": {
            "keyPriceFormat": "$# ","keyHasDecimal": true,"keyCurrencyCode": "AUD", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "en-ca": {
            "keyPriceFormat": "$# ","keyHasDecimal": true,"keyCurrencyCode": "CAD", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "en-gb": {
            "keyPriceFormat": "£#","keyHasDecimal": true,"keyCurrencyCode": "GBP", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "en-hk": {
            "keyPriceFormat": "HK$#","keyHasDecimal": true,"keyCurrencyCode": "HKD", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "en-ie": {
            "keyPriceFormat": "€ #","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "en-in": {
            "keyPriceFormat": "₹ #","keyHasDecimal": true,"keyCurrencyCode": "INR", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "en-nz": {
            "keyPriceFormat": "$# ","keyHasDecimal": true,"keyCurrencyCode": "NZD", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "en-sg": {
            "keyPriceFormat": "SG$#","keyHasDecimal": true,"keyCurrencyCode": "SGD", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "en-za": {
            "keyPriceFormat": "R#","keyHasDecimal": true,"keyCurrencyCode": "ZAR", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "es-ar": {
            "keyPriceFormat": "$ #","keyHasDecimal": false,"keyCurrencyCode": "ARS", 
            "keyThousandCharacter": ".","keyErptext": " PVP*","keyPriceAria": "Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "*Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden cambiar.","keyRecurrenceCopy": "Vendido por PLACEHOLDER en los últimos 30 días", "keyFullprice": "El precio original era", "keyNewprice": "El nuevo precio es"
        },
        "es-cl": {
            "keyPriceFormat": "$#","keyHasDecimal": false,"keyCurrencyCode": "CLP", 
            "keyThousandCharacter": ".","keyErptext": " PVP*","keyPriceAria": "Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "*Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden cambiar.","keyRecurrenceCopy": "Vendido por PLACEHOLDER en los últimos 30 días", "keyFullprice": "El precio original era", "keyNewprice": "El nuevo precio es"
        },
        "es-co": {
            "keyPriceFormat": "$#","keyHasDecimal": false,"keyCurrencyCode": "COP", 
            "keyThousandCharacter": ".","keyErptext": " PVP*","keyPriceAria": "Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "*Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden cambiar.","keyRecurrenceCopy": "Vendido por PLACEHOLDER en los últimos 30 días", "keyFullprice": "El precio original era", "keyNewprice": "El nuevo precio es"
        },
        "es-es": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " PVP*","keyPriceAria": "Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "*Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden variar.","keyRecurrenceCopy": "Precio más bajo últimos 30 días: PLACEHOLDER", "keyFullprice": "El precio original era", "keyNewprice": "El nuevo precio es"
        },
        "es-mx": {
            "keyPriceFormat": "$#","keyHasDecimal": false,"keyCurrencyCode": "MXN", 
            "keyThousandCharacter": ",","keyErptext": " PVP*","keyPriceAria": "Navega para leer el aviso de declinación de responsabilidades sobre los precios","keyLimitedTimeCopy": "*Oferta por tiempo limitado, en los distribuidores participantes. Los precios pueden cambiar.","keyRecurrenceCopy": "Vendido por PLACEHOLDER en los últimos 30 días", "keyFullprice": "El precio original era", "keyNewprice": "El nuevo precio es"
        },
        "fi-fi": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " ERP*","keyPriceAria": "Siirry lukemaan hintoja koskeva vastuuvapauslauseke","keyLimitedTimeCopy": "*Tarjous voimassa rajoitetun ajan tietyillä jälleenmyyjillä. Hinnat voivat vaihdella.","keyRecurrenceCopy": "Myyty PLACEHOLDER:lla viimeisen 30 päivän aikana", "keyFullprice": "Normaalihinta oli", "keyNewprice": "Uusi hinta on"
        },
        "fr-be": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " Prix de revente estimé*","keyPriceAria": "Naviguez pour lire la clause de non-responsabilité concernant les prix","keyLimitedTimeCopy": "*Offre à durée limitée dans les points de vente participants. Les prix peuvent varier.","keyRecurrenceCopy": "Prix le plus bas pratiqué au cours des 30 derniers jours : PLACEHOLDER", "keyFullprice": "Prix plein de", "keyNewprice": "Le nouveau prix s’élève à"
        },
        "fr-ca": {
            "keyPriceFormat": "# $","keyHasDecimal": true,"keyCurrencyCode": "CAD", 
            "keyThousandCharacter": ".","keyErptext": " PDE*","keyPriceAria": "Naviguer pour lire l’avis de non-responsabilité relatif aux prix","keyLimitedTimeCopy": "*Offre d’une durée limitée chez les détaillants participants. Les prix peuvent varier.","keyRecurrenceCopy": "Vendu pour PLACEHOLDER au cours des 30 derniers jours", "keyFullprice": "Le prix régulier est de", "keyNewprice": "Le nouveau prix est"
        },
        "fr-ch": {
            "keyPriceFormat": "CHF #","keyHasDecimal": true,"keyCurrencyCode": "CHF", 
            "keyThousandCharacter": ",","keyErptext": " Prix de revente estimé*","keyPriceAria": "Naviguez pour lire la clause de non-responsabilité concernant les prix","keyLimitedTimeCopy": "*Offre à durée limitée dans les points de vente participants. Les prix peuvent varier.","keyRecurrenceCopy": "Vendu pour PLACEHOLDER au cours des 30 derniers jours", "keyFullprice": "Prix plein de", "keyNewprice": "Le nouveau prix s’élève à"
        },
        "fr-fr": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " Prix de revente estimé*","keyPriceAria": "Naviguez pour lire la clause de non-responsabilité concernant les prix","keyLimitedTimeCopy": "*Offre à durée limitée dans les points de vente participants. Les prix peuvent varier.","keyRecurrenceCopy": "Prix le plus bas pratiqué au cours des 30 derniers jours : PLACEHOLDER", "keyFullprice": "Prix plein de", "keyNewprice": "Le nouveau prix s’élève à"
        },
        "he-il": {
            "keyPriceFormat": "₪‎#","keyHasDecimal": true,"keyCurrencyCode": "ILS", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Navigate to read disclaimer about prices","keyLimitedTimeCopy": "*Limited time offer at participating retailers. Prices may vary.","keyRecurrenceCopy": "Sold for PLACEHOLDER in the last 30 days", "keyFullprice": "Full price was", "keyNewprice": "New price is"
        },
        "hu-hu": {
            "keyPriceFormat": "# HUF","keyHasDecimal": true,"keyCurrencyCode": "HUF", 
            "keyThousandCharacter": ",","keyErptext": " Becsült fogyasztói ár*","keyPriceAria": "Navigálj az árakkal kapcsolatos jogi nyilatkozat elolvasásához","keyLimitedTimeCopy": "*Korlátozott ideig rendelkezésre álló akció a részt vevő viszonteladóknál. Az árak változhatnak.","keyRecurrenceCopy": "Eladva PLACEHOLDER részére az elmúlt 30 napban", "keyFullprice": "Eredeti ár:", "keyNewprice": "Az új ár:"
        },
        "it-it": {
            "keyPriceFormat": "€#","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " Prezzo stimato*","keyPriceAria": "Passa alle note legali relative ai prezzi","keyLimitedTimeCopy": "*Offerta limitata nel tempo presso i rivenditori partecipanti. I prezzi possono variare.","keyRecurrenceCopy": "Prezzo più basso degli ultimi 30 giorni: PLACEHOLDER", "keyFullprice": "Il prezzo intero era", "keyNewprice": "Il nuovo prezzo è"
        },
        "ja-jp": {
            "keyPriceFormat": "# 円 (税込)","keyHasDecimal": false,"keyCurrencyCode": "JPY", 
            "keyThousandCharacter": ",","keyErptext": " 推定小売価格*","keyPriceAria": "移動して価格に関する免責事項を読む","keyLimitedTimeCopy": "*特定の販売店にて期間限定で提供しています 実際の販売価格は販売店により決定されます。","keyRecurrenceCopy": "", "keyFullprice": "通常価格は", "keyNewprice": "新しい価格は"
        },
        "ko-kr": {
            "keyPriceFormat": "₩#","keyHasDecimal": false,"keyCurrencyCode": "KRW", 
            "keyThousandCharacter": ",","keyErptext": " 예상 소매 가격*","keyPriceAria": "가격 고지 사항으로 이동하여 읽기","keyLimitedTimeCopy": "*가맹 판매점에서 기간 한정 혜택 가격은 변동될 수 있습니다.","keyRecurrenceCopy": "", "keyFullprice": "F정가", "keyNewprice": "할인가"
        },
        "nb-no": {
            "keyPriceFormat": "# kr","keyHasDecimal": true,"keyCurrencyCode": "NOK", 
            "keyThousandCharacter": ".","keyErptext": " ERP*","keyPriceAria": "Gå til for å lese ansvarsfraskrivelse om priser","keyLimitedTimeCopy": "*Tidsbegrenset tilbud hos deltagende forhandlere. Prisene kan variere.","keyRecurrenceCopy": "", "keyFullprice": "Full pris var", "keyNewprice": "Ny pris er"
        },
        "nl-be": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " ERP*","keyPriceAria": "Ga naar de disclaimer over prijzen","keyLimitedTimeCopy": "*Aanbieding beperkte tijd geldig bij deelnemende verkopers. Prijzen kunnen variëren.","keyRecurrenceCopy": "Laagste prijs in de afgelopen 30 dagen: PLACEHOLDER", "keyFullprice": "Volledige prijs was", "keyNewprice": "De nieuwe prijs is"
        },
        "nl-nl": {
            "keyPriceFormat": "€ #","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " ERP*","keyPriceAria": "Ga naar de disclaimer over prijzen","keyLimitedTimeCopy": "*Aanbieding beperkte tijd geldig bij deelnemende verkopers. Prijzen kunnen variëren.","keyRecurrenceCopy": "Laagste prijs in de afgelopen 30 dagen: PLACEHOLDER", "keyFullprice": "Volledige prijs was", "keyNewprice": "De nieuwe prijs is"
        },
        "pl-pl": {
            "keyPriceFormat": "# zł","keyHasDecimal": true,"keyCurrencyCode": "PLN", 
            "keyThousandCharacter": " ","keyErptext": " ERP*","keyPriceAria": "Przejdź, aby przeczytać zastrzeżenie dotyczące cennika","keyLimitedTimeCopy": "*Oferta ograniczona czasowo dostępna u uczestniczących w programie sprzedawców. Ceny mogą się różnić.","keyRecurrenceCopy": "Sprzedawano w cenie PLACEHOLDER w ciągu ostatnich 30 dni", "keyFullprice": "Pełna cena:", "keyNewprice": "Nowa cena to"
        },
        "pt-br": {
            "keyPriceFormat": "R$ #","keyHasDecimal": false,"keyCurrencyCode": "BRL", 
            "keyThousandCharacter": ".","keyErptext": " ERP*","keyPriceAria": "Navegue para ler o aviso de isenção de responsabilidade dos preços","keyLimitedTimeCopy": "*Oferta de tempo limitado nas lojas participantes. Os preços podem variar.","keyRecurrenceCopy": "Vendido para PLACEHOLDER nos últimos 30 dias", "keyFullprice": "O preço normal era", "keyNewprice": "O novo preço é"
        },
        "pt-pt": {
            "keyPriceFormat": "#€","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ".","keyErptext": " ERP*","keyPriceAria": "Navega para leres a exclusão de responsabilidade sobre os preços","keyLimitedTimeCopy": "*Oferta de duração limitada nos revendedores participantes. Os preços podem variar","keyRecurrenceCopy": "Preço mais baixo nos últimos 30 dias: PLACEHOLDER", "keyFullprice": "O preço era", "keyNewprice": "O novo preço é"
        },
        "ru-ru": {
            "keyPriceFormat": "# ₽","keyHasDecimal": true,"keyCurrencyCode": "RUB", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Перейдите, чтобы прочитать заявление об отказе от ответственности в отношении цен","keyLimitedTimeCopy": "*Предложение действует ограниченное время и доступно через участвующих в акции розничных продавцов. Цены могут отличаться.","keyRecurrenceCopy": "", "keyFullprice": "Полная цена была", "keyNewprice": "Новая цена —"
        },
        "sk-sk": {
            "keyPriceFormat": "# €","keyHasDecimal": true,"keyCurrencyCode": "EUR", 
            "keyThousandCharacter": ",","keyErptext": " OMC*","keyPriceAria": "Prejdite na vyhlásenie o cenách a prečítajte si ho","keyLimitedTimeCopy": "*U participujúcich maloobchodníkov môže byť k dispozícii ďalšia časovo obmedzená ponuka. Ceny sa môžu líšiť.","keyRecurrenceCopy": "Predané za PLACEHOLDER za posledných 30 dní", "keyFullprice": "Plná cena:", "keyNewprice": "Nová cena je"
        },
        "sv-se": {
            "keyPriceFormat": "# kr","keyHasDecimal": true,"keyCurrencyCode": "SEK", 
            "keyThousandCharacter": ".","keyErptext": " rek-pris*","keyPriceAria": "Navigera för att läsa ansvarsfriskrivning om priser","keyLimitedTimeCopy": "*Begränsat erbjudande hos deltagande återförsäljare. Priserna kan variera.","keyRecurrenceCopy": "Sålts för PLACEHOLDER under de senaste 30 dagarna", "keyFullprice": "Fullt pris", "keyNewprice": "Nytt pris är"
        },
        "tr-tr": {
            "keyPriceFormat": "# ₺","keyHasDecimal": true,"keyCurrencyCode": "TRY", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "Fiyatlar hakkındaki yasal uyarıyı okumak için gidin","keyLimitedTimeCopy": "*Sınırlı süreli teklif, katılan satıcılarda geçerlidir. Fiyatlar değişiklik gösterebilir.","keyRecurrenceCopy": "", "keyFullprice": "Tam ücret", "keyNewprice": "Yeni fiyat:"
        },
        "zh-hk": {
            "keyPriceFormat": "HK$#","keyHasDecimal": true,"keyCurrencyCode": "HKD", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "瀏覽以閱讀關於價格的免責聲明","keyLimitedTimeCopy": "*限時優惠由合作零售商發售。價格或有差異。","keyRecurrenceCopy": "", "keyFullprice": "原價為", "keyNewprice": "新價格是"
        },
        "zh-tw": {
            "keyPriceFormat": "NT$#","keyHasDecimal": false,"keyCurrencyCode": "TWD", 
            "keyThousandCharacter": ",","keyErptext": " ERP*","keyPriceAria": "瀏覽以閱讀有關價格的免責聲明","keyLimitedTimeCopy": "*限時優惠只在參與的零售商提供。售價可能不同。","keyRecurrenceCopy": "", "keyFullprice": "原價為", "keyNewprice": "新價格為"
        }
    }
}

globalSoldout = {
    "locales": {
        "en-us": {
            "keySoldout": "Sold Out"
        },
        "ar-ae": {
            "keySoldout": "Sold Out"
        },
        "ar-sa": {
            "keySoldout": "Sold Out"
        },
        "cs-cz": {
            "keySoldout": " Vyprodáno"
        },
        "da-dk": {
            "keySoldout": "Udsolgt"
        },
        "de-at": {
            "keySoldout": " Ausverkauft"
        },
        "de-ch": {
            "keySoldout": " Ausverkauft"
        },
        "de-de": {
            "keySoldout": " Ausverkauft"
        },
        "el-gr": {
            "keySoldout": " Έχει εξαντληθεί"
        },
        "en-au": {
            "keySoldout": "Sold Out"
        },
        "en-ca": {
            "keySoldout": "Sold Out"
        },
        "en-gb": {
            "keySoldout": "Sold Out"
        },
        "en-hk": {
            "keySoldout": "Sold Out"
        },
        "en-ie": {
            "keySoldout": "Sold Out"
        },
        "en-in": {
            "keySoldout": "Sold Out"
        },
        "en-nz": {
            "keySoldout": "Sold Out"
        },
        "en-sg": {
            "keySoldout": "Sold Out"
        },
        "en-za": {
            "keySoldout": "Sold Out"
        },
        "es-ar": {
            "keySoldout": "Agotado"
        },
        "es-cl": {
            "keySoldout": "Agotado"
        },
        "es-co": {
            "keySoldout": "Agotado"
        },
        "es-es": {
            "keySoldout": " Agotado"
        },
        "es-mx": {
            "keySoldout": "Agotado"
        },
        "fi-fi": {
            "keySoldout": " Loppuunmyyty"
        },
        "fr-be": {
            "keySoldout": " Épuisé"
        },
        "fr-ca": {
            "keySoldout": " En rupture de stock"
        },
        "fr-ch": {
            "keySoldout": " Épuisé"
        },
        "fr-fr": {
            "keySoldout": " Épuisé"
        },
        "he-il": {
            "keySoldout": "Sold Out"
        },
        "hu-hu": {
            "keySoldout": "Elfogyott"
        },
        "it-it": {
            "keySoldout": " Esaurito"
        },
        "ja-jp": {
            "keySoldout": " 完売"
        },
        "ko-kr": {
            "keySoldout": " 품절"
        },
        "nb-no": {
            "keySoldout": "Utsolgt "
        },
        "nl-be": {
            "keySoldout": "Uitverkocht"
        },
        "nl-nl": {
            "keySoldout": "Uitverkocht"
        },
        "pl-pl": {
            "keySoldout": " Wyprzedane"
        },
        "pt-br": {
            "keySoldout": " Esgotado"
        },
        "pt-pt": {
            "keySoldout": " Esgotado"
        },
        "ru-ru": {
            "keySoldout": " Распродано"
        },
        "sk-sk": {
            "keySoldout": " Vypredané"
        },
        "sv-se": {
            "keySoldout": " Utsåld"
        },
        "tr-tr": {
            "keySoldout": " Tükendi"
        },
        "zh-hk": {
            "keySoldout": "售罄"
        },
        "zh-tw": {
            "keySoldout": "售罄"
        }
    }
}

lmCopy = {
    "locales": {
        "en-us": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "ar-ae": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "ar-sa": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "cs-cz": {"keyLearnmore": "DALŠÍ INFORMACE","keyCheckAvail": "ZKONTROLOVAT DOSTUPNOST","keyRetailerText": "NAJDĚTE PRODEJCE"},
        "da-dk": {"keyLearnmore": "FÅ MERE AT VIDE","keyCheckAvail": "SE TILGÆNGELIGHED","keyRetailerText": "FIND EN FORHANDLER"},
        "de-at": {"keyLearnmore": "MEHR ERFAHREN","keyCheckAvail": "VERFÜGBARKEIT PRÜFEN","keyRetailerText": "HÄNDLER FINDEN"},
        "de-ch": {"keyLearnmore": "MEHR ERFAHREN","keyCheckAvail": "VERFÜGBARKEIT PRÜFEN","keyRetailerText": "HÄNDLER FINDEN"},
        "de-de": {"keyLearnmore": "MEHR ERFAHREN","keyCheckAvail": "VERFÜGBARKEIT PRÜFEN","keyRetailerText": "HÄNDLER FINDEN"},
        "el-gr": {"keyLearnmore": "ΜΑΘΕΤΕ ΠΕΡΙΣΣΟΤΕΡΑ","keyCheckAvail": "ΕΛΕΓΧΟΣ ΔΙΑΘΕΣΙΜΟΤΗΤΑΣ","keyRetailerText": "ΕΠΙΛΕΞΤΕ ΚΑΤΑΣΤΗΜΑ ΛΙΑΝΙΚΗΣ"},
        "en-au": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-ca": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-gb": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-hk": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-ie": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-in": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-nz": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-sg": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "en-za": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "es-ar": {"keyLearnmore": "MÁS INFORMACIÓN","keyCheckAvail": "COMPROBAR DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "es-cl": {"keyLearnmore": "MÁS INFORMACIÓN","keyCheckAvail": "COMPROBAR DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "es-co": {"keyLearnmore": "MÁS INFORMACIÓN","keyCheckAvail": "COMPROBAR DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "es-es": {"keyLearnmore": "DESCUBRE MÁS","keyCheckAvail": "COMPROBAR LA DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "es-mx": {"keyLearnmore": "MÁS INFORMACIÓN","keyCheckAvail": "COMPROBAR DISPONIBILIDAD","keyRetailerText": "BUSCAR UN COMERCIANTE"},
        "fi-fi": {"keyLearnmore": "LUE LISÄÄ","keyCheckAvail": "TARKISTA SAATAVUUS","keyRetailerText": "ETSI JÄLLEENMYYJÄ"},
        "fr-be": {"keyLearnmore": "EN SAVOIR PLUS","keyCheckAvail": "VOIR LES DISPONIBILITÉS","keyRetailerText": "TROUVER UN DISTRIBUTEUR"},
        "fr-ca": {"keyLearnmore": "EN SAVOIR PLUS","keyCheckAvail": "VÉRIFIER LA DISPONIBILITÉ","keyRetailerText": "TROUVER UN DÉTAILLANT"},
        "fr-ch": {"keyLearnmore": "EN SAVOIR PLUS","keyCheckAvail": "VOIR LES DISPONIBILITÉS","keyRetailerText": "TROUVER UN DISTRIBUTEUR"},
        "fr-fr": {"keyLearnmore": "EN SAVOIR PLUS","keyCheckAvail": "VOIR LES DISPONIBILITÉS","keyRetailerText": "TROUVER UN DISTRIBUTEUR"},
        "he-il": {"keyLearnmore": "LEARN MORE","keyCheckAvail": "CHECK AVAILABILITY","keyRetailerText": "FIND A RETAILER"},
        "hu-hu": {"keyLearnmore": "TOVÁBBI INFORMÁCIÓ","keyCheckAvail": "AZ ELÉRHETŐSÉG ELLENŐRZÉSE","keyRetailerText": "VISZONTELADÓ KERESÉSE"},
        "it-it": {"keyLearnmore": "SCOPRI DI PIÙ","keyCheckAvail": "VERIFICA LA DISPONIBILITÀ","keyRetailerText": "TROVA UN RIVENDITORE"},
        "ja-jp": {"keyLearnmore": "詳細について","keyCheckAvail": "利用可能か確認する","keyRetailerText": "販売店を見つける"},
        "ko-kr": {"keyLearnmore": "자세한 정보","keyCheckAvail": "플레이 가능성 확인","keyRetailerText": "매장 찾기"},
        "nb-no": {"keyLearnmore": "FINN UT MER","keyCheckAvail": "SJEKK TILGJENGELIGHET","keyRetailerText": "FINN EN FORHANDLER"},
        "nl-be": {"keyLearnmore": "MEER INFO","keyCheckAvail": "BESCHIKBAARHEID CONTROLEREN","keyRetailerText": "ZOEK EEN VERKOPER"},
        "nl-nl": {"keyLearnmore": "MEER INFO","keyCheckAvail": "BESCHIKBAARHEID CONTROLEREN","keyRetailerText": "ZOEK EEN VERKOPER"},
        "pl-pl": {"keyLearnmore": "DOWIEDZ SIĘ WIĘCEJ","keyCheckAvail": "SPRAWDŹ DOSTĘPNOŚĆ","keyRetailerText": "ZNAJDŹ SPRZEDAWCĘ"},
        "pt-br": {"keyLearnmore": "SAIBA MAIS","keyCheckAvail": "VERIFICAR DISPONIBILIDADE","keyRetailerText": "LOCALIZAR UM VAREJISTA"},
        "pt-pt": {"keyLearnmore": "SABER MAIS","keyCheckAvail": "VERIFICAR DISPONIBILIDADE","keyRetailerText": "LOCALIZAR UM REVENDEDOR"},
        "ru-ru": {"keyLearnmore": "ПОДРОБНОСТИ","keyCheckAvail": "ПРОВЕРКА ДОСТУПНОСТИ","keyRetailerText": "НАЙТИ ПРОДАВЦА"},
        "sk-sk": {"keyLearnmore": "ZISTIŤ VIAC","keyCheckAvail": "OVERIŤ DOSTUPNOSŤ","keyRetailerText": "VYHĽADAŤ PREDAJCU"},
        "sv-se": {"keyLearnmore": "LÄS MER","keyCheckAvail": "KOLLA TILLGÄNGLIGHETEN","keyRetailerText": "HITTA EN ÅTERFÖRSÄLJARE"},
        "tr-tr": {"keyLearnmore": "DAHA FAZLA BILGI EDININ","keyCheckAvail": "ERİŞİLEBİLİRLİĞİ KONTROL EDİN","keyRetailerText": "SATICI BULUN"},
        "zh-hk": {"keyLearnmore": "詳細介紹","keyCheckAvail": "檢查可用性","keyRetailerText": "尋找零售商"},
        "zh-tw": {"keyLearnmore": "詳細介紹","keyCheckAvail": "查看供應情形","keyRetailerText": "尋找零售商"
        }
    }
}
  
tempOos = {
    "locales": {
        "en-us": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "ar-ae": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "ar-sa": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "cs-cz": {"keyTemporarilyoutofstock": "Dočasně není skladem."},
        "da-dk": {"keyTemporarilyoutofstock": "Midlertidigt udsolgt."},
        "de-at": {"keyTemporarilyoutofstock": "Vorübergehend nicht auf Lager."},
        "de-ch": {"keyTemporarilyoutofstock": "Vorübergehend nicht auf Lager."},
        "de-de": {"keyTemporarilyoutofstock": "Vorübergehend nicht auf Lager."},
        "el-gr": {"keyTemporarilyoutofstock": "Προσωρινά χωρίς απόθεμα."},
        "en-au": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "en-ca": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "en-gb": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "en-hk": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "en-ie": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "en-in": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "en-nz": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "en-sg": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "en-za": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "es-ar": {"keyTemporarilyoutofstock": "Temporalmente fuera de stock."},
        "es-cl": {"keyTemporarilyoutofstock": "Temporalmente fuera de stock."},
        "es-co": {"keyTemporarilyoutofstock": "Temporalmente fuera de stock."},
        "es-es": {"keyTemporarilyoutofstock": "Temporalmente agotado."},
        "es-mx": {"keyTemporarilyoutofstock": "Temporalmente fuera de stock."},
        "fi-fi": {"keyTemporarilyoutofstock": "Tilapäisesti loppu."},
        "fr-be": {"keyTemporarilyoutofstock": "Temporairement en rupture de stock."},
        "fr-ca": {"keyTemporarilyoutofstock": "Temporairement en rupture de stock."},
        "fr-ch": {"keyTemporarilyoutofstock": "Temporairement en rupture de stock."},
        "fr-fr": {"keyTemporarilyoutofstock": "Temporairement en rupture de stock."},
        "he-il": {"keyTemporarilyoutofstock": "Temporarily out of stock."},
        "hu-hu": {"keyTemporarilyoutofstock": "Jelenleg nincs raktáron."},
        "it-it": {"keyTemporarilyoutofstock": "Temporaneamente esaurito."},
        "ja-jp": {"keyTemporarilyoutofstock": "ただいま在庫はありません。"},
        "ko-kr": {"keyTemporarilyoutofstock": "일시적으로 재고가 없습니다."},
        "nb-no": {"keyTemporarilyoutofstock": "Midlertidig utsolgt."},
        "nl-be": {"keyTemporarilyoutofstock": "Tijdelijk niet op voorraad."},
        "nl-nl": {"keyTemporarilyoutofstock": "Tijdelijk niet op voorraad."},
        "pl-pl": {"keyTemporarilyoutofstock": "Tymczasowo niedostępny."},
        "pt-br": {"keyTemporarilyoutofstock": "Temporariamente fora de estoque."},
        "pt-pt": {"keyTemporarilyoutofstock": "Temporariamente esgotado."},
        "ru-ru": {"keyTemporarilyoutofstock": "Временно нет в наличии."},
        "sk-sk": {"keyTemporarilyoutofstock": "Dočasne nie je na sklade."},
        "sv-se": {"keyTemporarilyoutofstock": "Tillfälligt slut."},
        "tr-tr": {"keyTemporarilyoutofstock": "Geçici olarak stokta yok."},
        "zh-hk": {"keyTemporarilyoutofstock": "暫時缺貨。"},
        "zh-tw": {"keyTemporarilyoutofstock": "暫時缺貨。"
        }
    }
}