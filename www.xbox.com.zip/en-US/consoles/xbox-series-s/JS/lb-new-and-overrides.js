function swapTheme() {
    var newWidth = $(window).outerWidth(true);
    if (newWidth > 767) {
        $(".pageHero, .staticHero, .icon-list-hero").addClass("theme-dark");
    } else {
        $(".pageHero, .staticHero, .icon-list-hero").removeClass("theme-dark");
    }

    if (newWidth > 1083) {
        $(".gallery-hero").addClass("theme-dark");
    } else {
        $(".gallery-hero").removeClass("theme-dark");
    }
}
$(window).on("load resize", function() {
    swapTheme();
});
swapTheme();