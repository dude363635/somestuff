$(document).ready(function() {
    var urlRegion = document.URL.split("/")[3].toLowerCase();
    var allXGPConsoleGames = "https://catalog.gamepass.com/sigls/v2?id=f6f1f99f-9b49-4ccd-b3bf-4d9767a77f5e&language=" + urlRegion + "&market=" + urlRegion.split("-")[1];
    
    fullGameArray = [];
    gameTitles = [];
    allGames = {};

    // Get GUIDS
    $.get(allXGPConsoleGames)
        .done(function(responseData) {
            listData = responseData;
            let idlength = listData.length
            for (let i = 1; i < idlength; i++) {
              if (listData[i].id !== "9N4CPQ4R2180"){
                fullGameArray.push(listData[i].id);
                allGames[listData[i].id] = {};
              }
            }
            GUID_pop(fullGameArray);
        });
    
    function GUID_pop(rawGuids) {
      chunktotal = Math.ceil(fullGameArray.length / 20)
      const countryCode = urlRegion.split("-")[1].toUpperCase();
      let guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
  
      var first12 = rawGuids.slice(0, 12)
      rawGuids = rawGuids.slice(12)

      var firstToUrl = first12.join(",");
      guidUrl = guidUrl.replace("GAMEIDS", firstToUrl)
      $.get(guidUrl)
          .done(function(responseData) {
              var apiData = responseData;
              makeAllGames(apiData, 0, firstToUrl);
              guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
              restPop();
          })

      function restPop() {
        var m, n, temparray, chunk = 20;
        var arrayCount = 1
        for (m = 0, n = rawGuids.length; m < n; m += chunk) {
          (function(m, n) {
            temparray = rawGuids.slice(m, m + chunk);
            var guidsToUrl = temparray.join(",");
            guidUrl = guidUrl.replace("GAMEIDS", guidsToUrl)

            $.get(guidUrl)
              .done(function(responseData) {
                var apiData = responseData;
                makeAllGames(apiData, arrayCount, guidsToUrl);
                arrayCount++
              })
            guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
          })(m, n);
        }
      }
    };
      


    function makeAllGames(data, count, bigidsgiven) {
      // var bigidUrls = biUrls.items.urls;
      // var biuArray = Object.keys(bigidUrls);
      let productQuantity = data.Products.length;

      for (var x = 0; x < productQuantity; x++) {
          // Item Id/Title
          var itemId = data.Products[x].ProductId.toUpperCase();
          var itemTitle = data.Products[x].LocalizedProperties[0].ProductTitle;
          if (itemTitle === undefined) {
              itemTitle = "";
          }
          var itemUrlName = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, "");
          if (itemUrlName === "") {
              itemUrlName = "-"
          }

          var imagesNum = data.Products[x].LocalizedProperties[0].Images.length;
          var imgEnd = 999;

          for (var j = 0; j < imagesNum; j++) {
              if (data.Products[x].LocalizedProperties[0].Images[j].ImagePurpose === "TitledHeroArt") {
                  imgEnd = j;
                  break;
              }
          }

          if (imgEnd === 999) {
              for (var j = 0; j < imagesNum; j++) {
                  if (data.Products[x].LocalizedProperties[0].Images[j].Width < data.Products[x].LocalizedProperties[0].Images[j].Height) {
                      imgEnd = j;
                      break
                  }
              }
          }

          if (imgEnd === 999) {
              imgEnd = 1;
          }

          // Grabbing Image Path
          if (data.Products[x].LocalizedProperties[0].Images[imgEnd]) {
              var itemBoxshot = data.Products[x].LocalizedProperties[0].Images[imgEnd].Uri.replace("http:", "https:") + "?w=272";
              var itemBoxshotSmall;
          } else {
              var itemBoxshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
              var itemBoxshotSmall = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
          }

          var modDate = data.Products[x].DisplaySkuAvailabilities[0].Availabilities[0].LastModifiedDate;
          if (modDate === undefined) {
              modDate = 0;
          }

          var releaseDate = data.Products[x].MarketProperties[0].OriginalReleaseDate;
          if (releaseDate === undefined) {
              releaseDate = 0;
          }

          allGames[itemId] = {
            releasedate: releaseDate,
            boxshot: itemBoxshot,
            title: itemTitle
          }

          if ((x === (productQuantity - 1)) && count === chunktotal - 1) {
            //sort fullGameArray by releasedate
            var activecheck = setInterval(function() {
                var activeAjax = $.active;
                if (activeAjax === 0) {
                    ajaxdone();
                    clearInterval(activecheck);
                }
            }, 500);

            function ajaxdone() {
                fullGameArray = fullGameArray.sort(asc_sort);
  
                function asc_sort(a, b) {
                  return (new Date(allGames[a]["releasedate"])) < (new Date(allGames[b]["releasedate"])) ? 1 : -1;
                };

                populate(fullGameArray.slice(0, 30), ".newReleases");
                populate(fullGameArray.slice(30, 60), ".newReleases2");

            };
          };
      };

      function populate(array, container) {

        for (let i = 0; i < array.length; i++) {
          $(container + " ul").append('<li class="slide" aria-hidden="true">' +
          '<section class="m-product-placement-item f-size-large context-device f-clean" data-title="' + allGames[array[i]].title + '" data-prodid="' + array[i] + '" data-releasedate="' + allGames[array[i]].releasedate + '">' +
          '<picture>' +
          '<source srcset="' + allGames[array[i]].boxshot + '" media="(min-width:0)">' +
          '<img class="c-image" srcset="' + allGames[array[i]].boxshot + '" src="' + allGames[array[i]].boxshot + '" ' +
          'alt="' + allGames[array[i]].title + ' box art">' +
          '</picture>' +
          '<div>' +
          '</div>' +
          '</section>' +
          '</li>')

          var gameTitle = allGames[array[i]].title;
          gameTitles.push(gameTitle);
        }

        if (container === ".newReleases2") {
            sliderInit();
        }

      }

    }

    setTimeout(function() {
      var a = gameTitles.slice(1, gameTitles.length).join(", ")
      let animationScreenreader = $(".slider .x-screen-reader").text();
      animationScreenreader = animationScreenreader.replace("PLACEHOLDER", a);

      $(".slider .x-screen-reader").text(animationScreenreader);

    }, 3000)


    function sliderInit() {
        const theSlides = $(".newReleases .slide-track .slide");
        const theSlidesTwo = $(".newReleases2 .slide-track .slide");

        // get number of slides for CSS math
        const numberOfSlides = theSlides.length;
        const numberOfSlidesTwo = theSlidesTwo.length;
        console.log("numberOfSlides " + numberOfSlides + " numberOfSlidesTwo " + numberOfSlidesTwo);

        // 'copy and paste' the single set of slides; easier to maintain
        $(".newReleases .slide-track").append(theSlides.clone());
        $(".newReleases2 .slide-track").append(theSlidesTwo.clone());

        // set width of slide track based on number of slides
        // need math here but keyframes not accessible in jQuery, so write out the entire style declaration with math
        $(".newReleases.slider").find("style").remove(); // deletes the old style element so it  can be rewritten after resize
        $(".newReleases.slider").append("<style>@keyframes scroll {0%{transform: translateX(0);}100% {transform: translateX(calc(-298px * " + numberOfSlides + "));}}</style>");

        $(".newReleases2.slider").find("style").remove();
        $(".newReleases2.slider").append("<style>@keyframes scroll2 {0%{transform: translateX(0);}100% {transform: translateX(calc(-298px * " + numberOfSlidesTwo + "));}}</style>");

        $(".slider").addClass("fade-in");

        
        $(".pausePlay").click(function() {
            $(".slide-track").toggleClass("paused");
            var aria_label = "";
            if ($(this).hasClass("glyph-pause")) {
                aria_label = locStrings.locales[urlRegion].keyPausepressed;
                $(this).removeClass("glyph-pause").addClass("glyph-play");
                $(this).attr("aria-label", aria_label);
                $(this).attr("data-toggled-label", "paused");
            } else {
                aria_label = locStrings.locales[urlRegion].keyPlaypressed;
                $(this).removeClass("glyph-play").addClass("glyph-pause");
                $(this).attr("aria-label", aria_label);
                $(this).attr("data-toggled-label", "play");
            }
        });
    }    
});

locStrings = {
  "locales": {
      "en-us": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "ar-ae": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "ar-sa": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "cs-cz": {
          "keyPlay": "Hrát",
          "keyPause": "Pauza",
          "keyPlaypressed": "Tlačítko přehrávání je zapnuté",
          "keyPausepressed": "Tlačítko pro pauzu je zapnuté"
      },
      "da-dk": {
          "keyPlay": "Spil",
          "keyPause": "Pause",
          "keyPlaypressed": "Play-knappen er tændt",
          "keyPausepressed": "Pause-knappen er tændt"
      },
      "de-at": {
          "keyPlay": "Wiedergeben",
          "keyPause": "Pause",
          "keyPlaypressed": "Play-Taste ist eingeschaltet",
          "keyPausepressed": "Pause-Taste ist eingeschaltet"
      },
      "de-ch": {
          "keyPlay": "Wiedergeben",
          "keyPause": "Pause",
          "keyPlaypressed": "Play-Taste ist eingeschaltet",
          "keyPausepressed": "Pause-Taste ist eingeschaltet"
      },
      "de-de": {
          "keyPlay": "Wiedergeben",
          "keyPause": "Pause",
          "keyPlaypressed": "Play-Taste ist eingeschaltet",
          "keyPausepressed": "Pause-Taste ist eingeschaltet"
      },
      "el-gr": {
          "keyPlay": "Δείτε το",
          "keyPause": "Παύση",
          "keyPlaypressed": "Το κουμπί αναπαραγωγής είναι ενεργοποιημένο",
          "keyPausepressed": "Το κουμπί παύσης είναι ενεργοποιημένο"
      },
      "en-au": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "en-ca": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "en-gb": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "en-hk": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "en-ie": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "en-in": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "en-nz": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "en-sg": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "en-za": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "es-ar": {
          "keyPlay": "Juega",
          "keyPause": "Pause",
          "keyPlaypressed": "El botón de reproducción está activado",
          "keyPausepressed": "El botón de pausa está activado"
      },
      "es-cl": {
        "keyPlay": "Juega",
        "keyPause": "Pause",
        "keyPlaypressed": "El botón de reproducción está activado",
        "keyPausepressed": "El botón de pausa está activado"
      },
      "es-co": {
        "keyPlay": "Juega",
        "keyPause": "Pause",
        "keyPlaypressed": "El botón de reproducción está activado",
        "keyPausepressed": "El botón de pausa está activado"
      },
      "es-es": {
        "keyPlay": "Juega",
        "keyPause": "Pause",
        "keyPlaypressed": "El botón de reproducción está activado",
        "keyPausepressed": "El botón de pausa está activado"
      },
      "es-mx": {
        "keyPlay": "Juega",
        "keyPause": "Pause",
        "keyPlaypressed": "El botón de reproducción está activado",
        "keyPausepressed": "El botón de pausa está activado"
      },
      "fi-fi": {
          "keyPlay": "Play",
          "keyPause": "Pysäytys",
          "keyPlaypressed": "Toistopainike on käytössä",
          "keyPausepressed": "Pysäytyspainike on käytössä"
      },
      "fr-be": {
          "keyPlay": "Jouez",
          "keyPause": "Pause",
          "keyPlaypressed": "Le bouton Lecture est activé",
          "keyPausepressed": "Le bouton Pause est activé"
      },
      "fr-ca": {
          "keyPlay": "Jouer",
          "keyPause": "Pause",
          "keyPlaypressed": "Le bouton Lecture est activé",
          "keyPausepressed": "Le bouton Pause est activé"
      },
      "fr-ch": {
        "keyPlay": "Jouez",
        "keyPause": "Pause",
        "keyPlaypressed": "Le bouton Lecture est activé",
        "keyPausepressed": "Le bouton Pause est activé"
      },
      "fr-fr": {
        "keyPlay": "Jouez",
        "keyPause": "Pause",
        "keyPlaypressed": "Le bouton Lecture est activé",
        "keyPausepressed": "Le bouton Pause est activé"
      },
      "he-il": {
          "keyPlay": "Play",
          "keyPause": "Pause",
          "keyPlaypressed": "Play button is on",
          "keyPausepressed": "Pause button is on"
      },
      "hu-hu": {
          "keyPlay": "Lejátszás",
          "keyPause": "Szünet",
          "keyPlaypressed": "A Lejátszás gomb be van kapcsolva",
          "keyPlaypressed": "A Szünet gomb be van kapcsolva"
      },
      "it-it": {
          "keyPlay": "Gioca",
          "keyPause": "Sospendi",
          "keyPlaypressed": "Il pulsante di riproduzione è attivo",
          "keyPausepressed": "Il pulsante di pausa è attivo"
      },
      "ja-jp": {
          "keyPlay": "ゲーム",
          "keyPause": "ポーズ",
          "keyPlaypressed": "プレイ ボタンがオンになっています",
          "keyPausepressed": "ポーズ ボタンがオンになっています"
      },
      "ko-kr": {
          "keyPlay": "플레이",
          "keyPause": "일시 정지",
          "keyPlaypressed": "재생 버튼이 켜져 있습니다",
          "keyPausepressed": "일시 중지 버튼이 켜져 있습니다"
      },
      "nb-no": {
          "keyPlay": "Spill",
          "keyPause": "Pause",
          "keyPlaypressed": "Avspillingsknappen er på",
          "keyPausepressed": "Pause-knappen er på"
      },
      "nl-be": {
          "keyPlay": "Speel",
          "keyPause": "Pauze",
          "keyPlaypressed": "Afspeelknop staat aan",
          "keyPausepressed": "Pauzeknop staat aan"
      },
      "nl-nl": {
        "keyPlay": "Speel",
        "keyPause": "Pauze",
        "keyPlaypressed": "Afspeelknop staat aan",
        "keyPausepressed": "Pauzeknop staat aan"
      },
      "pl-pl": {
          "keyPlay": "Odtwórz",
          "keyPause": "Pauza",
          "keyPlaypressed": "Przycisk odtwarzania jest włączony",
          "keyPausepressed": "Przycisk pauzy jest włączony"
      },
      "pt-br": {
        "keyPlay": "Jogar",
        "keyPause": "Pausar",
          "keyPlaypressed": "O botão de reprodução está ativado",
          "keyPausepressed": "O botão de pausa está ativado"
      },
      "pt-pt": {
          "keyPlay": "Reproduzir",
          "keyPause": "Pausa",
          "keyPlaypressed": "O botão reprodução está ligado",
          "keyPausepressed": "O botão de pausa está ativado"
      },
      "ru-ru": {
          "keyPlay": "Воспроизвести",
          "keyPause": "Пауза",
          "keyPlaypressed": "Кнопка воспроизведения включена",
          "keyPausepressed": "Кнопка приостановки воспроизведения включена"
      },
      "sk-sk": {
          "keyPlay": "Prehrať",
          "keyPause": "Pozastavenie",
          "keyPlaypressed": "Tlačidlo prehrávania je zapnuté",
          "keyPausepressed": "Tlačidlo pozastavenia prehrávania je zapnuté"
      },
      "sv-se": {
          "keyPlay": "Spela",
          "keyPause": "Pausa",
          "keyPlaypressed": "Knappen Spela upp är aktiverad",
          "keyPausepressed": "Pausknappen är aktiverad"
      },
      "tr-tr": {
          "keyPlay": "Oynatın",
          "keyPause": "Duraklat",
          "keyPlaypressed": "Oynat düğmesi açık",
          "keyPausepressed": "Duraklat düğmesi açık"
      },
      "zh-hk": {
          "keyPlay": "暢玩",
          "keyPause": "暫停",
          "keyPlaypressed": "播放按鈕已啟用",
          "keyPausepressed": "暫停按鈕已啟用"
      },
      "zh-tw": {
          "keyPlay": "播放",
          "keyPause": "暫停",
          "keyPlaypressed": "播放按鈕已開啟",
          "keyPausepressed": "暫停按鈕已開啟"
      }
  }
}