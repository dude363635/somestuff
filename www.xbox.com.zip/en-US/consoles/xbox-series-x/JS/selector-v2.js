history.scrollRestoration = "manual"; // prevents jumping around after moving to hashtag

$(document).ready(function() {

    // fix until modules can be updated manually
    $('.c-pivot.custom[data-selector-group="buybox"]').attr("data-selector-group", "buyBox");

    // pivot is only hard coded in one place. The .c-pivot element is empty everywhere else.
    // contents get cloned for ease of maintenance. 
    // make sure the hard coded c-pivot appears in the first relevant module on the page.
    mainPivot = $(".c-pivot.custom").eq(0).children().clone();
    $(mainPivot).appendTo(".c-pivot.custom:not(:eq(0))");

    let automatedFocus = false;

    $(".selector li").on("focus", function() {
        $(this).click();
        if (automatedFocus === false) {
            theOption = $(this).attr("data-option");
            originator = $(this).closest(".c-pivot").attr("data-selector-group");
            selectorWrangler(theOption, originator, false); // "false" means not triggered by hashtag
        }
    });

    // begin to act on only relevant modules. Don't touch modules that don't have selected options.
    // get all group names: modules with classes the same as their data-selector-group
    var groups = new Array();
    var deletedOptions = new Array();
    $(".c-pivot.custom").each(function() {
        var group = $(this).attr("data-selector-group");
        if (groups.includes(group) === false) {
            groups.push(group);
        }
    });

    $(".c-pivot.custom").each(function() {
        thisGroup = $(this).attr("data-selector-group");
        $(this).find(".selector li").each(function() {
            thisOption = $(this).attr("data-option");
            thisText = $(this).attr("data-option");
            if ($(".option." + thisGroup + "." + thisOption).length === 0) {
                $(this).remove();

                selectOption = $('.pagebar-selector option[data-option="' + thisOption + '"]');
                selectOptionText = $(selectOption).text();
                // set matching UI select button to aria-selected
                $(".c-select.pagebar-selector .c-menu .c-menu-item span").each(function() {
                    if ($(this).find("p").text() === selectOptionText) {
                        $(this).remove();
                    }
                })
                $(selectOption).remove();
            }
        })

        if ($(this).find(".selector li").length < 2) {
            $(this).remove();
        }

        $(".c-pivot.custom").addClass("fade-in");
    });



    function selectorWrangler(theOption, originator, fromHash) {
        for (const group of groups) {

            // switch options by group since some don't have all options

            $(".option." + group).each(function() {
                if ($(this).hasClass(theOption) === true) {
                    // if the option exists for that group, do the thing
                    // hide all
                    $(".option." + group).removeClass("selected-option");

                    // show the new option
                    $(".option." + group + "." + theOption).addClass("selected-option");

                }
                // separate processing for page bar, which always has all options 
                $(".CTAdiv").removeClass("selected-option");
                $(".CTAdiv." + theOption).addClass("selected-option");

            });


            $(".option." + group).find(".selector").each(function() {
                // control appearance of pivot selectors
                // if this group doens't have the new option, leave last selected option showing as selected


                $(this).find("li").each(function() {

                    // found the option? do the thing
                    if ($(this).attr("data-option") === theOption && !($(this).hasClass("selected"))) {

                        // unselect all
                        $(".option." + group).find(".selector li").attr({
                            "class": "",
                            "aria-selected": "false",
                            "tabindex": "-1"
                        });

                        // set new option to selected
                        $(".option." + group).find('.selector li[data-option="' + theOption + '"]').attr({
                            "class": "f-active selected",
                            "aria-selected": "true",
                            "tabindex": "0"
                        });
                    }
                });
            });
            // end for of loop
        }



        //manage selector focus only if manually selected, not if triggered by hashtag
        if (fromHash === true) {
            purchaseWrangler();
        } else if (originator !== "pagebar") {
            automatedFocus = true;
            if ($('.c-pivot[data-selector-group="' + originator + '"] li[aria-selected="true"]').length > 0) {
                $('.c-pivot[data-selector-group="' + originator + '"] li[aria-selected="true"]').focus();
            }
            automatedFocus = false
        }

        pagebarWrangler(theOption, originator);
        vidWrangler();
    }


    // theOption determined from theHash acquired in each page's css-js module
    if (theOption.indexOf("standard") === -1) {
        selectorWrangler(theOption, null, true);
        pagebarWrangler(theOption);
    } else if (typeof theHash !== "undefined") {
        if (theHash === "#purchase") {
            defaultPurchase = "#" + $("section[id^='purchase']:visible").attr("id");
            theHash = defaultPurchase;
            purchaseWrangler();
        } else {
            purchaseWrangler();
        }
    }



    function purchaseWrangler() {
        /* send to purchase section only after selector is wrangled */
        if ((typeof theHash !== "undefined") && theHash.indexOf("#purchase") > -1) {
            // if the anchor is visible and theOption exists within it
            if ($(theHash).is(":visible") /*&& $(theHash).find(".c-pivot.custom li[data-option='" + theOption + "']").length > 0*/ ) {
                setTimeout(function() {
                    window.location.href = theHash;
                }, 0);
            }
        }
    }

    function vidWrangler() { // keep user from having to see the same video twice. Transfer current time back and forth.
        if ($(".gallery-hero video").length > 0) {
            var thisVideo = $(".staticHero:hidden").find("video").get(0); // when vidWrangler() is called the original video is already hidden
            var otherVideo = $(".staticHero:visible").find("video").get(0); // the target video is visible. find it to act on it.

            if (thisVideo.currentTime > 0.2) { // runs only after video has had time to start. prevents pausing on every #carbonblack page load.

                otherVideo.play(); // make sure target video is playing. cleans up some occasional jumpiness.

                currentTime = thisVideo.currentTime; // get current time
                otherVideo.currentTime = currentTime; // set other video to current time

                //handle combined play/pause including button glyph and global localized aria strings
                if (thisVideo.paused === true) {
                    otherVideo.pause();
                    $(".staticHero .m-hero-item .pp-button>video+div").find("button").removeClass("glyph-pause").addClass("glyph-play").attr("aria-label", locStrings.locales[urlRegion].keyPausepressed);
                } else if (thisVideo.paused === false) {
                    otherVideo.play();
                    $(".staticHero .m-hero-item .pp-button>video+div").find("button").removeClass("glyph-play").addClass("glyph-pause").attr("aria-label", locStrings.locales[urlRegion].keyPlaypressed);
                }
            }
        }
    }

    function pagebarWrangler(theOption, originator) {
        // handle UI select elements:
        // get theOption's related text from underlying hidden HTML select element
        pagebarOption = $(".c-in-page-navigation > .c-select.pagebar-selector select option[data-option='" + theOption + "']");
        pagebarText = $(pagebarOption).text();

        // change UI select button to show selected value
        $(".c-select.pagebar-selector .c-select-menu > button").text(pagebarText);

        // change underlying HTML select element to selected
        $(".c-select.pagebar-selector select option").each(function() {
            $(this).removeAttr("selected");
            if ($(this).attr("data-option") === pagebarOption) {
                $(this).attr("selected", "selected");
            }
        })

        // set matching UI select button to aria-selected
        $(".c-select.pagebar-selector .c-menu .c-menu-item span").each(function() {
                $(this).attr("aria-selected", "false");
                if ($(this).find("p").text() === pagebarText) {
                    $(this).attr("aria-selected", "true");
                }
            })
            //  END handle UI select elements:

        // misc:
        // force selected option to gain focus when dropdown is opened
        $(document).on("click", ".c-select.pagebar-selector .c-select-menu > button", function(e) {
            eventType = e.which;
            if (eventType === 1 || eventType === 13 || eventType === 32) { // click or enter or spacebar
                if ($(this).attr("aria-expanded") === "true") {
                    $(this).closest(".c-select-menu").find('.c-menu-item span[aria-selected="true"]').focus();
                }
            }
        });
        // END misc
    }


    // get the value of each option 
    $(document).on("click keydown", ".c-select.pagebar-selector .c-menu-item span", function(e) {
        eventType = e.which;
        if (eventType === undefined) {
            eventType = 1;
        }

        if (eventType === 1 || eventType === 13 || eventType === 32) { // click or enter or spacebar

            // need some falderal to get value of underlying <select></select> element. Associates UI button text with underlying select option.
            buttonText = $(this).text();

            $(".c-select.pagebar-selector").each(function(index) {

                let selectedIndex = null;

                $(this).find("select option").each(function(index) {
                    if ($(this).text() === buttonText) {
                        theOption = $(this).attr("data-option");
                        selectedIndex = index;
                    };
                });
                $(".c-select.pagebar-selector .c-menu .c-menu-item span").attr("aria-selected", "false");
                $(this).find(".c-menu .c-menu-item span").eq(selectedIndex).attr("aria-selected", "true");

            });
            selectorWrangler(theOption, "pagebar", false);

            //close pagebar main dropdown when option is selected

            if ($(this).closest(".pagebar-selector").hasClass("main-dropdown")) {
                $(".c-navigation-menu > ul").attr("aria-hidden", "true");
                $(".c-navigation-menu >button").attr("aria-expanded", "false").focus();
            }

        }

    });

    // pagebarSelector UI element gets written to the page well after load
    // this makes sure it's set to correct option, esepcially when a hashtag triggers a non-default selection

    let config = {
        childList: true,
    };
    let pagebarObserver = new MutationObserver(pagebarMonitor);
    let pagebarSelector = $(".c-select.pagebar-selector").get(0);
    pagebarObserver.observe(pagebarSelector, config);

    // ============================================================

    function pagebarMonitor(mutations) {
        for (var mutation of mutations) {
            // mutation.target is the element that is acted upon. 
            if ($(mutation.target).find(".c-select-menu").length > 0) {
                // get option value when pagebarSelector is written to the page
                theOption = $(".c-pivot.custom").eq(0).find("li.selected").attr("data-option");
                // set pagebar to that option
                pagebarWrangler(theOption);
            }
        };
    }

    /* =========================== */
    /* drawer consisitency when switching the controller selector */
    /* =========================== */

    let previousDrawerStatus = "false";

    $(document).on("click", ".control .c-drawer-toggle", function(e) {
        thisToggle = $(this);
        setTimeout(function() {
            previousDrawerStatus = $(thisToggle).attr("aria-expanded");
            console.log("previousDrawerStatus " + previousDrawerStatus);
        }, 1000);
    });

    /* monitor changes to the .control modules */
    let controlConfig = {
        attributes: true
    };
    let controlObserver = new MutationObserver(controlMonitor);
    controlModules = $(".control.option");

    /* send them all to be observed */
    $(controlModules).each(function(){
        thisControlModule = $(this).get(0);
        controlObserver.observe(thisControlModule, controlConfig);
    });

    /* act on the drawer if it's different than previous */
    function controlMonitor(mutations) {
        for (var mutation of mutations) {
            if ($(mutation.target).hasClass("selected-option") === true) {
                thisDrawer =  $(mutation.target).find(".c-drawer-toggle");
                thisDrawerStatus = $(thisDrawer).attr("aria-expanded");
                if (thisDrawerStatus !== previousDrawerStatus){
                    $(thisDrawer)[0].click();// using dom click rather than jquery click, which didn't work.
                }
            }
        };
    }
    /* =========================== */
    /* END drawer consisitency when switching the controller selector */
    /* =========================== */







    /*
    $(".c-pivot.custom.legacy li").on("click", function(e) {
        console.log("================= CLICKED $(this).attr(data-option) " +  $(this).attr("data-option"));
    
        previousDrawerStatus = $(this).closest(".control").find(".c-drawer-toggle").attr("aria-expanded");
        console.log("================= previousDrawerStatus " + previousDrawerStatus);
        setTimeout(function() {
            thisDrawer = $(".control:visible").find(".c-drawer-toggle");
            thisDrawerStatus = $(thisDrawer).attr("aria-expanded");
            console.log("================= thisDrawerStatus " + thisDrawerStatus);
    
            if (thisDrawerStatus !== previousDrawerStatus){
                $(thisDrawer).click();
            }
        }, 50);
    
    
    });
    */


    $(document).on("click", ".seeOptions", function() {
        $(this).blur().trigger("mouseleave");
        $(".buyBox:visible .c-pivot.custom li.f-active").focus();
        window.scrollTo(0, $(".buyBox:visible").offset().top)
    });
});