$(document).ready(function() {
  $(".gallery-hero").each(function(){
    var heroContent = $(this).find(".hero-content").clone(true, true);
    $(heroContent).addClass("mobile");
    $(this).find(".m-hero-item").append(heroContent);
  })
});