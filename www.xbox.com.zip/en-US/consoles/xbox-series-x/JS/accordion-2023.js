$(document).ready(function() {
    var accordionPanel = $(".accordion__main .accordion__wrap .accordion__panel"),
  accordionWrap = $(".accordion__main .accordion__wrap"),
        closeButton = $(".btnClose");
        
        $(accordionPanel).attr("aria-expanded", "false");

    /*
    $(accordionPanel).each(function (){
      $(this).find(".btnClose")[0].attr("tabindex", "-1");
  });*/
    if ($(window).outerWidth(true) < 1084) var i = "mobiBG";
    else var i = "dsktopBG";
    $(accordionWrap).css("background-image", "url(" + $(accordionPanel).attr(i) + ")");
    var a = (function() {
        var e = {};
        return function(o, n, i) {
            i || (i = "Fires only once."), e[i] && clearTimeout(e[i]), (e[i] = setTimeout(o, n));
        };
    })();
    $(window).resize(function() {
            a(
                function() {
                    (i = $(window).outerWidth(true) < 1084 ? "mobiBG" : "dsktopBG"), $(accordionWrap).css("background-image", "url(" + $(".expanded").attr(i) + ")");
                },
                200,
                "pageresize"
            );
        }),
        $(accordionPanel).on("keydown", function(e) {
            if (13 == e.keyCode || 32 == e.keyCode) {
                e.preventDefault();
                $(this).click();
            }
        }),
        $(document).on("keydown", ".btnClose", function(e) {
            if (13 == e.keyCode || 32 == e.keyCode) {
                e.preventDefault();
                $(this).closest(".accordion__panel").focus();
                $(this).click();
            }
        }),
        $(document).on("keydown", ".accordion__panel.expanded a:nth-child(1)", function(e) {
            if (13 == e.keyCode || 32 == e.keyCode) {
                e.preventDefault();
                window.open($(".accordion__panel.expanded a:nth-child(1)").attr("href"), "_parent");
            }
        }),
        $(accordionPanel).on("click", function() {
            $(accordionPanel).attr("tabindex", "0");
            $(this).attr("tabindex", "-1");
            if ($(this).hasClass("initial") || $(this).hasClass("contracted")) {
                $(this).find(".btnClose").show();
                $(this).find(".btnClose")[0].focus();
                var panText = $(this).find(".mainCont .m-content-placement-item.content").attr("aria-label") + $(this).find(".btnClose").attr("aria-label");
                if ($(".carouselAnnounce").text().toLowerCase().indexOf("...") === -1) {
                    panText = $(this).find(".mainCont .m-content-placement-item.content").attr("aria-label") + $(this).find(".btnClose").attr("aria-label") + "...";
                }
                $(".carouselAnnounce").text(panText);
            }
            $(accordionPanel).attr("aria-expanded", "false");

            $(this).addClass("expanded").removeClass("initial").removeClass("contracted");

            $(accordionPanel).not(this).addClass("contracted").removeClass("expanded").removeClass("initial");
            $(accordionPanel).not(this).each(function() {
                $(this).find(".btnClose").hide();
            })

            $(accordionWrap).css("background-image", "url(" + $(this).attr(i) + ")");

            if ($(this).hasClass("expanded")) {
                //$(this).find(".btnClose")[0].focus();
                $(this).attr("tabindex", "-1");
                $(this).attr("aria-expanded", "true");
            }

        }),
        $(closeButton).on("click", function(o) {
            $(accordionPanel).addClass("initial"), $(accordionPanel).removeClass("expanded").removeClass("contracted"), o.stopPropagation();
            $(this).closest(".accordion__panel").focus();
            $(this).hide();
            $(accordionPanel).attr("tabindex", "0");
            $(accordionPanel).attr("aria-expanded", "false");
        });
        
});