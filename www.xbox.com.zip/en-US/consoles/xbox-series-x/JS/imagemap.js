$(document).ready(function() {

    let viewportWidth = $(window).outerWidth(true);

    $(document).on("click", ".hotspot", function() {
        $(this).focus();
        
        $(".tool-tip").removeClass("adjusted");

        theTooltip = $(this).next(".tool-tip");

        if ($(theTooltip).attr("aria-hidden") === "false") {
            $(theTooltip).attr("aria-hidden", "true");
            $(this).attr("aria-expanded", "false");
        } else {
            $(".tool-tip").attr("aria-hidden", "true");
            $(theTooltip).attr("aria-hidden", "false");
            $(this).attr("aria-expanded", "true");

            setTimeout(function(){// prevents jumpiness
                $(theTooltip).find(".tooltip-close").focus();
            }, 20)
        }

        hotspotHeight = $(this).outerHeight(false);
        hotspotWidth = $(this).outerWidth(false);
        hotspotPositionTop = $(this).position().top
        hotspotPositionLeft = $(this).position().left
        
        tooltipWidth = $(theTooltip).outerWidth(false);
        tooltipTop = hotspotHeight + hotspotPositionTop + 6;
        tooltipLeft = hotspotPositionLeft + hotspotWidth / 2 - tooltipWidth / 2 // yay order of operations

        $(theTooltip).css({ "top": tooltipTop, "left": tooltipLeft });

        tooltipRight = tooltipWidth + $(theTooltip).offset().left;

        if (tooltipRight > (viewportWidth - 20)) {
            $(theTooltip).css({ "left": "auto", "right": "20px" })
            $(theTooltip).addClass("adjusted")
        }

        if (tooltipLeft < 20) {
            $(theTooltip).css({ "left": "20px", "right": "auto" })
            $(theTooltip).addClass("adjusted")
        }
    });

    $(document).on("click keydown", ".tool-tip", function(e) {// can click button or tooltip itself
        eventType = e.which;
        if (eventType === 1 || eventType === 32 || eventType === 27) { // click or spacebar or esc. enter works by default.
            $(this).prev(".hotspot").click();
        }
    });

/*
    $(document).on("click keydown", ".image-map", function(e) {
        $(".hotspot[aria-expanded='true'").click();
    });
*/
    // Determine viewport width and process everything. Limit resize detection to width only.
    $(window).on("resize", function(e) {
        let newViewportWidth = window.innerWidth;
        if (newViewportWidth != viewportWidth) {
            viewportWidth = newViewportWidth;
            $(".tool-tip").attr({ "aria-hidden": "true", "css": "" });
        }
    });

    // mutation observer to detects changes in flyout for aria and styling purposes, calls hotspotWrangler accordingly
    let config = {
        attributes: true,
        subtree: true
    };
    let hotspotObserver = new MutationObserver(hotspotWrangler);

    let hotspots = $(".the-hotspots .tool-tip");
    $(hotspots).each(function(index) {
        let theTarget = $(this).get(0); // get the actual node rather than jQuery object
        hotspotObserver.observe(theTarget, config);
    });

    // Multiple elements are observed. This function needs to know which element has changed.
    function hotspotWrangler(mutations) {
        for (var mutation of mutations) {
            // mutation.target is the element that is acted upon. Further operations are relevant only to this hero/pp group.
            if ($(mutation.target).attr("aria-hidden") === "true") {
                $(mutation.target).prev(".hotspot").attr("aria-expanded", "false");
            } else {
                $(mutation.target).prev(".hotspot").attr("aria-expanded", "true");
            }
        };
    }
});