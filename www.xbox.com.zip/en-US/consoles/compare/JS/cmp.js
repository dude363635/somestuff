$(document).ready(function() {
    var topPurchase = $(".top-purchase");
    var bottomPurchase = $(".bottom-purchase");
    var pageBar = $(".m-in-page-navigation");
    $(pageBar).addClass("isHidden");


    //$(pageBar).addClass("isHidden");
    $(bottomPurchase).addClass("isHidden");


    // show/hide elements when buybox is in viewport
    var scrollTimer = null;

    $(window).on("load scroll", function() {
        if (scrollTimer) {
            clearTimeout(scrollTimer); // clear any previous timer to save resources
        }
        scrollTimer = setTimeout(processScroll, 50); // set new timer

        //if ($(".CTAdiv button").attr("data-cta-href") !== undefined) {
        //    if ($(".CTAdiv button").attr("data-cta-href").indexOf('#') == 0) { // if elements exists and starts with #
        //        scrollTimer = setTimeout(processScroll, 150); // set new timer
        //    }
        //}

    });

    function processScroll() {
        scrollTimer = null; // start over, save resources

        scrollPosition = $(document).scrollTop(); // page scroll position

        //var skuTarget = $(".CTAdiv button").attr("data-cta-href"); // get sku by whatever target is in the elements
        //var skuChooser = $("#" + skuTarget.split("#")[1]); // select SKU after some hashtag wrangling

        //var skuHeight = $(skuChooser).height();

        //var skuTop = $(skuChooser).offset().top;

        var topOfViewport = scrollPosition;
        var bottomOfViewport = scrollPosition + window.innerHeight;

        var topTop = $(topPurchase).offset().top;
        var topHeight = $(topPurchase).height();
        var bottomTop = $(bottomPurchase).offset().top;
        var bottomHeight = $(bottomPurchase).height();

console.log("topOfViewport " +topOfViewport + " topTop " + topTop+ " topHeight " +topHeight + " bottomTop " + bottomTop+ " bottomHeight " +bottomHeight);
        topTarget = topTop + (.5 * topHeight); // set how much of top or bottom shows before taking action
        console.log("topTarget " +topTarget);

        bottomTarget = bottomTop - (.5 * window.innerHeight);
        console.log("bottomTarget " +bottomTarget);


        if ((topTarget < topOfViewport)) {
            $(topPurchase).addClass("isHidden");
            $(pageBar).removeClass("isHidden");
            console.log('1 $(pageBar).removeClass("isHidden")');
        } else {
            $(topPurchase).removeClass("isHidden");
            $(pageBar).addClass("isHidden");
            console.log('1 $(pageBar).addClass("isHidden")');

        }
        if ((bottomTarget < topOfViewport)) {
            $(bottomPurchase).removeClass("isHidden");
            $(pageBar).addClass("isHidden");
            console.log('2 $(pageBar).addClass("isHidden")');

        } else {
            $(bottomPurchase).addClass("isHidden");
            //$(pageBar).removeClass("isHidden");
            console.log('2 $(pageBar).removeClass("isHidden")');

        }

    }
    // END show/hide elements when buybox is in viewport

});