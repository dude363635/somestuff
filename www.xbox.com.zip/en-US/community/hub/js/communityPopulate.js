$(document).ready(function() {
    var urlRegion = document.URL.split("/")[3].toLowerCase();
    //   var locregionContent = locContent.locales[urlRegion];

    var popJSON = (function() {
        var regionContent = globalContent.locales[urlRegion];
        var allKeys = Object.keys(regionContent)
        var keysLength = allKeys.length
        for (var i = 0; i < keysLength; i++) {
            if (allKeys[i].indexOf("keyCopy") !== -1) {
                if (regionContent[allKeys[i]] !== "####") {
                    $("[data-loc-copy=" + allKeys[i] + "]").html(regionContent[allKeys[i]]);
                }
            } else if (allKeys[i].indexOf("keyImage") !== -1) {
                $("source[data-loc-image=" + allKeys[i] + "]").attr("srcset", regionContent[allKeys[i]]);
                $("img[data-loc-image=" + allKeys[i] + "]").attr("src", regionContent[allKeys[i]]).attr("src", regionContent[allKeys[i]]);
            } else if (allKeys[i].indexOf("keyAlt") !== -1) {
                $("[data-loc-alt=" + allKeys[i] + "]").attr("alt", regionContent[allKeys[i]]);
            } else if (allKeys[i].indexOf("keyLink") !== -1) {
                if (regionContent[allKeys[i]] !== "####") {
                    $("[data-loc-link=" + allKeys[i] + "]").attr("href", regionContent[allKeys[i]]);
                }
            } else if (allKeys[i].indexOf("keyAria") !== -1) {
                $("[data-loc-aria=" + allKeys[i] + "]").attr("aria-label", regionContent[allKeys[i]]);
                // Community font colors 
            } else if (allKeys[i].indexOf("keyTextcolor") !== -1) {
                theColor = regionContent[allKeys[i]].toLowerCase();
                if (theColor === "white") {
                    $("[data-loc-textcolor=" + allKeys[i] + "]" + " > *").addClass("white-c");
                } else {
                    $("[data-loc-textcolor=" + allKeys[i] + "]" + " > *").removeClass("white-c");
                }
            }
        };

        $(".mosaic__content a, .events a").each(function() {
            if ($(this).attr("href").indexOf("www.xbox.com") !== -1) {
                console.log("www.xbox.com " + $(this).attr("href"));
                $(this).attr({ "data-cta": "learn", "target": "" });
            } else if ($(this).attr("href").indexOf("xbox.com") !== -1) {
                console.log("internal xbox.com " + $(this).attr("href"));
                $(this).attr({ "data-cta": "internal", "target": "_blank" });
            } else if ($(this).attr("href").indexOf("surface.com") !== -1 || $(this).attr("href").indexOf("microsoft.com") !== -1 || $(this).attr("href").indexOf("minecraft.net") !== -1) {
                console.log("other internal" + $(this).attr("href"));
                $(this).attr({ "data-cta": "internal", "target": "_blank" });
            } else {
                console.log("external " + $(this).attr("href"));
                $(this).attr({ "data-cta": "external", "target": "_blank" });
            }

            if ($(this).attr("href") === "####" || $(this).attr("href") === "") {
                $(this).remove();
            }
        });

        // to turn off elements
        $("a span:contains(####)").closest("a").hide();
        $("p:contains(####)").hide();
    })();

});

//global functions
if (!window.globFunctions) { window.globFunctions = {} }
globFunctions = globFunctions || {};
globFunctions.startVid = function(id, src) {
    var vid = document.getElementById(id);
    if ($(vid).length) {
        vidUrl = $("#" + id + " source").attr("src", src);
        vid.load();
    }
}