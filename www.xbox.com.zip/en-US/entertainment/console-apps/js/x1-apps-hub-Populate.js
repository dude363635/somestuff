document.domain = "xbox.com";
$(document).ready(function() {
  var uri = new URL(document.URL);
  var urlRegion = uri.pathname.slice(1,6).toLowerCase();
  if (urlRegion === "en-ae") {
    urlRegion = "ar-ae";
  } else if (urlRegion === "en-sa") {
    urlRegion = "ar-sa";
  } else if (urlRegion === "en-il") {
    urlRegion = "he-il";
  }

  if ($(".CatAnnounce").length === 0) {
    $("body").append('<div style="width:0;height:0;font-size:0;" class="CatAnnounce" aria-live="assertive"></div>');
  }
  
  var catGuidArray = ["FeaturedApps", "GamerApps", "EntertainmentApps", "NewApps", "MusicApps"];
  var catClassArray = ["catFeatured", "catPopular", "catEnt", "catNews", "catMusic",];
  var listUrl = "http://reco-public.rec.mp.microsoft.com/channels/Reco/v8.0/lists/collection/CATEGORY?itemTypes=Game&DeviceFamily=Windows.Xbox&market=US&count=200";

  popLists();

  function popLists() {
    //var showMoreLoc = showMore.locales[urlRegion]
    for (var j = 0; j < Object.keys(globalContent["locales"][urlRegion].gameIdArrays).length; j++) {
      if (globalContent["locales"][urlRegion].gameIdArrays[catGuidArray[j]].length !== 0) {
        GUID_pop(globalContent["locales"][urlRegion].gameIdArrays[catGuidArray[j]], catClassArray[j]);
      } else {
        $("." + catClassArray[j]).prev("h3").remove();
        $("." + catClassArray[j]).remove();
      }
      
      // if (j === 0) {
      //   $(".gpList").after('<div class="gameSection gs' + catClassArray[j] + '"><div class="gameDivsWrapper ' + catClassArray[j] + ' ignoreSeeMore" data-grid="container"></div></div>');
      // } else {
      //   $(".gameSection").last().after('<div class="gameSection gs' + catClassArray[j] + '"><div class="gameDivsWrapper ' + catClassArray[j] + '" data-grid="container"></div>' +
      //       '<div class="gameDivCTA">' +
      //          '<button name="button" class="c-button svg-container showMore">' + showMoreLoc.keyShowmoregames + ' <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" preserveAspectRatio="xMinYMin meet"><polygon points="843.8 437.5 531.3 437.5 531.3 125 468.8 125 468.8 437.5 156.3 437.5 156.3 500 468.8 500 468.8 812.5 531.3 812.5 531.3 500 843.8 500 "/></svg></button>' +
      //          '<button name="button" class="c-button svg-container showLess hide">' + showMoreLoc.keyShowlessgames + ' <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" preserveAspectRatio="xMinYMin meet"><rect x="156.3" y="437.5" width="687.5" height="62.5"/></svg></button>'+
      //     '</div></div>');
      // }
    }
  }

  function GUID_pop(rawGuids, sectionClass) {

    var countryCode = urlRegion.split("-")[1].toUpperCase();
    var guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
    // var rawGuids = []
    // $(".xboxOneItem .gameDiv").each(function() {
    //   var biRaw = $(this).attr("data-bigid")
    //   rawGuids.push(biRaw)
    // });

    var first12 = rawGuids.slice(0,12)
    rawGuids = rawGuids.slice(12)

    // var apiData

    var firstToUrl = first12.join(",");
    guidUrl = guidUrl.replace("GAMEIDS", firstToUrl)
    $.get(guidUrl)
        .done(function(responseData) {
          var apiData = responseData;
          populate(apiData, 0, sectionClass);
          guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
          restPop();
        })

    function restPop() {
      var m,n,temparray,chunk = 20;
      var arrayCount = 1
      for (m=0,n=rawGuids.length; m<n; m+=chunk) {
        temparray = rawGuids.slice(m,m+chunk);
        var guidsToUrl = temparray.join(",");
        guidUrl = guidUrl.replace("GAMEIDS", guidsToUrl)

        $.get(guidUrl)
          .done(function(responseData) {
            var apiData = responseData;
            populate(apiData, arrayCount, sectionClass);
            arrayCount++
          })
        guidUrl = 'http://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
      }
    }

    

    function populate(data, count, sectionClass) {
      var productQuantity = data.Products.length
      for (var i = 0; i < productQuantity; i ++) {
        var itemTitle = data.Products[i].LocalizedProperties[0].ProductTitle
        var titleClickname = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^>a-z0-9-]/gi,'');
        // get boxshot
        var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
        var imageInd = 1;
        for (var j = 0; j < imagesNum; j++) {
          if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Logo" && data.Products[i].LocalizedProperties[0].Images[j].Width === 300 && data.Products[i].LocalizedProperties[0].Images[j].Height === 300) {
            imageInd = j;
            break;
          } 
          if ((data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Tile" || data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "tile") 
            && data.Products[i].LocalizedProperties[0].Images[j].Width === 300 && data.Products[i].LocalizedProperties[0].Images[j].Height === 300) {
            imageInd = j;
            break;
          } 
          if ((data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Tile" || data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "tile") 
            && data.Products[i].LocalizedProperties[0].Images[j].Width === 150 && data.Products[i].LocalizedProperties[0].Images[j].Height === 150) {
            imageInd = j;
            break;
          } 
          if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "FeaturePromotionalSquareArt") {
            imageInd = j;
            break
          }
        }
        // var desc = data.Products[i].LocalizedProperties[0].ProductDescription || "";
        
        // if (data.Products[i].LocalizedProperties[0].ShortDescription !== "" && data.Products[i].LocalizedProperties[0].ShortDescription !== null) {
        //   desc = data.Products[i].LocalizedProperties[0].ShortDescription;
        // }
        // if (desc.indexOf(".") !== -1) {desc = desc.split(".")[0] + ".";} // cut the description to one sentence

        var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri;
        var boxbgColor = data.Products[i].LocalizedProperties[0].Images[imageInd].BackgroundColor;
        if (itemBoxshot.indexOf("xboxlive.com") !== -1) {itemBoxshot = itemBoxshot + "&w=300&format=jpg"; }
        var itemId = data.Products[i].ProductId.toUpperCase();

        if (itemId === "9NBLGGH43D8W") {
          itemBoxshot = "https://assets.xboxservices.com/assets/c8/f3/c8f3eb38-0bc2-48e4-87bf-7f5542930a42.jpg?n=X1-App-Hub_Logo-0_Rooster-Teeth_300x300.jpg";
        }
        if (itemId === "9PGQ6G1K5QD7") {
          itemBoxshot = "https://assets.xboxservices.com/assets/35/06/35060866-6d47-4642-8190-52724f7f0a24.jpg?n=X1-App-Hub_Logo-0_Ubisoft-Connect_300x300.jpg";
        }
        if (itemId === "9NDJSB7LP64D") {
          itemBoxshot = "https://assets.xboxservices.com/assets/6b/fc/6bfc842f-a919-43bf-acc4-96b55e21aa93.png?n=MS_300x300_CTV.png";
        }
        if (itemId === "9NJQFHG3FJB7") {
          itemBoxshot = "https://assets.xboxservices.com/assets/e8/68/e8688362-07ee-4234-9635-0404ef9a5e74.png?n=MS_300x300_TSN.png";
        }
        if (itemId === "9NX1X6TH2GRT") {
          itemBoxshot = "https://assets.xboxservices.com/assets/96/01/96016936-8a88-4e34-9db2-fa10b4f240e1.png?n=MS_300x300_Crave.png";
        }
        if (itemId === "9MW0ZWQFH0M2") {
          itemBoxshot = "https://assets.xboxservices.com/assets/15/c7/15c7ba67-d00e-4b9b-ac70-355b1d0c6a48.png?n=AppleTV_logo.png";
        }
        if (itemId === "BZFK7WNK7R4M") {
          itemBoxshot = "https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTc6LYEXhNheFwp2halN6MiJq0hK8tHwcOslhHzFcqc.uw90wjv2YtwC_mZJs.lEh1cto.K33xsXgRNctiGCKrDjVsG9PhS5GzkLXFMF5wlXsJAfaI6.Hc6zR2KrB00Sjgkn0kvJZv.PD1.7g.ytDgP368SN3vocTlHhhyS_BQ8qZs-";
        }  
        if (itemId === "9NFQ49H668TB") {
          itemBoxshot = "https://assets.xboxservices.com/assets/d6/09/d609ede5-dad3-415d-97c0-b05916246f5e.png?n=Spotify-Music_02.png";
        }  
        if (itemId === "9WZDNCRFJ3Q2") {
          itemBoxshot = "https://assets.xboxservices.com/assets/e7/f7/e7f783f8-0afc-4688-a33f-e865450e5356.png?n=App-Hub_App-Logo_MSN-Weather_240x240.png";
        }  
        if (itemId === "9PJJ1K9DZMRS") {
          itemBoxshot = "https://assets.xboxservices.com/assets/4d/a1/4da126e7-38e9-448a-97a4-050c59922fab.png?n=X1-HBOMax-AppIcon-1x1-M-284x284-P-01.png";
          itemTitle = "HBO Max"
        } 
        if (itemId === "9NXQXXLFST89") {
          itemBoxshot = "https://assets.xboxservices.com/assets/26/aa/26aaab69-ca30-4b99-90e6-0d4203d56fb2.jpg?n=DisneyPlus_App.jpg";
        }  
        if (itemId === "9NCPJ3XP3FN8") {
          itemBoxshot = "https://assets.xboxservices.com/assets/73/bb/73bb5f5f-4938-4744-8567-9d4e5a7f4dab.png?n=YouTube_TV-App.png";
        }  
        if (itemId === "9N0866FS04W8") {
          itemBoxshot = "https://assets.xboxservices.com/assets/7c/74/7c746181-40fb-41f0-919e-745c8dbfdf08.jpg?n=X1-App-Hub_Logo-0_Dolby_300x300.jpg";
        }  
        if (itemId === "9P1BNLC6DD69") {
          itemBoxshot = "https://assets.xboxservices.com/assets/58/93/589315b3-128f-4240-829c-464a09474e89.png?n=Facebook-Watch-App-Logo-300x300.png";
        }
        if (itemId === "9NBCJX3ZVWVN") {
          itemBoxshot = "https://assets.xboxservices.com/assets/37/c2/37c26f1e-c458-4c34-b820-b55a7fd20df6.png?n=Animal-Planet-Go-App-Icon.png";
        } 
        if (itemId === "9MV42N00241D") {
          itemBoxshot = "https://assets.xboxservices.com/assets/a9/89/a9892258-3c93-4067-b0d4-5db9bf5d41e7.jpg?n=Amazon-Music-App-Logo-300x300.jpg";
        }  
        if (itemId === "9PN94D9BDFZM") {
          boxbgColor = "grey";
        }
        if (itemId === "9WZDNCRFJ3P2" || itemId === "9WZDNCRFJ1XX") {
          boxbgColor = "blue";
        }   
        if (itemId === "9WZDNCRDNKFB") {
          boxbgColor = "blue";
        }
        if (itemId === "9NBLGGH1ZJ3R") {
          boxbgColor = "blue";
        }
        if (itemId === "9NBLGGH58P0W") {
          boxbgColor = "blue";
        }




        var thishref = ""
        if (entUrls[itemId] !== undefined) {
          thishref = entUrls[itemId];
        } else {
          thishref = 'https://www.microsoft.com/store/p/' + titleClickname + '/' + itemId;
        }
        var datatrack = 'data-retailer="ms store"'
        if (thishref.toLowerCase().indexOf("xbox.com") !== -1) {
          datatrack = 'data-cta="learn"'
        }

        $("." + sectionClass + " ul").append('<li>' +
                                              '<section class="m-product-placement-item context-app f-size-medium gameDiv noClick" itemscope itemtype="http://schema.org/Product" data-bigid="' + itemId + '">' +
                                                '<a target="_blank" href="#" data-clickname="www>entertainment>xbox-one>live-apps-hub>' + titleClickname + '>click" ' + datatrack + ' tabindex="-1">' +
                                                  '<picture style="background-color: ' + boxbgColor + '">' +
                                                    '<source srcset="' + itemBoxshot + '" media="(min-width:0)">' +
                                                    '<img class="c-image" srcset="' + itemBoxshot + '" src="' + itemBoxshot + '" ' +
                                                         'alt="' + itemTitle + ' logo">' +
                                                  '</picture>' +
                                                  '<div>' +
                                                    '<h4 class="c-subheading-4" itemprop="product name">' + itemTitle + '</h4>' +
                                                    //'<p class="c-paragraph-4">' + desc + '</p>' +
                                                  '</div>' +
                                                '</a>' +
                                              '</section>' +
                                            '</li>') 

        if (i === productQuantity - 1) {
          // post pop changes
          $("[data-bigid='9WZDNCRFJ3TJ'] picture").css("background-color", "white");
          $("[data-bigid='9WZDNCRFJ3TJ'] img").css("border", "1px solid lightgrey");
          $("[data-bigid='9NFQ49H668TB'] picture").addClass("high-contrast-svg-black");
        }
      }

      //if (count === 2) {
       // setTimeout(function() {
        //  GAMEBOXSHOT_SHOWHIDE.init()
        //}, 2500)
     // }
    
    }
    //$(".gameDivsWrapper").append()
  }

  $(".disclosureClose").click(function() {
    $(this).closest(".c-flyout").prev("button").click();
  })
  $(".disclosureContainer .glyph-prepend").click(function() {
    const butInd = $(this).index(".glyph-prepend");
    
    setTimeout(function() {
      if ($(".frDisclosure").css("display") !== 'none') {
        if ($(".CatAnnounce").text() === "l'info-bulle s'est ouverte") {
          $(".CatAnnounce").text("l'info-bulle s'est ouverte.")
        } else {
          $(".CatAnnounce").text("l'info-bulle s'est ouverte")
        }
      } else {  
        $(".CatAnnounce").text("l'info-bulle s'est fermée")
      }
      $(".disclosureClose")[butInd].focus()
    }, 30)
  })

  var x1RegionPop = (function() {
    $(".gameDiv a").each(function() {
      var rawHref = $(this).attr("href")
      var splitHref = rawHref.split("/")
      splitHref.splice(3, 0, urlRegion)
      var newHref = splitHref.join("/")
      $(this).attr("href", newHref)
    })
  })();

  // setTimeout(function() {
  //   var durl = document.URL.toLowerCase();
  //   if (durl.indexOf("recent") !== -1) {
  //     $("#selectRecent").click();
  //     var topofgames = $("#selectRecent").offset().top - 140;
  //     $(document).scrollTop(topofgames);
  //   }
  // }, 2500)

});
