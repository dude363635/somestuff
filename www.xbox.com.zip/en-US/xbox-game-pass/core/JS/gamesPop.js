$(document).ready(function() {

    var urlRegion = document.URL.split("/")[3].toLowerCase();
    
    if (urlRegion === "fr-fr") {
        $(".rotator-heading h3").each(function(i) {
        $(this).after('<span class="disclosureContainer">' +
        '<button class="glyph-prepend glyph-prepend-info" type="button" aria-describedby="frDisclosure' + i + '"></button>' +
        '<div class="c-flyout f-beak frDisclosure" id="frDisclosure' + i + '" role="tooltip" data-js-flyout-placement="top" data-js-flyout-dismissible="true" aria-hidden="true">' +
        '<button tabindex="0" class="disclosureClose" aria-label="bouton de fermeture pour l\'info-bulle">' +
        '<img src="https://assets.xboxservices.com/assets/3b/df/3bdfab2d-d1b1-4019-9bac-d953db4fd7fb.svg?n=Games-Catalog_Image-0_X-Button_230x120.svg" alt="bouton de fermeture">' +
        '</button>' +
        '<p class="c-paragraph">Voir <a href="https://www.microsoft.com/fr-fr/store/b/imprint" target="_blank">mentions légales et informations consommateurs</a> pour ' +
        'plus d\'informations sur les critères de classement.</p>' +
        '</div>' +
        '</span>')
    })
    
    $(".disclosureContainer .glyph-prepend").click(function() {
    const butInd = $(this).index(".glyph-prepend");
        
    setTimeout(function() {
        if ($(".frDisclosure").css("display") !== 'none') {
        if ($(".CatAnnounce").text() === "l'info-bulle s'est ouverte") {
        $(".CatAnnounce").text("l'info-bulle s'est ouverte.")
        } else {
        $(".CatAnnounce").text("l'info-bulle s'est ouverte")
        }
        } else {  
        $(".CatAnnounce").text("l'info-bulle s'est fermée")
        }
        $(".disclosureClose")[butInd].focus()
        }, 30)
        })
        $(".disclosureClose").click(function() {
        $(this).closest(".c-flyout").prev("button").click();
        })
    }
        
    // var onlineUrl = "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/new?Market=" + urlRegion.split("-")[1] + "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.Xbox&NumberOfPlayers=OnlineMultiplayerWithGold&count=2000&skipitems=0";
    const onlineUrl = "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/mostplayed?Market=" + urlRegion.split("-")[1] + "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.Xbox&NumberOfPlayers=OnlineMultiplayerWithGold&count=2000&skipitems=0"

    var onlineArray = [];
        
        // Get GUIDS
    $.get(onlineUrl)
        .done(function(responseData) {
            responseData.Items.forEach(function(e) {
            // Skip Call of Duty 6/12/2024
            if (e.Id !== "9N201KQXS5BM") {
                onlineArray.push(e.Id)
            }

    });

        // Adding Black Ops 6 to front of the Array
        onlineArray.unshift("9N58QRBG9WDG")
        onlineArray = onlineArray.splice(0, 24);

        var onlineGuids = onlineArray.join(",");

        console.warn(onlineGuids)

        gamesPop(onlineGuids);
    
    });
        
        
    function gamesPop(onlineGuids) {
    
        var countryCode = urlRegion.split("-")[1].toUpperCase();
        var guidOnline = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
    
        guidOnline = guidOnline.replace("GAMEIDS", onlineGuids);
    
        $.get(guidOnline)
        .done(function(responseData) {
        var onlineData = responseData;
            populateOne(onlineData);
        });
    }
        
    function populateOne(data) {
        var bigidUrls = biUrls.items.urls;
        var biuArray = Object.keys(bigidUrls);
        
        var productlength = data.Products.length;
        
        let poppedGames = 0;
        for (var x = 0; x < productlength; x++) {
          // Item Id/Title
          var itemId = data.Products[x].ProductId.toUpperCase();
          var itemTitle = data.Products[x].LocalizedProperties[0].ProductTitle;
          if (itemTitle === undefined) {
          itemTitle = "";
          }
          var itemUrlName = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, "");
          if (itemUrlName === "") {
              itemUrlName = "-"
          }
        
          var shortDesc = data.Products[x].LocalizedProperties[0].ShortDescription;
          if (shortDesc === "") {
          shortDesc = data.Products[x].LocalizedProperties[0].ProductDescription;
          }
          if (shortDesc === undefined) {
          shortDesc = "";
          }
          
          var imagesNum = data.Products[x].LocalizedProperties[0].Images.length;
          var imgEnd = 999;
          
          for (var j = 0; j < imagesNum; j++) {
              if (data.Products[x].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                  imgEnd = j;
                  break;
              }
          }
          
          if (imgEnd === 999) {
              for (var j = 0; j < imagesNum; j++) {
                  if (data.Products[x].LocalizedProperties[0].Images[j].Width < data.Products[x].LocalizedProperties[0].Images[j].Height) {
                      imgEnd = j;
                      break
                  }
              }
          }
          
          if (imgEnd === 999) {
              imgEnd = 1;
          }
          
          // Grabbing Image Path
          if (data.Products[x].LocalizedProperties[0].Images[imgEnd]) {
              var itemBoxshot = data.Products[x].LocalizedProperties[0].Images[imgEnd].Uri.replace("http:", "https:");
              var itemBoxshotSmall;
          } else {
              var itemBoxshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
              var itemBoxshotSmall = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
          }
          if (itemBoxshot.indexOf("store-images") !== -1) {
              itemBoxshotSmall = itemBoxshot + "?w=140";
              // itemBoxshot = itemBoxshot + "&h=300&w=200&format=jpg";
              itemBoxshot = itemBoxshot + "?w=280";
          } else {
              itemBoxshotSmall = itemBoxshot;
          }
          
          // URL
        //   if (biuArray.indexOf(itemId) === -1 || bigidUrls[itemId].toLowerCase().indexOf(urlRegion) !== -1) {
              var itemhref = 'https://www.xbox.com/' + urlRegion + '/games/store/' + itemUrlName + '/' + itemId;
        //   } else {
        //       var itemhref = bigidUrls[itemId].split("<exc>")[0];
        //       var splitHref = itemhref.split("/");
        //       splitHref.splice(3, 0, urlRegion);
        //       itemhref = splitHref.join("/");
        //   }

          var listprice;
          var msrpprice;
          var purchaseable = false;

          data.Products[x].DisplaySkuAvailabilities.forEach(function(sku) {
            sku.Availabilities.forEach(function(av, ind) {
              if (av.Actions.indexOf("Purchase") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) &&
                sku.Sku.Properties.IsTrial === false) {
                purchaseable = true;
                if ((av.OrderManagementData.Price.ListPrice !== av.OrderManagementData.Price.MSRP || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && ind !== 0) {
                    listprice = av.OrderManagementData.Price.ListPrice;
                } else {
                    listprice = av.OrderManagementData.Price.ListPrice;
                }
                if (ind === 0) {
                    msrpprice = av.OrderManagementData.Price.MSRP;
                }
                currencycode = av.OrderManagementData.Price.CurrencyCode;
                if (av.Properties.MerchandisingTags !== undefined) {
                  if (av.Properties.MerchandisingTags.indexOf("LegacyGamesWithGold") !== -1) {
                    listprice = msrpprice;
                  }
                }
              }
            })
          })

          if (msrpprice !== 0 || purchaseable === false) {
          
            $(".onlineCarousel" + " ul").append('<li>' +
                '<section class="m-product-placement-item f-size-large context-device f-clean" data-prodid="' + itemId + '">' +
                '<a target="blank" class="ignoreContStore" href="' + itemhref + '" data-retailer="MS Store" aria-label="' + itemTitle + '">' +
                '<picture>' +
                '<source srcset="' + itemBoxshot + '" media="(min-width:0)">' +
                '<img class="c-image" srcset="' + itemBoxshot + '" src="' + itemBoxshot + '" ' +
                'alt="' + itemTitle + ' boxshot">' +
                '</picture>' +
                '<div>' +
                '<h4 class="c-heading">' + itemTitle + '</h4>' +
                '</div>' +
                '</a>' +
                '</section>' +
                '</li>');
            poppedGames++ 
          }
          if (poppedGames >= 12) { break; }
        }
      
    $(".onlineCarousel").closest(".featured-games").fadeIn("slow");
    
    }
    
    
    xgpCore = {};
    
    let xboxGamePassCore = "CFQ7TTC0K5DJ";
    let xgpCoreSkuids = ["000C"];
    
    bigIdPop(xboxGamePassCore); 
    
    function bigIdPop(xboxGamePassCore) {
        let countryCode = urlRegion.split("-")[1].toUpperCase();
        let guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
    
        guidUrl = guidUrl.replace("GAMEIDS", xboxGamePassCore);
    
        $.get(guidUrl)
            .done(function(responseData) {
                let apiData = responseData;
                populateIds(apiData, 0);
                guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
    
            });
    
        function populateIds(data, count) {
            let productQuantity = data.Products.length;
            for (let i = 0; i < productQuantity; i++) {
                let itemTitle = data.Products[i].LocalizedProperties[0].ProductTitle;
                let itemId = data.Products[i].ProductId.toUpperCase();
            
            //get prices
            let listprice;
            let msrpprice;
            let currencycode;
            let skuIds;
            let monthTIO = false;
    
            // No 14 Day SKU
            let dayTIO = false;
    
            // Month SKU No 14 Day SKU
            data.Products[i].DisplaySkuAvailabilities.forEach(function(sku) {
                    sku.Availabilities.forEach(function(av) {
                        if (xgpCoreSkuids[0].indexOf(sku.Sku.SkuId) !== -1) {
                            skuIds = sku.Sku.SkuId;
                            if (av.Actions.indexOf("Purchase") !== -1 && av.Actions.indexOf("Browse") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && av.Actions.length > 2) {
                                listprice = av.OrderManagementData.Price.ListPrice;
                                msrpprice = av.OrderManagementData.Price.MSRP;
                                currencycode = av.OrderManagementData.Price.CurrencyCode;
                                if (listprice < msrpprice) {
                                    monthTIO = true;
                                };
    
                            };
                        };
    
                        if (listprice === undefined) {
                            listprice = 100000000;
                            msrpprice = 100000000;
                            currencycode = "USD";
                        };
                    });
                });
    
                
                xgpCore[itemId] = {
                    title: itemTitle,
                    ids: itemId,
                    msrpprice: msrpprice,
                    listprice: listprice,
                    skuids: skuIds,
                    currencycode: currencycode,
                    monthTIO: monthTIO,
                };
    
            };
    
    
                let activecheck = setInterval(function() {
                    let activeAjax = $.active;
                    if (activeAjax === 0) {
                        rendered();
                        clearInterval(activecheck);
                    };
                }, 500);
            
            
        };
    };
    
    
    function rendered() {
        // Prices
        let xboxGameCoreListPrice;
        let xboxGameCoremsrpPrice;

        // Copy
        let currregion;
        let monthCopy = monthStrings.locales[urlRegion].keyMonthCopy;
        let dayCopy = monthStrings.locales[urlRegion].keyDayTio;
        let firstMonthCopy = monthStrings.locales[urlRegion].keyMonthTio;

        if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
            // Core Pricing
            xboxGameCoreListPrice = xgpCore[xboxGamePassCore].listprice.toLocaleString(urlRegion, { style: 'currency', currency: xgpCore[xboxGamePassCore]["currencycode"] });
            xboxGameCoremsrpPrice = xgpCore[xboxGamePassCore].msrpprice.toLocaleString(urlRegion, { style: 'currency', currency: xgpCore[xboxGamePassCore]["currencycode"] });

            // Specific Locale Changes
            if (urlRegion === "tr-tr") {
                let symbol = xboxGameCoreListPrice.split("")[0];
                xboxGameCoreListPrice = xboxGameCoreListPrice.split(symbol)[1] + " " + symbol;
                xboxGameCoremsrpPrice = xboxGameCoremsrpPrice.split(symbol)[1] + " " + symbol;
            } else if (urlRegion === "zh-tw") {
                xboxGameCoreListPrice = "NT" + xboxGameCoreListPrice;
                xboxGameCoremsrpPrice = "NT" + xboxGameCoremsrpPrice;
            }
        }  else {
            if (urlRegion === "ar-ae") {
                currregion = "en-us";
            } else {
                currregion = "en-ca";
            }
            xboxGameCoreListPrice = xgpCore[xboxGamePassCore].listprice.toLocaleString(currregion, { style: 'currency', currency: xgpCore[xboxGamePassCore]["currencycode"] });
            xboxGameCoremsrpPrice = xgpCore[xboxGamePassCore].msrpprice.toLocaleString(currregion, { style: 'currency', currency: xgpCore[xboxGamePassCore]["currencycode"] });
        };

        // Core
        // document.querySelector(".sku-chooser__panel.right .price p").setAttribute("id", "coregamepass");
        document.querySelector(".sku-chooser__panel .price p").setAttribute("id", "coregamepass");

        let coregamepass = document.getElementById("coregamepass");

        // TIO Check
        if (xgpCore[xboxGamePassCore].listprice !== xgpCore[xboxGamePassCore].msrpprice) {
            // Remove Content First
            coregamepass.textContent = "";

            let spanCoregamepass = document.createElement("span");

            if (xgpCore[xboxGamePassCore].monthTIO && xgpCore[xboxGamePassCore].monthTIO === false) {
                spanCoregamepass.innerHTML = dayCopy.replace("PLACEHOLDER", xboxGameCoremsrpPrice) + xboxGameCoreListPrice + monthCopy;
            } else {
                spanCoregamepass.innerHTML = firstMonthCopy.replace("PLACEHOLDER", xboxGameCoremsrpPrice) + xboxGameCoreListPrice + monthCopy;
            }


        // No TIO Copy     
        } else {
            // Remove Content First
            coregamepass.textContent = "";

            let strongCoregamepass = document.createElement("strong");
            
            strongCoregamepass.innerHTML = xboxGameCoremsrpPrice + monthCopy;
            coregamepass.append(strongCoregamepass);
        };
    };

    monthStrings = {
        "locales": {
            "en-us": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong><strong>PLACEHOLDER</strong></strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "ar-ae": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "ar-sa": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "cs-cz": {
                "keyMonthCopy": " měsíčně",
                "keyMonthTio": "Získejte první měsíc za <strong>PLACEHOLDER</strong>, poté ",
                "keyDayTio": "Získejte prvních 14 dnů za <strong>PLACEHOLDER</strong>, poté "
            },
            "da-dk": {
                "keyMonthCopy": " pr.måned",
                "keyMonthTio": "Få din første måned for <strong>PLACEHOLDER</strong> og derefter ",
                "keyDayTio": "Få dine første 14 dage for <strong>PLACEHOLDER</strong> og derefter "
            },
            "de-at": {
                "keyMonthCopy": "/Monat",
                "keyMonthTio": "Hol dir deinen ersten Monat für <strong>PLACEHOLDER</strong>, danach ",
                "keyDayTio": "Hol dir die ersten 14 Tage für <strong>PLACEHOLDER</strong>, danach "
            },
            "de-ch": {
                "keyMonthCopy": "/Monat",
                "keyMonthTio": "Hol dir deinen ersten Monat für <strong>PLACEHOLDER</strong>, danach ",
                "keyDayTio": "Hol dir die ersten 14 Tage für <strong>PLACEHOLDER</strong>, danach "
            },
            "de-de": {
                "keyMonthCopy": "/Monat",
                "keyMonthTio": "Hol dir deinen ersten Monat für <strong>PLACEHOLDER</strong>, danach ",
                "keyDayTio": "Hol dir die ersten 14 Tage für <strong>PLACEHOLDER</strong>, danach "
            },
            "el-gr": {
                "keyMonthCopy": " /μήνα",
                "keyMonthTio": "Αποκτήστε τον πρώτο σας μήνα με <strong>PLACEHOLDER</strong>, στη συνέχεια ",
                "keyDayTio": "Αποκτήστε τις 14 πρώτες μέρες συνδρομής με <strong>PLACEHOLDER</strong>, στη συνέχεια "
            },
            "en-au": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "en-ca": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "en-gb": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "en-hk": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "en-ie": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "en-in": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "en-nz": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "en-sg": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "en-za": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "es-ar": {
                "keyMonthCopy": " al mes",
                "keyMonthTio": "Consigue el primer mes por <strong>PLACEHOLDER</strong>, luego ",
                "keyDayTio": "Consigue los primeros 14 días por <strong>PLACEHOLDER</strong>, luego "
            },
            "es-cl": {
                "keyMonthCopy": " al mes",
                "keyMonthTio": "Consigue el primer mes por <strong>PLACEHOLDER</strong>, luego ",
                "keyDayTio": "Consigue los primeros 14 días por <strong>PLACEHOLDER</strong>, luego "
            },
            "es-co": {
                "keyMonthCopy": " al mes",
                "keyMonthTio": "Consigue el primer mes por <strong>PLACEHOLDER</strong>, luego ",
                "keyDayTio": "Consigue los primeros 14 días por <strong>PLACEHOLDER</strong>, luego "
            },
            "es-es": {
                "keyMonthCopy": "/mes",
                "keyMonthTio": "Consigue el primer mes por <strong>PLACEHOLDER</strong>, y luego ",
                "keyDayTio": "Consigue los primeros 14 días por <strong>PLACEHOLDER</strong>, y luego "
            },
            "es-mx": {
                "keyMonthCopy": " al mes",
                "keyMonthTio": "Consigue el primer mes por <strong>PLACEHOLDER</strong>, luego ",
                "keyDayTio": "Consigue los primeros 14 días por <strong>PLACEHOLDER</strong>, luego "
            },
            "fi-fi": {
                "keyMonthCopy": "/kuukausi",
                "keyMonthTio": "Saat ensimmäisen kuukauden <strong>PLACEHOLDER</strong>:lla, minkä jälkeen tilaus maksaa ",
                "keyDayTio": "Saat ensimmäiset 14 päivää <strong>PLACEHOLDER</strong>:lla, minkä jälkeen tilaus maksaa "
            },
            "fr-be": {
                "keyMonthCopy": " par mois",
                "keyMonthTio": "Profite du premier mois pour seulement <strong>PLACEHOLDER</strong>, puis ",
                "keyDayTio": "Profite des 14 premiers jours pour seulement <strong>PLACEHOLDER</strong>, puis "
            },
            "fr-ca": {
                "keyMonthCopy": "/mois",
                "keyMonthTio": "Obtiens ton premier mois d’abonnement pour <strong>PLACEHOLDER</strong>, puis pour ",
                "keyDayTio": "Obtiens tes 14 premiers jours d’abonnement pour <strong>PLACEHOLDER</strong>, puis pour "
            },
            "fr-ch": {
                "keyMonthCopy": " par mois",
                "keyMonthTio": "Profite du premier mois pour seulement <strong>PLACEHOLDER</strong>, puis ",
                "keyDayTio": "Profite des 14 premiers jours pour seulement <strong>PLACEHOLDER</strong>, puis "
            },
            "fr-fr": {
                "keyMonthCopy": " par mois",
                "keyMonthTio": "Profite du premier mois pour seulement <strong>PLACEHOLDER</strong>, puis ",
                "keyDayTio": "Profite des 14 premiers jours pour seulement <strong>PLACEHOLDER</strong>, puis "
            },
            "he-il": {
                "keyMonthCopy": "/month",
                "keyMonthTio": "Get your first month for <strong>PLACEHOLDER</strong>, <br> then ",
                "keyDayTio": "Get your first 14 days for <strong>PLACEHOLDER</strong>, <br> then "
            },
            "hu-hu": {
                "keyMonthCopy": "/hónap",
                "keyMonthTio": "Az első hónap <strong>PLACEHOLDER</strong>, majd ",
                "keyDayTio": "Az első 14 nap <strong>PLACEHOLDER</strong>, majd "
            },
            "it-it": {
                "keyMonthCopy": " al mese",
                "keyMonthTio": "Ottieni il primo mese di abbonamento a <strong>PLACEHOLDER</strong>, e i successivi a ",
                "keyDayTio": "Acquista i primi 14 giorni a <strong>PLACEHOLDER</strong>, i successivi a "
            },
            "ja-jp": {
                "keyMonthCopy": "/月",
                "keyMonthTio": "最初の 1 か月は <strong>PLACEHOLDER</strong>、以降は月額、以降は月額 ",
                "keyDayTio": "最初の 14 日は <strong>PLACEHOLDER</strong>、以降は月額 "
            },
            "ko-kr": {
                "keyMonthCopy": "/월",
                "keyMonthTio": "처음 1개월은 <strong>PLACEHOLDER</strong>, 그 이후에는 ",
                "keyDayTio": "처음 14일은 <strong>PLACEHOLDER</strong>, 그 이후에는 "
            },
            "nb-no": {
                "keyMonthCopy": "/månedlig",
                "keyMonthTio": "Få den første måneden for <strong>PLACEHOLDER</strong>, deretter ",
                "keyDayTio": "Få dine første 14 dager for <strong>PLACEHOLDER</strong>, deretter "
            },
            "nl-be": {
                "keyMonthCopy": "/maand",
                "keyMonthTio": "Ontvang je eerste maand voor <strong>PLACEHOLDER</strong>, daarna ",
                "keyDayTio": "Ontvang je eerste 14 dagen voor <strong>PLACEHOLDER</strong>, daarna "
            },
            "nl-nl": {
                "keyMonthCopy": "/maand",
                "keyMonthTio": "Ontvang je eerste maand voor <strong>PLACEHOLDER</strong>, daarna ",
                "keyDayTio": "Ontvang je eerste 14 dagen voor <strong>PLACEHOLDER</strong>, daarna "
            },
            "pl-pl": {
                "keyMonthCopy": "/mies.",
                "keyMonthTio": "Zapewnij sobie pierwszy miesiąc w cenie <strong>PLACEHOLDER</strong>, a następnie w cenie ",
                "keyDayTio": "Zapewnij sobie pierwsze 14 dni w cenie <strong>PLACEHOLDER</strong>, a następnie w cenie "
            },
            "pt-br": {
                "keyMonthCopy": "/mês",
                "keyMonthTio": "Obtenha o seu primeiro mês por <strong>PLACEHOLDER</strong>, e depois ",
                "keyDayTio": "Obtenha os 14 primeiros dias por <strong>PLACEHOLDER</strong>; depois, "
            },
            "pt-pt": {
                "keyMonthCopy": "/mês",
                "keyMonthTio": "Obtém o teu primeiro mês por <strong>PLACEHOLDER</strong> e depois por ",
                "keyDayTio": "Obtém os primeiros 14 dias por <strong>PLACEHOLDER</strong> e depois por "
            },
            "ru-ru": {
                "keyMonthCopy": " в месяц",
                "keyMonthTio": "Получите первый месяц за <strong>PLACEHOLDER</strong>, а затем за ",
                "keyDayTio": "Получите первые 14 дней за <strong>PLACEHOLDER</strong>, а затем за "
            },
            "sk-sk": {
                "keyMonthCopy": "/mesiac",
                "keyMonthTio": "Prvý mesiac získajte za <strong>PLACEHOLDER</strong>, následne ",
                "keyDayTio": "Prvých 14 dní získate za <strong>PLACEHOLDER</strong>, následne "
            },
            "sv-se": {
                "keyMonthCopy": "/månad",
                "keyMonthTio": "Få första månaden för <strong>PLACEHOLDER</strong>, därefter ",
                "keyDayTio": "Få de första 14 dagarna för <strong>PLACEHOLDER</strong>, därefter "
            },
            "tr-tr": {
                "keyMonthCopy": "/ay",
                "keyMonthTio": "İlk ayınız için <strong>PLACEHOLDER</strong>, ardından ayda ",
                "keyDayTio": "İlk 14 gün için <strong>PLACEHOLDER</strong>, ardından ayda "
            },
            "zh-hk": {
                "keyMonthCopy": "/月",
                "keyMonthTio": "第一個月只要 <strong>PLACEHOLDER</strong>，然後每個月 ",
                "keyDayTio": "首 14 天只要 <strong>PLACEHOLDER</strong>，然後每個月 "
            },
            "zh-tw": {
                "keyMonthCopy": "/月",
                "keyMonthTio": "第一個月只要 <strong>PLACEHOLDER</strong>，之後每月 ",
                "keyDayTio": "前 14 天只要 <strong>PLACEHOLDER</strong>，之後每個月 "
            }
        }
    }

});