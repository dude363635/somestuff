// XGP Games  
$(document).ready(function() {
  var urlRegion = document.URL.split("/")[3].toLowerCase().slice(0, 5);

  if ($(".CatAnnounce").length === 0) {
      $("body").append('<div style="width:0;height:0;font-size:0;" class="CatAnnounce" aria-live="assertive"></div>');
  }
  const regionContent = globalContent.locales[urlRegion]; //change back to urlRegion once JSON localized
  let showRotators = true;

  //a11y
  (function checkQL() {
  if (urlRegion.includes("ja-jp,ko-kr")) {
      if (regionContent["keyQuicklook"].split(" ")[0].length > 11 || regionContent["keyQuicklook"].split(" ")[1].length > 11) {
      $("body").append('<style>.qlButton button.c-call-to-action {font-size:12px;padding:2px;}</style>')
      }
  }
  })();

  // targeted content
  if (typeof(xb_tgt) !== 'undefined') {
    console.log("running targeted content")
    const tgtContent = targetedContent.locales[urlRegion];
    var allKeys = Object.keys(tgtContent)
    var keysLength = allKeys.length

    for (var i = 0; i < keysLength; i++) {
      if (allKeys[i].indexOf("keyCopy") !== -1) {
          $("[data-loc-copy=" + allKeys[i] + "]").html(tgtContent[allKeys[i]]);
      } else if (allKeys[i].indexOf("keyImage") !== -1) {
          $("source[data-loc-image=" + allKeys[i] + "]").attr("srcset", tgtContent[allKeys[i]]);
          $("img[data-loc-image=" + allKeys[i] + "]").attr("srcset", tgtContent[allKeys[i]]).attr("srcset", tgtContent[allKeys[i]]);
      } else if (allKeys[i].indexOf("keyAlt") !== -1) {
          $("[data-loc-alt=" + allKeys[i] + "]").attr("alt", tgtContent[allKeys[i]]);
      } else if (allKeys[i].indexOf("keyLink") !== -1) {
          $("[data-loc-link=" + allKeys[i] + "]").attr("href", tgtContent[allKeys[i]]);
      } else if (allKeys[i].indexOf("keyCtahref") !== -1) {
          $("[data-loc-cta-href=" + allKeys[i] + "]").attr("data-cta-href", tgtContent[allKeys[i]]);
      } else if (allKeys[i].indexOf("keyAria") !== -1) {
          $("[data-loc-aria=" + allKeys[i] + "]").attr("aria-label", tgtContent[allKeys[i]]);
      } 
    }

    $(".optionalEl *:contains(####)").closest(".optionalEl").remove();
    $(".optionalEl").removeClass("optionalEl");
    if (tgtContent["keyPagebarinternalextern"] === "external") {
      $(".pageBar .CTAdiv button").eq(0).remove();
      $(".pageBar .CTAdiv button").attr("data-target", "_blank");
    } else {
      $(".pageBar .CTAdiv button").eq(1).remove();
    }
    $(".pageBar .CTAdiv button").removeClass("hidden");

    if ($(".SB-hero-banner .banner-background a").first().attr("href").charAt(0) === "#") {
      $(".SB-hero-banner .banner-background a").first().addClass("internalLink");
    }

    //data-learn
    if (tgtContent["keyDatactapagebar"] !== "####") {
      $(".CTAdiv button").attr("data-cta", tgtContent["keyDatactapagebar"]);
    }
    if (tgtContent["keyDatactaherocta1"] !== "####") {
      $(".SB-hero-banner .banner-background a").eq(0).attr("data-cta", tgtContent["keyDatactaherocta1"]);
    }
    if (tgtContent["keyDatactaherocta2"] !== "####") {
      $(".SB-hero-banner .banner-background a").eq(1).attr("data-cta", tgtContent["keyDatactaherocta2"]);
    }

    // horizontal channel handling
    if (xb_tgt === "core") {
      showRotators = false;
    } else if (xb_tgt === "cons") {
      $(".carouselselection").remove();
      $(".gcPc").remove();
      $(".gcConsole").removeClass("hidden");
      $("#GameCarousel1and2").css("display", "block");
      $("#GameCarousel3and4").css("display", "block");
    } else if (xb_tgt === "pcgp") {
      $(".carouselselection").remove();
      $(".gcConsole").remove();
      $(".gcPc").removeClass("hidden");
      $("#GameCarousel1and2").css("display", "block");
      $("#GameCarousel3and4").css("display", "block");
    } else {
      $("#GameCarousel1and2").css("display", "block");
      $("#GameCarousel3and4").css("display", "block");
    }
  } else {
    $("#GameCarousel1and2").css("display", "block");
    $("#GameCarousel3and4").css("display", "block");
  }
  // end targeted content

  if (urlRegion !== "en-us") {
    $("label.c-label[role='radio']").removeAttr("role");  
  }

  gamesperpage = 30;
  
  paginateclick = 0;

  var globalAdd = { // collections start at 12
      "d9234be9-3322-463a-95bd-a2d0789f6e4a": { 
          colname : "spaceconquestsconsole",
          plat: "xbox",
          title: "Space Conquests",
          spot: 13,
          startstring: "spaceconquestsconsole",
      },
      "7f34fc94-7a0a-42cd-81da-c6ce6cb3a5e3": { 
          colname : "spaceconquestspc",
          plat: "pc",
          title: "Space Conquests",
          spot: 12,
          startstring: "spaceconquestspc",
      },
      "db145e20-352b-435f-b0ef-26986ec7d58a": { 
          colname : "hispanicheritageconsole",
          plat: "xbox",
          title: "Celebrate Hispanic Heritage",
          spot: 14,
          startstring: "hispanicheritageconsole",
      },
      "6b7c99ad-d438-4993-b961-cb9fe82cdf34": { 
          colname : "hispanicheritagepc",
          plat: "pc",
          title: "Celebrate Hispanic Heritage",
          spot: 13,
          startstring: "hispanicheritagepc",
      }
  }

  const consoleCarouselLists = ["XGPPMPRecentlyAdded",
                                "popularconsole",
                                "consoleleavingsoon",
                                "hispanicheritageconsole"];
  const pcCarouselLists = ["pcrecent",
                           "pcgaVTpopular",
                           "pcleavingsoon",
                           "hispanicheritagepc"];
  const consoleCarouselLinks = ["#consolerecent",
                                "#consolepopular",
                                "#consoleleavingsoon",
                                "#hispanicheritageconsole"]
  const pcCarouselLinks = ["#pcrecent",
                           "#pcpopular",
                           "#pcleavingsoon",
                           "#hispanicheritagepc"]

  siglTitles = {};

  var newListIds = Object.keys(globalAdd);

  function totop() {
    var acctop = $(".thecatalog").offset().top - 80;
    $("HTML, BODY").animate({
      scrollTop: acctop
    }, 300);
  }
  $(document).on("click", ".openFilters", function() {
    $(".sortUi").addClass("mobileHidden");
    $(".searchgroup").addClass("mobileHidden");
    $(".pageBar").addClass("mobileHidden");
    $(".refineFilters").removeClass("mobileHidden");
    $("body").addClass("mobileOpen");
    $(".thecatalog").addClass("mobileOpen");
    $(".closeShowResults").addClass("mobileOpen");
  })
  $(document).on("click", ".closeFilters, .showResults", function() {
    $(".sortUi").removeClass("mobileHidden");
    $(".searchgroup").removeClass("mobileHidden");
    $(".pageBar").removeClass("mobileHidden");
    $(".refineFilters").addClass("mobileHidden");
    $("body").removeClass("mobileOpen");
    $(".thecatalog").removeClass("mobileOpen");
    $(".closeShowResults").removeClass("mobileOpen");
    $(".openFilters")[0].focus();
    totop();
  })

  $(document).on("click", ".platselectbutton", function(e) {
    e.preventDefault();
    const newPlat = $(this).attr("data-theplat");
    $(".platselectbutton").removeClass("platselected");
    $(this).addClass("platselected");
    $(".platformselection").attr("data-platselected", newPlat);
    $(".coreOnly").addClass("hidden");
    resetFilters(true, true, newPlat);
    removeSearchSummary();
    $(".CatAnnounce").text(regionContent["keyPlatselect"].replace("<PLACEHOLDER>", $(".platselected span").text()));
    if (newPlat === "pc") {
      $(".consoleOnly").addClass("hidden");
      $(".pcOnly").removeClass("hidden");
    } else {
      $(".consoleOnly").removeClass("hidden");
      $(".pcOnly").addClass("hidden");
    }
    filtersort();
  })

  function resetFilters(resetMemberships, resetCollections, plat) {
    const membClasses = {"xbox": "consoleOnly", "pc": "pcOnly"}
    $(".c-drawer.f-checkbox a").attr("aria-checked", "false").removeClass("f-selected").attr("clicked", "false");
    if (resetMemberships === true && resetCollections === true) {
      $(".collectionsFilter." + membClasses[plat] + " input").addClass("platformSelecting");
      $(".membershipsFilter." + membClasses[plat] + " input").addClass("platformSelecting");
      $(".collectionsFilter." + membClasses[plat] + " input").first().click();
      $(".membershipsFilter." + membClasses[plat] + " input").first().click();
    } else if (resetMemberships === true) {
      $(".membershipsFilter." + membClasses[plat] + " input").addClass("platformSelecting");
      $(".membershipsFilter." + membClasses[plat] + " input").first().click();
    } else if (resetCollections === true) {
      $(".collectionsFilter." + membClasses[plat] + " input").addClass("platformSelecting");
      $(".collectionsFilter." + membClasses[plat] + " input").first().click();
    }
    $(".collectionsFilter." + membClasses[plat] + " input").removeClass("platformSelecting");
    $(".membershipsFilter." + membClasses[plat] + " input").removeClass("platformSelecting");
  }

  var win10user = false;
  if (navigator.userAgent.indexOf("Windows NT 10") > -1) { win10user = true; }
  if (win10user === false) {
      $(".win10ban").remove();
  } else {
      $(".nonwin10ban").remove();
      
  }

  if (navigator.userAgent.indexOf("iPhone") !== -1 || navigator.userAgent.indexOf("iPad") !== -1 || navigator.userAgent.indexOf("Android") !== -1) { 
      $(".theme-light.specialBanner.eappcBanner, .theme-light.specialBanner.ubisoftpcBanner, .theme-light.specialBanner.allpcBanner").remove();
  }
  
  regionRatingOrgs = { "en-us" : "ESRB", "en-au" : "COB-AU", "en-hk" : "IARC", "en-in" : "IARC", "en-nz" : "OFLC-NZ", "en-sg" : "IARC", "ja-jp" : "CERO", "ko-kr" : "GRB", "zh-hk" : "IARC", "zh-tw" : "CSRR", "ar-ae" : "IARC", "ar-sa" : "IARC", "cs-cz" : "PEGI", "da-dk" : "PEGI", "de-at" : "PEGI", "de-ch" : "PEGI", "de-de" : "USK", "el-gr" : "PEGI", "en-gb" : "PEGI", "en-ie" : "PEGI", "en-za" : "FPB", "fi-fi" : "PEGI", "fr-be" : "PEGI", "fr-ch" : "PEGI", "fr-fr" : "PEGI", "he-il" : "PEGI", "hu-hu" : "PEGI", "it-it" : "PEGI", "nb-no" : "PEGI", "nl-be" : "PEGI", "nl-nl" : "PEGI", "pl-pl" : "PEGI", "pt-pt" : "PEGI", "ru-ru" : "PCBP", "sk-sk" : "PEGI", "sv-se" : "PEGI", "tr-tr" : "PEGI", "en-ca" : "ESRB", "fr-ca" : "ESRB", "es-ar" : "ESRB", "es-cl" : "CCC", "es-co" : "ESRB", "es-es" : "PEGI", "es-mx" : "ESRB", "pt-br": "DJCTQ" };
  //overrides
  fullcarouselimages = ["9PGSCB1X2P7G", "BRKX5CRMRTC2", "BZGJRJC1FGF3", "BPL68T0XK96W", "BV0NSD4NN4V4", "BPQ955FQFPH6", "BZRK5C951KK7", "BWPKGQV97N7N", "BPJ686W6S0NH", "9PDV8FKWP3B4", "BNG91PT95LQN", "C0QN5M9ZTC38", "C0GWTPD0S8S1", "C40860J5R2MP", "BR7X7MVBBQKM", "C4LLMHFQ1BXQ", "9NDDH3R9DF40", "BS36XT3Z5ZKL", "C17SFN1NXZ37", "BVFDTJ1XF6CS", "C4VLMWJWM7BG", "C57L9GR0HHB7", "BX4RTV7M28VS", "BS37BWWP2PZ1", "BW2XDRNSCCPZ", "BSZM480TSWGP", "BRGPD72KHM3Q", "C3KLDKZBHNCZ", "C3HQKX3B35PD", "C2N9CS4FS1QR", "C0X2HNVH08FB", "9NBLGGH51QT4", "BPBC39LH0Q9B", "BVV8LHVGPBS3", "BWC95BZPFBS7", "BXL4538LK4DK", "BQMVWCMB8P59", "C2BTFXNW3TTT", "9P4WKZXWP1QW", "BRJGPRMBV1NT"]
  omitimages = ["https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTcB7WVDn.f4Uli2dyqvJAR1iMrHLquSMr6CthfgctOtrvg54xKrmjYXQ1BkhiG4i6RT1HzvxN47vdGKnWcFR1BrIpKbs257dc4YHkUyePffX5a.c3Z9hfO6bkguMWKak4QJZyll1iBDl8IFZ12EEgxVXSW2Bh6iGMM6qEszDFtB80-&w=980&format=jpg"]
      //omitgames = ["9PNQKHFLD2WQ"];
  swapgames = { "9PNQKHFLD2WQ": "9PNJXVCVWD4K" }
      //end overrides
  pageloadfocus = 0;

  var ratingorg = regionRatingOrgs[urlRegion];

  // noncloud regions
  const nonCloudRegions = "ar-ae, ar-sa, el-gr, en-hk, en-in, en-sg, en-za, es-cl, es-co, he-il, ru-ru, tr-tr, zh-hk, zh-tw";
  if (nonCloudRegions.indexOf(urlRegion) > -1) {
    $(".boxShots-gallery").addClass("nonCloudRegion");
  }

  //android detection
  var androiduser = false;
  if (navigator.userAgent.indexOf("Android") > -1) { androiduser = true; }

  if (androiduser === true) {
      $(".androidBanner").show();
  }

  $(".modalDialog .close").click(function() {
      $(".modalDialog").hide();
  });

  xgpGuidArray = ["eab7757c-ff70-45af-bfa6-79d3cfb2bf81", "a884932a-f02b-40c8-a903-a008c23b1df1", "f13cf6b4-57e6-4459-89df-6aec18cf0538",
      "3fdd7f57-7092-4b65-bd40-5a9dac1b2b84", "fc40d1b9-85ec-422d-b454-8685fb31776e", "4c894453-744d-4b35-acea-40df9f4312b1", "fafb048d-9850-4447-ae20-f8f698bd208a", "34031711-5a70-4196-bab7-45757dc2294e",
      "099d5213-25e2-4896-bf09-33432f1c6e66","3b2da8c2-a0b0-49d5-aab9-f0ac40beb43d", "8e7cd765-1293-44e0-95bb-8257e2bf0221", 
      "393f05bf-e596-4ef6-9487-6d4fa0eab987", "cc7fc951-d00f-410e-9e02-5e4628e04163", "2e8e2cdf-f1bb-4e7e-8295-04949a26f6cc", "1e2ce757-e84f-4d2c-9243-34b81912644a", "c621daed-3d22-4745-afc9-19ed77a2e9be",
      "9fd6a075-57c3-4084-82d0-b00e2d43424a", "25d0b8d5-1a6a-489f-8195-219c96656497","f6f1f99f-9b49-4ccd-b3bf-4d9767a77f5e", "e7590b22-e299-44db-ae22-25c61405454c", "29a81209-df6f-41fd-a528-2ae6b91f719c",
      "88c10a22-33b5-4e24-90b6-125bee02da39", "ebedc400-a688-4929-b794-4435b2e1ab0a", "f576ca76-9aad-4ac7-a0f0-71429ef36850", "c4be032d-0f42-4df5-8934-1758748cf7f0",
      "95f39cf3-48ec-4d3c-83e6-a7f6916fbdfe", "e68225ce-e42f-4156-998d-697bf985da73", "38441e3f-26c6-498c-8b84-0ca20a3785af", "200674bd-7bd4-4360-bd0f-af8cd899839f",
      "5d6c2384-b30e-4717-86f6-e684e819622b", "7d8e8d56-c02f-4711-afec-73a80d8e9261", "796c328b-4a17-4996-99f8-0edb59bef85a", "b8900d09-a491-44cc-916e-32b5acae621b",
      "6661f37d-6159-4c9c-81d8-668af0a78b04", "eab7757c-ff70-45af-bfa6-79d3cfb2bf81", "095bda36-f5cd-43f2-9ee1-0a72f371fb96", "18e0b0af-cefe-4492-845c-b9f6ab8737f8","4b59700c-801f-494a-a34c-842b8c98f154",
      "4165f752-d702-49c8-886b-fb57936f6bae", "a672552e-fdc2-4ecd-96e9-b8409193f524", "0f0bccc0-cdc8-4e1a-bfca-4b7da5c6c418", "f0e9ffe0-176e-41af-be11-c40a05d26e2c", 
      "609d944c-d395-4c0a-9ea4-e9f39b52c1ad","f6505a9f-ec7d-4eb8-a496-be83f8f35829", "0ee8fddb-8a59-45c5-aebb-9d4adbe832c5","1d33fbb9-b895-4732-a8ca-a55c8b99fa2c","a5a535fb-d926-4141-9ce4-9f6af8ca22e7",
      "9c09d734-1c45-4740-ae7f-fd73ff629880", "79fe89cf-f6a3-48d4-af6c-de4482cf4a51","490f4b6e-a107-4d6a-8398-225ee916e1f2","19e5b90a-5a20-4b1d-9dda-6441ca632527","4e641124-9279-46a5-a73f-4e20d89c787c",
      "5dfd8fdd-2fd3-4e7f-b9f8-175e96b1adac", "7dff3157-a037-4449-85db-8086d51ec4f8",
      "62ba1846-03bb-4209-aeea-35110a9935f1", "39d48297-93f9-4b5a-85dd-641a337b212c",
      "6d18c7d7-7f62-4c87-b1b7-b5555c5752d0", "0767da77-95d4-4023-9971-d1a9756fccef",
      "bd8e0e95-78d1-42fd-aee2-291210df273d", "15d529d7-0b6b-431f-a0fe-fa01d6a6e9c6",
      "3950236c-9aa7-433d-88fd-96023d276346", "f0e9ffe0-176e-41af-be11-c40a05d26e2c","43074527-8b07-42ca-af99-cf481e756aad"
  ];

  var pcarrays = [];
  var xgplistUrl = "https://catalog.gamepass.com/sigls/v2?id=CATEGORY&language=LANG&market=MARK";
  var xgplistUrlPC = "https://catalog.gamepass.com/sigls/v2?id=CATEGORY&language=LANG&market=MARK";

  guidAmpt = {
      "XGPPMPRecentlyAdded": "f13cf6b4-57e6-4459-89df-6aec18cf0538",
      "XGPPMPIDXbox": "fc40d1b9-85ec-422d-b454-8685fb31776e",
      "actionconsole": "fafb048d-9850-4447-ae20-f8f698bd208a",
      "actionpc": "3b2da8c2-a0b0-49d5-aab9-f0ac40beb43d",
      "allGamesXboxCore": "34031711-5a70-4196-bab7-45757dc2294e",
      "popularGamesXboxCore": "099d5213-25e2-4896-bf09-33432f1c6e66",
      "subsxgprecentlyadded": "f13cf6b4-57e6-4459-89df-6aec18cf0538",
      "subsxgpchannel9": "fc40d1b9-85ec-422d-b454-8685fb31776e",
      "subsxgpchannel5": "fafb048d-9850-4447-ae20-f8f698bd208a",
      "familyconsole": "8e7cd765-1293-44e0-95bb-8257e2bf0221",
      "consoleleavingsoon": "393f05bf-e596-4ef6-9487-6d4fa0eab987",
      "pcrecent": "3fdd7f57-7092-4b65-bd40-5a9dac1b2b84",
      "pccomingsoon": "4165f752-d702-49c8-886b-fb57936f6bae",
      "pcgaVTpopular": "a884932a-f02b-40c8-a903-a008c23b1df1",
      "indieconsole": "2e8e2cdf-f1bb-4e7e-8295-04949a26f6cc",
      "pcgaVTIndies": "1e2ce757-e84f-4d2c-9243-34b81912644a",
      "pcgaVTRPG": "c621daed-3d22-4745-afc9-19ed77a2e9be",
      "pcgaVTStrategy": "9fd6a075-57c3-4084-82d0-b00e2d43424a",
      "strategyconsole": "25d0b8d5-1a6a-489f-8195-219c96656497",
      "pcgaVTFamily": "0f0bccc0-cdc8-4e1a-bfca-4b7da5c6c418",
      "pcleavingsoon": "cc7fc951-d00f-410e-9e02-5e4628e04163",
      "allconsole": "f6f1f99f-9b49-4ccd-b3bf-4d9767a77f5e",
      "popCloud": "e7590b22-e299-44db-ae22-25c61405454c",
      "allCloud": "29a81209-df6f-41fd-a528-2ae6b91f719c",
      "mobileCloud": "88c10a22-33b5-4e24-90b6-125bee02da39",
      "aaCloud": "ebedc400-a688-4929-b794-4435b2e1ab0a",
      "famCloud": "f576ca76-9aad-4ac7-a0f0-71429ef36850",
      "fightCloud": "c4be032d-0f42-4df5-8934-1758748cf7f0",
      "indieCloud": "95f39cf3-48ec-4d3c-83e6-a7f6916fbdfe",
      "rpgCloud": "e68225ce-e42f-4156-998d-697bf985da73",
      "shooterCloud": "38441e3f-26c6-498c-8b84-0ca20a3785af",
      "simCloud": "200674bd-7bd4-4360-bd0f-af8cd899839f",
      "stratCloud": "5d6c2384-b30e-4717-86f6-e684e819622b",
      "touchCloud": "7d8e8d56-c02f-4711-afec-73a80d8e9261",
      "sportsConsole": "796c328b-4a17-4996-99f8-0edb59bef85a",
      "sportsPC": "6661f37d-6159-4c9c-81d8-668af0a78b04",
      "rpgConsole": "18e0b0af-cefe-4492-845c-b9f6ab8737f8",
      "eaplayAll": "b8900d09-a491-44cc-916e-32b5acae621b",
      "eaplayConsole": "b8900d09-a491-44cc-916e-32b5acae621b",
      "popularconsole": "eab7757c-ff70-45af-bfa6-79d3cfb2bf81",
      "consolecomingsoon": "095bda36-f5cd-43f2-9ee1-0a72f371fb96",
      "pdoConsole": "a672552e-fdc2-4ecd-96e9-b8409193f524",
      "pdoPC": "4b59700c-801f-494a-a34c-842b8c98f154",
      "allpc": "609d944c-d395-4c0a-9ea4-e9f39b52c1ad",
      "ubisoftconsole": "a5a535fb-d926-4141-9ce4-9f6af8ca22e7",
      "ubisoftpc": "9c09d734-1c45-4740-ae7f-fd73ff629880",
      "eagametrialsconsole": "490f4b6e-a107-4d6a-8398-225ee916e1f2",
      "eagametrialspc": "19e5b90a-5a20-4b1d-9dda-6441ca632527",
   "riotgamesconsole": "4e641124-9279-46a5-a73f-4e20d89c787c",
      "riotgamespc": "4e641124-9279-46a5-a73f-4e20d89c787c",
      "bethxbox": "f6505a9f-ec7d-4eb8-a496-be83f8f35829",
      "bethpc": "79fe89cf-f6a3-48d4-af6c-de4482cf4a51",
      "optXS": "0ee8fddb-8a59-45c5-aebb-9d4adbe832c5",
      "eaplayPC": "1d33fbb9-b895-4732-a8ca-a55c8b99fa2c",
      "idxboxpc": "4c894453-744d-4b35-acea-40df9f4312b1",
      "platformerconsole": "5dfd8fdd-2fd3-4e7f-b9f8-175e96b1adac",
      "platformerpc": "7dff3157-a037-4449-85db-8086d51ec4f8",
      "puzzleconsole": "62ba1846-03bb-4209-aeea-35110a9935f1",
      "puzzlepc": "39d48297-93f9-4b5a-85dd-641a337b212c",
      "racingconsole": "6d18c7d7-7f62-4c87-b1b7-b5555c5752d0",
      "racingpc": "0767da77-95d4-4023-9971-d1a9756fccef",
      "shootersconsole": "bd8e0e95-78d1-42fd-aee2-291210df273d",
      "shooterspc": "15d529d7-0b6b-431f-a0fe-fa01d6a6e9c6",
      "simconsole": "3950236c-9aa7-433d-88fd-96023d276346",
      "simpc": "f0e9ffe0-176e-41af-be11-c40a05d26e2c"
  }

  for (var p = 0; p < newListIds.length; p++) {
      xgpGuidArray.unshift(newListIds[p]);
      guidAmpt[globalAdd[newListIds[p]].colname] = newListIds[p];
  }

  // do rotators first
  let rotatorSigls = []
  consoleCarouselLists.forEach(function(list) {
    const sigl = guidAmpt[list];
    rotatorSigls.push(sigl)
  })
  pcCarouselLists.forEach(function(list) {
    const sigl = guidAmpt[list];
    rotatorSigls.push(sigl)
  })

  xgplistUrl = xgplistUrl.replace("LANG", urlRegion).replace("MARK", urlRegion.split("-")[1].toUpperCase());
  xgplistUrlPC = xgplistUrlPC.replace("LANG", urlRegion).replace("MARK", urlRegion.split("-")[1].toUpperCase());

  fullGameArray = [];

  function replacepcwithcon(pcbid, conbid) {
      pcarrays.forEach(function(p) {
          var replaceind = p.indexOf(pcbid);
          p[replaceind] = conbid;
      })
  }

  for (var i = 0; i < rotatorSigls.length; i++) {
    if (pcarrays.indexOf(rotatorSigls[i]) === -1) {
        var catUrl = xgplistUrl.replace("CATEGORY", rotatorSigls[i]);
    } else {
        var catUrl = xgplistUrlPC.replace("CATEGORY", rotatorSigls[i]);
    }

    (function() {
        xgpLists(catUrl, i, rotatorSigls[i], rotatorSigls.length, true);
    })(i);
  }

  function runAll() {
    for (var i = 0; i < xgpGuidArray.length; i++) {
      if (pcarrays.indexOf(xgpGuidArray[i]) === -1) {
          var catUrl = xgplistUrl.replace("CATEGORY", xgpGuidArray[i]);
      } else {
          var catUrl = xgplistUrlPC.replace("CATEGORY", xgpGuidArray[i]);
      }

      (function() {
        // if (!rotatorSigls.includes(xgpGuidArray[i])) {
          xgpLists(catUrl, i, xgpGuidArray[i], xgpGuidArray.length, false);
        // }
      })(i);
    }
  }

  function xgpLists(url, index, arrayname, arraylength, rotators) {
      $.get(url)
          .done(function(responseData) {
              listData = responseData;
              var idlength = listData.length
              var idArray = [];
              for (var j = 1; j < idlength; j++) {
                  if (swapgames[listData[j].id] !== undefined) {
                      if (idArray.indexOf(swapgames[listData[j].id]) === -1) {
                          idArray.push(swapgames[listData[j].id])
                      }
                  } else {
                      if (idArray.indexOf(listData[j].id) === -1) {
                          idArray.push(listData[j].id)
                      }
                  }
              }
              var apiTitle = listData[0].title;
              var apiDesc = listData[0].description;
              if (globalAdd[arrayname] !== undefined) {
                  if (globalAdd[arrayname].title.indexOf("^") !== -1) { // use json loc titles
                      var titleVar = globalAdd[arrayname].title.split("^")[1];
                      globalAdd[arrayname].title = titleStrings[titleVar].locales[urlRegion].keyTitle;
                  } else if (globalAdd[arrayname].title.indexOf("**") !== -1) { // regions listed after ** use string, not json loc title
                      var specialtitlelocs = globalAdd[arrayname].title.split("**")[1];
                      if (specialtitlelocs.indexOf(urlRegion) !== -1) {
                          globalAdd[arrayname].title = globalAdd[arrayname].title.split("**")[0];
                      } else {
                          globalAdd[arrayname].title = apiTitle;
                      }
                  } else if (globalAdd[arrayname].title.indexOf("%") !== -1) { // use string globally
                      globalAdd[arrayname].title = globalAdd[arrayname].title.split("%")[1];
                  } else {
                      globalAdd[arrayname].title = apiTitle;
                  }
              }
              siglTitles[arrayname] = {};
              siglTitles[arrayname].title = apiTitle;
              siglTitles[arrayname].desc = apiDesc;
              gameIdArrays[arrayname] = [];
              if (rotators === false) {
                gameIdArrays[arrayname] = idArray;
              } else {
                gameIdArrays[arrayname] = idArray.slice(0,12);
              }
              

              //gameIdArrays[arrayname] = gameIdArrays[arrayname].filter(function(v) { return omitgames.indexOf(v) === -1});
              let idLength = 12;
              if (rotators === false) {
                idLength = idArray.length;
              } 
              for (var a = 0; a < idLength; a++) {
                  if (fullGameArray.indexOf(idArray[a]) === -1 && idArray[a] !== undefined) {
                      fullGameArray.push(idArray[a])
                  }
              }
              if (index === arraylength - 1) {
                  var activecheck1 = setInterval(function() {
                      var activeAjax = $.active;
                      if (activeAjax === 0) {
                          chunktotal = Math.ceil(fullGameArray.length / 20)
                          if (rotators === true) {
                            ratingsApi(rotators);
                          } else {
                            grabLists(rotators);
                          }
                          clearInterval(activecheck1);
                      }
                  }, 500);

              }
          })
  }


  function ratingsApi(rotators) {
    var ratingsUrl = "https://displaycatalog.mp.microsoft.com/v7.0/ratings?market=US&languages=LANG&MS-CV=DGU1mcuYo0WMMp+F.1"
    ratingsUrl = ratingsUrl.replace("US", urlRegion.split("-")[1]).replace("LANG", urlRegion);

    $.get(ratingsUrl)
      .done(function(listData) {
        ratingData = listData;
        // grabLists(rotators);
        popJSON(rotators);
      })
  }

  var capArray = ["&gamecapabilities=capability4k:fourk", "&gamecapabilities=capabilityhdr:HDRGaming", "&NumberOfPlayers=OnlineMultiplayerWithGold:multionline", "&NumberOfPlayers=LocalMultiplayer:multilocal",
      "&NumberOfPlayers=CoopSupportOnline:cooponline", "&NumberOfPlayers=CoopSupportLocal:cooplocal",
      "&gamecapabilities=consolecrossgen:cross", "&gamecapabilities=ConsoleGen9Optimized:genNine"
  ];

  function grabLists(rotators) {
      var recoUrl = "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/LIST?Market=US&Language=EN&ItemTypes=Game&deviceFamily=Windows.Xbox&count=2000&skipitems=0"
      recoUrl = recoUrl.replace("US", urlRegion.split("-")[1]).replace("EN", urlRegion.split("-")[0]);

      var capUrls = ["https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/TopPaid?Market=" + urlRegion.split("-")[1] +
          "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0",
          "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/TopFree?Market=" + urlRegion.split("-")[1] +
          "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0",
          "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/New?Market=" + urlRegion.split("-")[1] +
          "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0",
          "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/ComingSoon?Market=" + urlRegion.split("-")[1] +
          "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0"
      ]

      // capability list arrays
      for (var i = 0; i < capArray.length; i++) {
          var arrayname = capArray[i].split(":")[1];
          gameIdArrays[arrayname] = [];
      }
      for (var i = 0; i < capUrls.length; i++) {
          (function(i) {
              for (var j = 0; j < capArray.length; j++) {
                  (function(j) {
                      var listreplace = capArray[j].split(":")[0];
                      var arrayname = capArray[j].split(":")[1];
                      var listUrl = capUrls[i].replace("CAPABILITY", listreplace);
                      $.get(listUrl)
                          .done(function(responseData) {
                              var totalitems = responseData.PagingInfo.TotalItems;
                              responseData.Items.forEach(function(e) {
                                  if (gameIdArrays[arrayname].indexOf(e.Id) === -1) {
                                      gameIdArrays[arrayname].push(e.Id);
                                  }
                              })
                              if (totalitems > 200) {
                                  var chunks = Math.ceil(totalitems / 200)
                                  largeList(listUrl, arrayname, chunks, true);
                              }
                              if (i === capUrls.length - 1 && j === capArray.length - 1) {
                                  var recoactivecheck = setInterval(function() {
                                      var recoactiveAjax = $.active;
                                      if (recoactiveAjax === 0) {
                                          recodone(rotators);
                                          clearInterval(recoactivecheck);
                                      }
                                  }, 500);
                              }
                          })
                  })(j);
              }
          })(i);
      }


      function largeList(url, arrayname, chunks, cap) {
          for (var i = 1; i < chunks; i++) {
              (function(i) {
                  var skipnum = 200 * i;
                  var largeUrl = url.replace("skipitems=0", "skipitems=" + skipnum);
                  $.get(largeUrl)
                      .done(function(responseData) {
                          responseData.Items.forEach(function(e) {
                              if (cap === true) {
                                  if (gameIdArrays[arrayname].indexOf(e.Id) === -1) {
                                      gameIdArrays[arrayname].push(e.Id);
                                  }
                              } else {
                                  if (excludebids.indexOf(e.Id) === -1) {
                                      gameIdArrays[arrayname].push(e.Id);
                                  }
                              }
                          })
                      })
              })(i);
          }
      }

      function recodone() {
          popJSON(rotators);
      }

  };

  function popJSON(rotators) {
      // add new collections
    if (rotators === false) {
      for (var p = 0; p < newListIds.length; p++) {
        let riotAdjust = 0;
        if ($("[value='riotgamesconsole']").length === 0 && globalAdd[newListIds[p]].plat === "xbox") {
          riotAdjust = 1
        }
        const inputName = $(".collections-" + globalAdd[newListIds[p]].plat + " label")
                          .eq(globalAdd[newListIds[p]].spot - riotAdjust - 2).find("input").attr("name");
        $(".collections-" + globalAdd[newListIds[p]].plat + " label").eq(globalAdd[newListIds[p]].spot - riotAdjust - 1)
        .after('<label class="c-label" data-label="' + globalAdd[newListIds[p]].colname + '">' +
          '<input aria-posinset="1" aria-setsize="12" id="default6-1' + p + p + p + '" type="radio" aria-label="' +
            regionContent["keyFilterby"].replace("<PLACEHOLDER>", globalAdd[newListIds[p]].title) + 
            '" name="' + inputName + '" value="' + globalAdd[newListIds[p]].colname + '">' +
            '<span>' + globalAdd[newListIds[p]].title + '</span></label>');
      }
      if (newListIds.length > 0) {
        const xbLen = $(".collections-xbox label").length;
        $(".collections-xbox label").each(function(ind) {
          $(this).find("input").attr("aria-posinset", ind + 1).attr("aria-setsize", xbLen);
        })
        const coreLen = $(".collections-core label").length;
        $(".collections-core label").each(function(ind) {
          $(this).find("input").attr("aria-posinset", ind + 1).attr("aria-setsize", coreLen);
        })
        const pcLen = $(".collections-pc label").length;
        $(".collections-pc label").each(function(ind) {
          $(this).find("input").attr("aria-posinset", ind + 1).attr("aria-setsize", pcLen);
        })
      }

      //Removal of Collections
    //   var removeExLocale = ["hu-hu", "ru-ru", "ar-sa", "tr-tr", "ar-ae", "en-sg", "en-in"];

    //   if (removeExLocale.indexOf(urlRegion) !== -1) {
    //       $("[data-label='spaceconquestsconsole']").remove();
    //       $("[data-label='spaceconquestspc']").remove();
    //       $("#GameCarousel3and4 .featured-games:not(.leavingSoon)").remove();
    //   }

      if (urlRegion === "ru-ru") {
          $("[data-label='spaceconquestsconsole']").remove();
          $("[data-label='spaceconquestspc']").remove();
          $("[data-label='hispanicheritageconsole']").remove();
          $("[data-label='hispanicheritagepc']").remove();
      }
    }


      // translate new GUID lists to old names
      var guidAmptKeys = Object.keys(guidAmpt);
      for (var i = 0; i < guidAmptKeys.length; i++) {
          if (guidAmpt[guidAmptKeys[i]].indexOf(",") > -1) {
              var a = gameIdArrays[guidAmpt[guidAmptKeys[i]].split(",")[0]];
              var b = gameIdArrays[guidAmpt[guidAmptKeys[i]].split(",")[1]];
              var c = [];
              for (var j = 0; j < a.length; j++) {
                  c.push(a[j]);
              }
              for (var j = 0; j < b.length; j++) {
                  if (c.indexOf(b[j]) === -1) {
                      c.push(b[j]);
                  }
              }
              gameIdArrays[guidAmptKeys[i]] = c;
              siglTitles[guidAmptKeys[i]] = c;
          } else {
              gameIdArrays[guidAmptKeys[i]] = gameIdArrays[guidAmpt[guidAmptKeys[i]]];
              siglTitles[guidAmptKeys[i]] = siglTitles[guidAmpt[guidAmptKeys[i]]];
              delete siglTitles[guidAmpt[guidAmptKeys[i]]]
          }
      }

      // make leaving soon pc and console lists
      // gameIdArrays["SubsXGPAllGames"] = gameIdArrays["subsxgpchannel3"];

      const fgContent = featuredGames.locales[urlRegion];
      var allKeys = Object.keys(fgContent)
      var keysLength = allKeys.length

      setTimeout(function() {
        if (rotators === true) {
          for (var i = 0; i < keysLength; i++) {
              if (allKeys[i].indexOf("keyCopy") !== -1) {
                  $("[data-loc-copy=" + allKeys[i] + "]").text(fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyImage") !== -1) {
                  $("source[data-loc-image=" + allKeys[i] + "]").attr("srcset", fgContent[allKeys[i]]);
                  $("img[data-loc-image=" + allKeys[i] + "]").attr("srcset", fgContent[allKeys[i]]).attr("srcset", fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyAlt") !== -1) {
                  $("[data-loc-alt=" + allKeys[i] + "]").attr("alt", fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyLink") !== -1) {
                  $("[data-loc-link=" + allKeys[i] + "]").attr("href", fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyClickname") !== -1) {
                  $("[data-loc-clickname=" + allKeys[i] + "]").attr("data-clickname", fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyRetailer") !== -1) {
                  $("[data-loc-retailer=" + allKeys[i] + "]").attr("data-retailer", fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyAria") !== -1) {
                  $("[data-loc-aria=" + allKeys[i] + "]").attr("aria-label", fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyInclude") !== -1) {
                  $("[data-loc-include=" + allKeys[i] + "]").attr("data-region-include", fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyExclude") !== -1) {
                  $("[data-loc-exclude=" + allKeys[i] + "]").attr("data-region-exclude", fgContent[allKeys[i]]);
              } else if (allKeys[i].indexOf("keyPlayson") !== -1) {
                  $("[data-loc-playson=" + allKeys[i] + "]").attr("data-playson", fgContent[allKeys[i]].toLowerCase());
              }
          }
        }
        GUID_pop(fullGameArray, rotators);
        ieFix();
        $("body").css("visibility", "visible");
      }, 250);  

      if ($("[data-loc-copy='keyCopylinks3title']").text().indexOf("####") !== -1) {
          $("[data-loc-copy='keyCopylinks3title']").closest("div[data-grid='col-6']").remove();
          $('.pagelinks [data-grid="col-6 pad-12x"]').removeAttr("data-grid");
          $('.pagelinks [data-grid="col-6"]').attr("data-grid", "col-4").css("padding", "0 12px");
      }

      //fix for IE  hero
      // window resizing
      function ieFix() {
          var userAgentString = navigator.userAgent;
          if (userAgentString.indexOf("Trident") >= 0) { //only IE browsers
              $(".m-content-placement-item.f-size-large").each(function() {
                  $(this).find("img").attr("src", $(this).find("img").attr("srcset"))
              })
              var winWidth = $(document).width();
              if (winWidth < 767) {
                  $(".c-image").each(function() {
                      if ($(this).find("source").length === 3) {
                          $(this).find("img").attr("src", $(this).find("source").eq(2).attr("srcset"));
                      } else if ($(this).find("source").length === 2) {
                          $(this).find("img").attr("src", $(this).find("source").eq(1).attr("srcset"));
                      } else {
                          $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                      }
                  });
              } else if (winWidth >= 768 && winWidth < 1083) {
                  $(".c-image").each(function() {
                      if ($(this).find("source").length === 3) {
                          $(this).find("img").attr("src", $(this).find("source").eq(1).attr("srcset"));
                      } else {
                          $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                      }
                  });
              } else if (winWidth >= 1084) {
                  $(".c-image").each(function() {
                      $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                  });
              }

              var windowresized = (function() {
                  var timers = {};
                  return function(callback, ms, uniqueId) {
                      if (!uniqueId) {
                          uniqueId = "Fires only once.";
                      }
                      if (timers[uniqueId]) {
                          clearTimeout(timers[uniqueId]);
                      }
                      timers[uniqueId] = setTimeout(callback, ms);
                  };
              })();

              $(window).resize(function() {
                  windowresized(function() {
                      $(".m-content-placement-item.f-size-large").each(function() {
                          $(this).find("img").attr("src", $(this).find("img").attr("srcset"))
                      })
                      mobileZoom();
                      if (newWidth < 768) {
                          $(".c-image").each(function() {
                              if ($(this).find("source").length === 3) {
                                  $(this).find("img").attr("src", $(this).find("source").eq(2).attr("srcset"));
                              } else if ($(this).find("source").length === 2) {
                                  $(this).find("img").attr("src", $(this).find("source").eq(1).attr("srcset"));
                              } else {
                                  $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                              }
                          });
                      } else if (newWidth >= 768 && newWidth < 1083) {
                          $(".c-image").each(function() {
                              if ($(this).find("source").length === 3) {
                                  $(this).find("img").attr("src", $(this).find("source").eq(1).attr("srcset"));
                              } else {
                                  $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                              }
                          });
                      } else if (newWidth >= 1084) {
                          $(".c-image").each(function() {
                              $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                          });
                      }
                  }, 200, "pageresize");
              });
          } else {
            var windowresized = (function() {
                var timers = {};
                return function(callback, ms, uniqueId) {
                    if (!uniqueId) {
                        uniqueId = "Fires only once.";
                    }
                    if (timers[uniqueId]) {
                        clearTimeout(timers[uniqueId]);
                    }
                    timers[uniqueId] = setTimeout(callback, ms);
                };
            })();

            $(window).resize(function() {
                windowresized(function() {
                  mobileZoom();
                }, 200, "pageresize");
            });
          }
      }
  };

  var catGuidArray = ["HDRGaming", "IDXPAgaming.homepage", "TryForFree.homepage"];
  //var catClassArray = ["catFeatured", "catRecent", "catMs", "catId", "catAll"];
  var fullGameListId = "SpringSale2017All.games";
  var countcheckUrl = "http://reco-public.rec.mp.microsoft.com/channels/Reco/v8.0/lists/collection/CATEGORY?itemTypes=Game&DeviceFamily=Windows.Xbox&market=US&count=1";
  var listUrl = "http://reco-public.rec.mp.microsoft.com/channels/Reco/v8.0/lists/collection/CATEGORY?itemTypes=Game&DeviceFamily=Windows.Xbox&market=US&count=200&skipItems=0";

  function GUID_pop(rawGuids, rotators) {
      var countryCode = urlRegion.split("-")[1].toUpperCase();
      var guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'

      var first12 = rawGuids.slice(0, 12)
      rawGuids = rawGuids.slice(12)

      var firstToUrl = first12.join(",") + ",9N1NLJK9SKRN";
      guidUrl = guidUrl.replace("GAMEIDS", firstToUrl)
      $.get(guidUrl)
          .done(function(responseData) {
              var apiData = responseData;
              populate(apiData, 0, firstToUrl, rotators);
              guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
              restPop(rotators);
          })

      function restPop(rotators) {
          var m, n, temparray, chunk = 20;
          var arrayCount = 1
          for (m = 0, n = rawGuids.length; m < n; m += chunk) {
              (function(m, n) {
                  temparray = rawGuids.slice(m, m + chunk);
                  var guidsToUrl = temparray.join(",");
                  guidUrl = guidUrl.replace("GAMEIDS", guidsToUrl)

                  $.get(guidUrl)
                      .done(function(responseData) {
                          var apiData = responseData;
                          populate(apiData, arrayCount, guidsToUrl, rotators);
                          arrayCount++
                      })
                  guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
              })(m, n);
          }
      }

      var gamehtml = '';
      var popcounter = 0;
      // var bigidUrls = biUrls.items.urls;
      // var biuArray = Object.keys(bigidUrls);
      allGames = {};
      gameIdArrays["exclusives"] = [];
      gameIdArrays["newreleases"] = [];
      gameIdArrays["multiplayer"] = [];
      gameIdArrays["upcoming"] = [];
      gameIdArrays["kidsfamily"] = [];
      gameIdArrays["onsale"] = [];
      // gameIdArrays["enhanced"] = gameIdArrays["enhanced"].filter(function(v) { return fullGameArray.indexOf(v) !== -1});
      gameIdArrays["enhanced"] = [];
      gameIdArrays["360games"] = [];
      gameIdArrays["physical"] = [];
      gameIdArrays["riotgamesconsole"] = ["9N1NLJK9SKRN"];  

      selectedGames = [];
      prunedGames = [];
      shownGames = [];

      var nowdate = new Date();
      var nowmonthsdate = new Date();
      var monthsagofilterdate = new Date(nowmonthsdate.setMonth(nowmonthsdate.getMonth() - 2));
      var locgamesremoved = 0;

      function populate(data, count, bigidsgiven, rotators) {
          // var now = new Date();
          // var monthsago = new Date(now.setMonth(now.getMonth() - 9));
          var productQuantity = data.Products.length;

          bigidsgiven = bigidsgiven.split(",");
          var allprodids = [];
          for (var s = 0; s < productQuantity; s++) {
              allprodids.push(data.Products[s].ProductId);
          }
          var eliminated = [];
          eliminated = bigidsgiven.filter(function(v) { return allprodids.indexOf(v) === -1 });

          var giakeys = Object.keys(gameIdArrays);

          for (var w = 0; w < eliminated.length; w++) {
              locgamesremoved++
              var idind = fullGameArray.indexOf(eliminated[w]);
              if (idind !== -1) { fullGameArray.splice(idind, 1); }

              // remove from each gameidarray list
              for (var g = 0; g < giakeys.length; g++) {
                  var idgind = gameIdArrays[giakeys[g]].indexOf(eliminated[w]);
                  if (idgind !== -1) { gameIdArrays[giakeys[g]].splice(idgind, 1); }
              }

          }

          for (var t = 0; t < allprodids.length; t++) {
              var excludetest = false;
              // if (allprodids.indexOf(bigidsgiven[t]) !== -1) {
              var producttest = data.Products[t];
              var excludeit404 = 0;
              var excludeitpurch = 0;
              producttest.DisplaySkuAvailabilities.forEach(function(d) {
                  d.Availabilities.forEach(function(av) {
                      if (av.Actions.indexOf("Purchase") !== -1) {
                          excludeit404 += 1;
                          excludeitpurch += 1;
                      }
                      if (av.Actions.indexOf("Details") !== -1) {
                          excludeit404 += 1;
                      }
                  })
              })
              if (excludeit404 === 0 && excludeitpurch === 0) {
                  excludetest = true;
              }
              //}

              if (excludetest === true) {
                  console.log("NOTE: BigID " + allprodids[t] + " unavailable to buy in this locale. Removing from game lists.");
                  locgamesremoved++
                  popcounter--
                  var idind = fullGameArray.indexOf(allprodids[t]);
                  if (idind !== -1) { fullGameArray.splice(idind, 1); }

                  // remove from each gameidarray list
                  for (var g = 0; g < giakeys.length; g++) {
                      var idgind = gameIdArrays[giakeys[g]].indexOf(eliminated[w]);
                      if (idgind !== -1) { gameIdArrays[giakeys[g]].splice(idgind, 1); }
                  }
              }
          }

          for (var i = 0; i < productQuantity; i++) {
              var itemId = data.Products[i].ProductId.toUpperCase();
              var descriptionSizeLimit = 300;

              var itemTitle = data.Products[i].LocalizedProperties[0].ProductTitle;
              if (itemTitle === undefined) {
                  itemTitle = "";
              }
              var titleClickname = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, '');
              if (titleClickname === "") {
                  titleClickname = "-";
              }

              var shortdesc = data.Products[i].LocalizedProperties[0].ShortDescription;
              if (shortdesc === "") {
                  shortdesc = data.Products[i].LocalizedProperties[0].ProductDescription;
              }
              if (shortdesc === undefined || shortdesc === null) {
                  shortdesc = "";
              }

              if (shortdesc && (shortdesc.length > descriptionSizeLimit)) { // This should trim the description to prevent overflow
                  for (var j = descriptionSizeLimit; j > 0; j--) {
                      var curChar = shortdesc.charAt(j);
                      if (curChar == '.' || curChar == '?' || curChar == "!") {
                          shortdesc = shortdesc.substring(0, j + 1);
                          break;
                      }
                  }
              }

              var phys = "false";

              // get boxshot
              if (data.Products[i].LocalizedProperties[0].Images !== undefined) {
                  var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                  var imageInd = 1;
                  for (var j = 0; j < imagesNum; j++) {
                      if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                          imageInd = j;
                          break;
                      }
                  }
                  if (data.Products[i].LocalizedProperties[0].Images[imageInd]) {
                      var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri.replace("http:", "https:");
                      var itemBoxshotSmall;
                  } else {
                      var itemBoxshot = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                      var itemBoxshotSmall = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                  }
                  if (itemBoxshot.indexOf("store-images") !== -1) {
                      itemBoxshotSmall = itemBoxshot + "?w=140";
                      // itemBoxshot = itemBoxshot + "&h=300&w=200&format=jpg";
                      itemBoxshot = itemBoxshot + "?w=272";
                  } else {
                      itemBoxshotSmall = itemBoxshot;
                  }
              } else {
                  var itemBoxshot = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                  var itemBoxshotSmall = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
              }

              // get screenshot
              if (data.Products[i].LocalizedProperties[0].Images !== undefined) {
                  var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                  var imageInd = 1;
                  for (var j = 0; j < imagesNum; j++) {
                      var im = data.Products[i].LocalizedProperties[0].Images[j];
                      if ((im.ImagePurpose === "ImageGallery" || im.ImagePurpose === "Screenshot") && (im.Height < im.Width)) {
                          imageInd = j;
                          break;
                      }
                  }
                  if (data.Products[i].LocalizedProperties[0].Images[imageInd]) {
                      var itemScreenshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri.replace("http:", "https:");
                  } else {
                      var itemScreenshot = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                  }
                  if (itemScreenshot.indexOf("xboxlive.com") !== -1) {
                      itemScreenshot = itemScreenshot + "&w=480&format=jpg";
                  }
              } else {
                  if (data.Products[i].LocalizedProperties[0].Images !== undefined && data.Products[i].LocalizedProperties[0].Images[0]) {
                      var itemScreenshot = data.Products[i].LocalizedProperties[0].Images[0].Uri.replace("http:", "https:") + "&w=231&h=197&q=90&m=6&b=%23FFFFFFFF&o=f";
                  } else {
                      var itemScreenshot = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                  }
              }

              // get screenshot array
              var ssarray = [];
              var superheroart = "";
              if (phys === "false" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                  var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                  var sslimit = 5;
                  var imageInd = 1;
                  for (var j = 0; j < imagesNum; j++) {
                      var im = data.Products[i].LocalizedProperties[0].Images[j];
                      if ((im.ImagePurpose.toLowerCase() === "imagegallery" || im.ImagePurpose.toLowerCase() === "screenshot") && (im.Height < im.Width)) {
                          if (im.Uri.indexOf("xboxlive.com") !== -1) {
                              var ssimg = im.Uri.replace("http:", "https:") + "&w=980&format=jpg";
                          } else {
                              var ssimg = im.Uri.replace("http:", "https:");
                          }
                          if (ssarray.length < sslimit) {
                              if (ssarray.indexOf(ssimg) === -1 && omitimages.indexOf(ssimg) === -1) {
                                  ssarray.push(ssimg);
                              }
                          } else {
                              break;
                          }
                      } else if (im.ImagePurpose.toLowerCase() === "superheroart") {
                          if (im.Uri.indexOf("xboxlive.com") !== -1) {
                              var shimg = im.Uri.replace("http:", "https:") + "&w=980&format=jpg";
                          } else {
                              var shimg = im.Uri.replace("http:", "https:");
                          }
                          //console.log("keyart = " + kaimg);
                          superheroart = shimg;
                      }
                  }
              }


              var releaseDate = data.Products[i].MarketProperties[0].OriginalReleaseDate;
              if (releaseDate === undefined) {
                  releaseDate = 0;
              }
              var modDate = data.Products[i].DisplaySkuAvailabilities[0].Availabilities[0].LastModifiedDate;
              if (modDate === undefined) {
                  modDate = 0;
              }
              var msproduct = data.Products[i].IsMicrosoftProduct;
              var multiplayer = "false";
              var coop = "false";
              var mptest = data.Products[i].Properties;
              if (mptest.Attributes) {
                  for (var n = 0; n < mptest.Attributes.length; n++) {
                      if (mptest.Attributes[n].Name.toLowerCase().indexOf("multiplayer") !== -1) {
                          multiplayer = "true";
                      }
                      if (mptest.Attributes[n].Name.toLowerCase().indexOf("coop") !== -1) {
                          coop = "true";
                      }
                  }
              }

              //get prices
              var listprice;
              var msrpprice;
              var currencycode;
              var onsale = "false";
              var gwg = "false";
              var golddiscount = "false"; // deals with gold ... and gold member sale prices?
              var goldandsilversale = "false";
              var goldandsilversalegoldprice = 100000000;
              var specialprice = 100000000;
              var eaaccessgame = "false";
              var gamepassgame = "false";
              var purchasable = "false";
              var tempea = "false"
              var tempgs = "false";
              var goldaffids = [];
              var silversaleperc = "0%";
              var goldandsilversalegoldperc = "0%";
              var platxbox = "false";
              var platpc = "false";
              var platcloud = "false";
              var platxo = "false";
              var platxsx = "false";
              var licensekeys = [];

              if (phys === "false") {
                  if (data.Products[i].LocalizedProperties[0].EligibilityProperties !== null && data.Products[i].LocalizedProperties[0].EligibilityProperties !== undefined &&
                      data.Products[i].LocalizedProperties[0].EligibilityProperties !== "undefined") {
                      if (data.Products[i].LocalizedProperties[0].EligibilityProperties.Affirmations.length > 0) {
                          data.Products[i].LocalizedProperties[0].EligibilityProperties.Affirmations.forEach(function(aff) {
                              if (aff.Description.toLowerCase().indexOf("ea access") !== -1) {
                                  tempea = "true";
                              }
                              if (aff.Description.toLowerCase().indexOf("game pass") !== -1) {
                                  gamepassgame = "true";
                              }
                              if (aff.Description.toLowerCase().indexOf("gold") !== -1) {
                                  tempgs = "true";
                                  goldaffids.push(aff.AffirmationProductId);
                              }
                          })
                      }
                  }
                  data.Products[i].DisplaySkuAvailabilities.forEach(function(sku) {
                      var purchnum = 0;
                      sku.Availabilities.forEach(function(av, ind) {
                          if (av.Actions.indexOf("Purchase") !== -1) {
                              purchasable = "true";
                              purchnum++;
                              if (purchnum > 1 && tempgs === "true" && av.RemediationRequired === true && goldaffids.indexOf(av.Remediations[0].BigId) !== -1) {
                                  goldandsilversale = "true";
                              }
                              // get platform info
                              av.Conditions.ClientConditions.AllowedPlatforms.forEach(function(plat) {
                                  if (plat.PlatformName === "Windows.Xbox") {
                                      platxbox = "true";
                                  }
                                  if (plat.PlatformName === "Windows.Desktop") {
                                      platpc = "true";
                                  }
                              })
                          }
                          if (av.Actions.indexOf("Purchase") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) &&
                              sku.Sku.Properties.IsTrial === false) {
                              if ((av.OrderManagementData.Price.ListPrice !== av.OrderManagementData.Price.MSRP || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && ind !== 0) {
                                  specialprice = av.OrderManagementData.Price.ListPrice;
                              } else {
                                  listprice = av.OrderManagementData.Price.ListPrice;
                              }
                              if (ind === 0) {
                                  msrpprice = av.OrderManagementData.Price.MSRP;
                              }
                              currencycode = av.OrderManagementData.Price.CurrencyCode;
                              if (av.Properties.MerchandisingTags !== undefined) {
                                  if (av.Properties.MerchandisingTags.indexOf("LegacyGamesWithGold") !== -1) {
                                      gwg = "true";
                                      specialprice = listprice;
                                      listprice = msrpprice;
                                  }
                                  if (av.Properties.MerchandisingTags.indexOf("LegacyDiscountGold") !== -1) {
                                      golddiscount = "true";

                                  }
                              }
                              if (goldandsilversale === "true" && av.DisplayRank === 1) {
                                  goldandsilversalegoldprice = av.OrderManagementData.Price.ListPrice;
                                  var golddiff = msrpprice - goldandsilversalegoldprice;
                                  goldandsilversalegoldperc = Math.round(golddiff / msrpprice * 100).toString() + "%";
                              }
                              if (tempea === "true" && av.Actions.length === 2) {
                                  eaaccessgame = "true";
                              }
                              if (listprice < msrpprice) {
                                  onsale = "true";
                                  var listdiff = msrpprice - listprice;
                                  silversaleperc = Math.round(listdiff / msrpprice * 100).toString() + "%";
                                  if (gameIdArrays["onsale"].indexOf(itemId) === -1) {
                                      gameIdArrays["onsale"].push(itemId);
                                  }
                              }
                          }
                          // replace pc copies of console games, part 1 get connected copies
                          // if (av.Actions.indexOf("License") !== -1 && av.LicensingData) {
                          //   av.LicensingData.SatisfyingEntitlementKeys.forEach(function(se) {
                          //     se.EntitlementKeys.forEach(function(kk) {
                          //       var enkey = kk.split(":")[1];
                          //       if (enkey.length === 12 && licensekeys.indexOf(enkey) === -1) {
                          //         licensekeys.push(enkey)
                          //       }
                          //     })
                          //   })
                          // }
                      })
                  })

                  if (platxbox === "true") {
                      if (data.Products[i].Properties.XboxConsoleGenCompatible === null) {
                          platxo = "true";
                          platxsx = "true";
                      } else if (data.Products[i].Properties.XboxConsoleGenCompatible === undefined) {
                          platxo = "true";
                      } else if (data.Products[i].Properties.XboxConsoleGenCompatible.length === 2) {
                          platxo = "true";
                          platxsx = "true";
                      } else if (data.Products[i].Properties.XboxConsoleGenCompatible[0] === "ConsoleGen8" && data.Products[i].Properties.XboxConsoleGenCompatible.length === 1) {
                          platxo = "true";
                          platxsx = "false";
                      } else if (data.Products[i].Properties.XboxConsoleGenCompatible[0] === "ConsoleGen9" && data.Products[i].Properties.XboxConsoleGenCompatible.length === 1) {
                          platxsx = "true";
                          platxo = "false";
                      }
                  }

              } else {
                  data.Products[i].DisplaySkuAvailabilities.forEach(function(sku) {
                      sku.Availabilities.forEach(function(av) {
                          if (av.Actions.indexOf("Purchase") !== -1 && av.Actions.indexOf("Browse") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && av.Actions.length > 2) {
                              listprice = av.OrderManagementData.Price.ListPrice;
                              msrpprice = av.OrderManagementData.Price.MSRP;
                              currencycode = av.OrderManagementData.Price.CurrencyCode;
                              if (listprice < msrpprice) {
                                  onsale = "true";
                                  if (gameIdArrays["onsale"].indexOf(itemId) === -1) {
                                      gameIdArrays["onsale"].push(itemId);
                                  }
                              };
                          }
                      })
                  })
              }

              if (platpc === "false" && platxbox === "false" && (gameIdArrays["609d944c-d395-4c0a-9ea4-e9f39b52c1ad"] && gameIdArrays["609d944c-d395-4c0a-9ea4-e9f39b52c1ad"].indexOf(itemId) !== -1 ||
                      gameIdArrays["4165f752-d702-49c8-886b-fb57936f6bae"] && gameIdArrays["4165f752-d702-49c8-886b-fb57936f6bae"].indexOf(itemId) !== -1)) {
                  platpc = "true";
              } else if (platpc === "false" && platxbox === "false") {
                  platxbox = "true";
              }
              if (platpc === "true" && platxbox === "false") {
                  platxsx = "false";
              }
              if (gameIdArrays["eaplayPC"] && gameIdArrays["eaplayPC"].indexOf(itemId) !== -1) {
                  platxbox = "false";
                  platxsx = "false";
                  platpc = "true"
              }

              if (listprice === undefined) {
                  console.log("NOTE: BigID " + itemId + " has no price information.");
                  listprice = 100000000;
                  msrpprice = 100000000;
                  currencycode = "USD";
              }

              var rating = "none";
              var ratingUrl = "https://www.esrb.org/";
              var ratingcode = "";
              var ratingage = 99;
              var ratingsystem = "none";
              var kidfamilyratings = ["ESRB:T", "ESRB:E10", "ESRB:E", "ESRB:EC", "ESRB:RPEveryone", "ESRB:RPTeen", "PEGI:3", "PEGI:7", "PEGI:12", "COB-AU:G", "COB-AU:PG", "COB-AU:CTC", "OFLC-NZ:G",
                  "OFLC-NZ:PG", "OFLC-NZ:R13", "OFLC-NZ:R13", "USK:Everyone", "USK:6", "USK:12", "IARC:3", "IARC:7", "IARC:12", "CERO:A", "CERO:B", "USK:6", "USK:Everyone", "USK:6",
                  "PCBP:0", "PCBP:6", "PCBP:12", "DJCTQ:L", "DJCTQ:10", "DJCTQ:12", "DJCTQ:14", "CSRR:G", "CSRR:PG12", "CSRR:PG15"
              ]
              var rawdescriptors = "none";
              var rawinteractive = "none";
              var rawdisclaimers = "none";
              var pegiFallbackRegions = "en-za ,";
              var iarcFallbackRegions = "ja-jp ,";
              var cr = 99;
              var cresrb = 99;
              var crfallback = 0;
              var crfallback_PEGI = -1;
              var crfallback_IARC = -1;
              if (data.Products[i].MarketProperties[0].ContentRatings !== undefined && data.Products[i].MarketProperties[0].ContentRatings !== null && data.Products[i].MarketProperties[0].ContentRatings.length > 0) {
                  for (var c = 0; c < data.Products[i].MarketProperties[0].ContentRatings.length; c++) {
                      // if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "ESRB") {
                      //     cresrb = c;
                      // }
                      if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "Microsoft") { // Microsoft rating is fallback
                        crfallback = c;
                      }
                      if ((pegiFallbackRegions.includes(urlRegion)) && data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "PEGI") { // PEGI fallback for en-za
                          crfallback_PEGI = c;
                        }
                        if ((iarcFallbackRegions.includes(urlRegion)) && data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "IARC") { // PEGI fallback for en-za
                          crfallback_IARC = c;
                        }
                      if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === ratingorg) {
                          cr = c;
                      }
                  }
                  if (cr === 99) { cr = cresrb } // if region's rating system is not found, use esrb
                  if (cr === 99) { cr = crfallback } // fallback if no esrb either

                  if ((pegiFallbackRegions.includes(urlRegion)) && crfallback_PEGI !== -1 && cr === crfallback) { cr = crfallback_PEGI } // fallback if pegi needed
                  if ((iarcFallbackRegions.includes(urlRegion)) && crfallback_IARC !== -1 && cr === crfallback) { cr = crfallback_IARC } // fallback if iarc needed
                  ratingsystem = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingSystem;
                  ratingcode = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingId;
                  var ratimage = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].LocalizedProperties[0].LogoUrl;
                  ratingage = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].Age;
                  // if (urlRegion === "ko-kr" && ratingage === 18) { // fixing  ko-kr 18 age issue
                  //   ratingage = 19;
                  // }
                  rating = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].LocalizedProperties[0].LongName;
                  ratingUrl = ratingData.RatingBoards[ratingsystem].LocalizedProperties[0].Url;
                  
                  if (kidfamilyratings.indexOf(rating) !== -1) {
                      gameIdArrays["kidsfamily"].push(itemId);
                  }
                  rawdescriptors = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingDescriptors.join(",");
                  rawinteractive = data.Products[i].MarketProperties[0].ContentRatings[cr].InteractiveElements.join(",");
                  rawdisclaimers = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingDisclaimers.join(",");                    
              }
              if (urlRegion === "ja-jp" || urlRegion === "ko-kr") {
                  $(".c-label[data-game='kids and family']").remove()
              }

              // if (biuArray.indexOf(itemId) === -1 || bigidUrls[itemId].toLowerCase().indexOf(urlRegion) !== -1) {
                  var itemhref = 'https://www.xbox.com/' + urlRegion + '/games/store/' + titleClickname + '/' + itemId;
                  if (itemId === "9N0H62KZ3BXV") {
                    itemhref = "https://dlassets-ssl.xboxlive.com/public/content/XboxInstaller/XboxInstaller.exe"
                  }
              // } else {
              //     var itemhref = bigidUrls[itemId].split("<exc>")[0];
              //     var splitHref = itemhref.split("/");
              //     splitHref.splice(3, 0, urlRegion);
              //     itemhref = splitHref.join("/");
              // }

              var avgstars = 0;
              var ratingcount = 0;
              if (data.Products[i].MarketProperties[0].UsageData) {
                  //avgstars = data.Products[i].MarketProperties[0].UsageData[0].AverageRating;
                  //ratingcount = data.Products[i].MarketProperties[0].UsageData[0].RatingCount;
              }


              if (itemId === "9NCLP4LV5K7Z") {
                  itemBoxshot = "https://store-images.s-microsoft.com/image/apps.28362.67453348098260763.a9f96429-c651-425e-97d2-e8861561f15f.f7b26f7f-73d8-4f53-9f3b-4d9e4e4d23f0";
                  itemBoxshotSmall = "https://store-images.s-microsoft.com/image/apps.28362.67453348098260763.a9f96429-c651-425e-97d2-e8861561f15f.f7b26f7f-73d8-4f53-9f3b-4d9e4e4d23f0";
              }
              // if (itemId === "BZFK7WNK7R4M") {
              //   itemBoxshot = "https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTc6LYEXhNheFwp2halN6MiJq0hK8tHwcOslhHzFcqc.uw90wjv2YtwC_mZJs.lEh1cto.K33xsXgRNctiGCKrDjVsG9PhS5GzkLXFMF5wlXsJAfaI6.Hc6zR2KrB00Sjgkn0kvJZv.PD1.7g.ytDgP368SN3vocTlHhhyS_BQ8qZs-&w=200&format=jpg";
              //   itemBoxshotSmall = "https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTc6LYEXhNheFwp2halN6MiJq0hK8tHwcOslhHzFcqc.uw90wjv2YtwC_mZJs.lEh1cto.K33xsXgRNctiGCKrDjVsG9PhS5GzkLXFMF5wlXsJAfaI6.Hc6zR2KrB00Sjgkn0kvJZv.PD1.7g.ytDgP368SN3vocTlHhhyS_BQ8qZs-&w=200&format=jpg";
              // }    

              // genres
              var gamegenresall = [];
                  if (data.Products[i].Properties.Categories !== undefined && data.Products[i].Properties.Categories !== null) {
                      var gamegenres = data.Products[i].Properties.Categories[0];
                      gamegenresall = data.Products[i].Properties.Categories;
                  } else if (data.Products[i].Properties.Category !== undefined && data.Products[i].Properties.Category !== null) {
                      var gamegenres = data.Products[i].Properties.Category;
                      gamegenresall.push(gamegenres)
                  } else {
                      var gamegenres = "";
                      gamegenresall = [""];
                  }

              var recentxgp = "false";
              if (gameIdArrays["subsxgprecentlyadded"].indexOf(itemId) !== -1 || gameIdArrays["XGPPMPRecentlyAdded"].indexOf(itemId) !== -1) {
                  recentxgp = "true";
              }
              var leavingsoon = "false";
              if (gameIdArrays["consoleleavingsoon"].indexOf(itemId) !== -1) {
                  leavingsoon = "true";
              }

              allGames[itemId] = {
                  releasedate: releaseDate,
                  msproduct: msproduct,
                  multiplayer: multiplayer,
                  coop: coop,
                  rating: rating,
                  ratingUrl: ratingUrl,
                  ratingage: ratingage,
                  ratingsystem: ratingsystem,
                  gameurl: itemhref,
                  titleclickname: titleClickname,
                  ratimage: ratimage,
                  boxshot: itemBoxshot,
                  boxshotsmall: itemBoxshotSmall,
                  title: itemTitle,
                  msrpprice: msrpprice,
                  listprice: listprice,
                  currencycode: currencycode,
                  onsale: onsale,
                  upcoming: "false",
                  newrelease: "false",
                  physical: phys,
                  genres: gamegenres,
                  genresAll: gamegenresall,
                  screenshot: itemScreenshot,
                  descriptors: rawdescriptors,
                  interactive: rawinteractive,
                  disclaimers: rawdisclaimers,
                  stars: avgstars,
                  starcount: ratingcount,
                  screenarray: ssarray,
                  superheroart: superheroart,
                  description: shortdesc,
                  gameswithgold: gwg,
                  golddiscount: golddiscount,
                  goldandsilversale: goldandsilversale,
                  goldandsilversalegoldprice: goldandsilversalegoldprice,
                  specialprice: specialprice,
                  eaaccessgame: eaaccessgame,
                  gamepassgame: gamepassgame,
                  purchasable: purchasable,
                  silversaleperc: silversaleperc,
                  goldandsilversalegoldperc: goldandsilversalegoldperc,
                  x360game: "false",
                  includes: "",
                  excludes: "",
                  playson: "false",
                  moddate: modDate,
                  recentxgp: recentxgp,
                  platformxbox: platxbox,
                  platformpc: platpc,
                  licensekeys: licensekeys,
                  leavingsoon: leavingsoon,
                  eaplaypcgame: "false",
                  platformxo: platxo,
                  platformxsx: platxsx
              };

              // add ampt list info
              for (var g = 0; g < giakeys.length; g++) {
                  if (giakeys[g] !== "multiplayer") {
                      allGames[itemId][giakeys[g]] = "false";
                      if (gameIdArrays[giakeys[g]] && gameIdArrays[giakeys[g]].indexOf(itemId) !== -1) {
                          allGames[itemId][giakeys[g]] = "true";
                      }
                  }
              }

              //make API-provided lists        
              if (msproduct === true) {
                  gameIdArrays["exclusives"].push(itemId);
              }
              if (multiplayer === "true") {
                  gameIdArrays["multiplayer"].push(itemId);
              }
              var reldate = new Date(releaseDate);
              if (reldate > nowdate) {
                  gameIdArrays["upcoming"].push(itemId);
                  allGames[itemId]["upcoming"] = "true";
              }
              if (reldate < nowdate && monthsagofilterdate < reldate) {
                  gameIdArrays["newreleases"].push(itemId);
                  allGames[itemId]["newrelease"] = "true";
              }
              if (gameIdArrays["eaplayPC"] && gameIdArrays["eaplayPC"].indexOf(itemId) > -1) {
                  allGames[itemId]["eaplaypcgame"] = "true";
              }


              popcounter++;

              //console.log("itemId:" + itemId + "  " + i + ":" + (productQuantity -1) + "   " + popcounter + ":" + (fullGameArray.length) + "  locagamesremoved:" + locgamesremoved + "   " + count + ":" + chunktotal)

              if ((i === (productQuantity - 1)) && count === chunktotal - 1) {
                  var activecheck = setInterval(function() {
                      var activeAjax = $.active;
                      if (activeAjax === 0) {
                        if (rotators === true) {
                          if (showRotators === true) {
                            popCarousels();  
                          }                         
                          runAll()
                          clearInterval(activecheck);
                        } else {
                          ajaxdone(rotators);
                          clearInterval(activecheck); 
                        }
                      }
                  }, 500);

                  function ajaxdone(rotators) {      
                      // Removed 3/29                 
                      // var x1RegionPop = (function() {
                      //     $(".gameDiv a").each(function() {
                      //         var rawHref = $(this).attr("href")
                      //         var splitHref = rawHref.split("/")
                      //         splitHref.splice(3, 0, urlRegion)
                      //         var newHref = splitHref.join("/")
                      //         $(this).attr("href", newHref)
                      //     })
                      // })();

                      var durl = document.URL.toLowerCase();
                      var beginfeat = "avail-download";
                      if (durl.indexOf("multiplayer") !== -1) {
                          beginfeat = 'avail-download,feature-multiplayer';
                      }
                      if (durl.indexOf("co-op") !== -1) {
                          beginfeat = 'avail-download,feature-coop';
                      }
                      if (durl.indexOf("4k") !== -1) {
                          beginfeat = 'avail-download,feature-4k';
                      }
                      if (durl.indexOf("hdr") !== -1) {
                          beginfeat = 'avail-download,feature-hdr'; //consolecomingsoon
                      }

                      collectioninfo = {
                          "allpopular": { plat: "xbox", ampt: "popularconsole", filt: "" },
                          "allrecent": { plat: "xbox", ampt: "subsxgprecentlyadded", filt: "" },
                          "allaction": { plat: "xbox", ampt: "allconsole", filt: "genre-action & adventure" },
                          "allshooters": { plat: "xbox", ampt: "allconsole", filt: "genre-shooter" },
                          "allfamily": { plat: "xbox", ampt: "allconsole", filt: "genre-family" },
                          "allleaving": { plat: "xbox", ampt: "consoleleavingsoon", filt: "" },
                          "consolerecent": { plat: "xbox", ampt: "subsxgprecentlyadded", filt: "" },
                          "consoleid": { plat: "xbox", ampt: "subsxgpchannel9", filt: "" },
                          "consoleshooters": { plat: "xbox", ampt: "allconsole", filt: "genre-shooter" },
                          "pcshooters": { plat: "pc", ampt: "allpc", filt: "genre-shooter" },
                          "consolefamily": { plat: "xbox", ampt: "allconsole", filt: "genre-family" },
                          "consolepopular": { plat: "xbox", ampt: "popularconsole", filt: "" },
                          "consolecomingsoon": { plat: "xbox", ampt: "consolecomingsoon", filt: "" },
                          "consoleleavingsoon": { plat: "xbox", ampt: "consoleleavingsoon", filt: "" },
                          "pcpopular": { plat: "pc", ampt: "pcgaVTpopular", filt: "" },
                          "pcrecent": { plat: "pc", ampt: "pcrecent", filt: "" },
                          "comingsoonpc": { plat: "pc", ampt: "pccomingsoon", filt: "" },
                          "pcleavingsoon": { plat: "pc", ampt: "pcleavingsoon", filt: "" },
                          "consolegames": { plat: "xbox", ampt: "allconsole", filt: "" },
                          "all-games": { plat: "xbox", ampt: "allconsole", filt: "" },
                          "pcgames": { plat: "pc", ampt: "allpc", filt: "" },
                          "xboxtouchcontrols": { plat: "xbox", ampt: "allconsole", filt: "inputs-touch" },
                          "eaplay": { plat: "xbox", ampt: "eaplayConsole", filt: "" },
                          "consoleea": { plat: "xbox", ampt: "eaplayConsole", filt: "" },
                          "pcea": { plat: "pc", ampt: "eaplayPC", filt: "" },
                          "pcid": { plat: "pc", ampt: "idxboxpc", filt: "" },
                          "cloud": { plat: "xbox", ampt: "allconsole", filt: "playon-cloud" },
                          "pcdayone": { plat: "pc", ampt: "pdoPC", filt: "" },
                          "consoledayone": { plat: "xbox", ampt: "pdoConsole", filt: "" },
                          "optimized": { plat: "xbox", ampt: "optXS", filt: "" },
                          "consolecomingsoon": { plat: "xbox", ampt: "consolecomingsoon", filt: "" },
                          "comingsoonconsole": { plat: "xbox", ampt: "consolecomingsoon", filt: "" },
                          "bethesdaconsole": { plat: "xbox", ampt: "bethxbox", filt: "" },
                          "bethesdapc": { plat: "pc", ampt: "bethpc", filt: "" },
                          "eagametrialsconsole": { plat: "xbox", ampt: "eagametrialsconsole", filt: "" },
                          "eagametrialspc": { plat: "pc", ampt: "eagametrialspc", filt: "" },
                          "ubisoftconsole": { plat: "xbox", ampt: "ubisoftconsole", filt: "" },
                          "ubisoftpc": { plat: "pc", ampt: "ubisoftpc", filt: "" },
                          "riotgamespc": { plat: "pc", ampt: "riotgamespc", filt: "" },
                          "allcore": { plat: "xbox", ampt: "coreall", filt: "" },
             "riotgamesconsole": { plat: "console", ampt: "riotgamesconsole", filt: "" },

                      };

                      // add new collections
                      for (var p = 0; p < newListIds.length; p++) {
                          if (globalAdd[newListIds[p]].startstring.length > 0) {
                              collectioninfo[globalAdd[newListIds[p]].startstring] = {};
                              collectioninfo[globalAdd[newListIds[p]].startstring].plat = globalAdd[newListIds[p]].plat;
                              collectioninfo[globalAdd[newListIds[p]].startstring].ampt = globalAdd[newListIds[p]].colname;
                              collectioninfo[globalAdd[newListIds[p]].startstring].filt = "";
                          }
                      }

                      // modify lists
                      if (gameIdArrays.eaplayPC) {
                        gameIdArrays.eaplayAll = gameIdArrays.eaplayAll.concat(gameIdArrays.eaplayPC);
                      }

                      let filterFound = false;
                      var ciarray = Object.keys(collectioninfo);

                      for (var c = 0; c < ciarray.length; c++) {
                          if (durl.indexOf(ciarray[c]) !== -1) {
                              $("[data-theplat=" + collectioninfo[ciarray[c]].plat + "]").click();
                              if (collectioninfo[ciarray[c]].filt !== "") {
                                $("[data-filt='" + collectioninfo[ciarray[c]].filt + "']").closest(".c-drawer.f-checkbox").find("button")[0].click();
                                $("[data-filt='" + collectioninfo[ciarray[c]].filt + "']")[0].click();
                              } else {
                                $(".selectSet:not(.hidden) input[value='" + collectioninfo[ciarray[c]].ampt + "']")[0].click();
                              }
                              filterFound = true;
                              setTimeout(function() {
                                var btttop = $(".thecatalog").offset().top - 80;
                                $("HTML, BODY").animate({
                                    scrollTop: btttop
                                }, 400);
                                $(".thecatalog .gameDiv a").eq(0).focus();
                                console.log("anchoring")
                              }, 200) 
                              break;
                          }
                          if (c === ciarray.length - 1 && rotators === false) {
                              beginningState("xbox","ultimate");

                              // listGames("SubsXGPAllGames", beginfeat, "release", "xbox");
                              // filtersort();
                              // $(".coloption").removeClass("col-selected");
                              // $(".coloption[data-col='" + collection + "']").addClass("col-selected");
                              // $(".coloption").first().addClass("col-selected");

                              // var colTitleMemb = $(".colmembership.col-selected span").text();
                              // var colTitle = colTitleMemb + " > " + $(".colgroup .col-selected span").text();

                              if (urlRegion === "fr-fr") {
                                if ($(".catalogTitle #disclosureContainer").length > 0) {
                                  $(".catalogTitle #disclosureContainer").detach().appendTo("#disclosureStore");
                                }
                              }
                              // $(".catalogTitle").text(colTitle);
                              if (urlRegion === "fr-fr") {
                                // if (colTitle === "Les plus populaires") {
                                  $("#disclosureStore #disclosureContainer").detach().appendTo(".catalogTitle");
                                // }
                              }
                          }
                      }

                      $(document).on("click", ".carShopAll, .expLink", function(e) {
                        e.preventDefault();
                        const amptVals = {"consolerecent": "subsxgprecentlyadded", "consolepopular": "popularconsole", 
                                          "consoleleavingsoon": "consoleleavingsoon", "spaceconquestsconsole": "spaceconquestsconsole", "hispanicheritageconsole": "hispanicheritageconsole", 
                                          "pcrecent": "pcrecent", "pcpopular": "pcgaVTpopular", 
                                          "pcleavingsoon": "pcleavingsoon", "spaceconquestspc": "spaceconquestspc", "hispanicheritagepc": "hispanicheritagepc"}
                        let ampt = $(this).attr("href").split("#")[1];
                        let plat = "xbox";
                        if ($(this).closest(".gamesCarousel").hasClass("gcPc")) {
                          plat = "pc";
                        }
                        if ($(".selectSet:not(.hidden) input[value='" + ampt + "']").length === 0) {
                          ampt = amptVals[ampt]
                        }
                        $("[data-theplat=" + plat + "]").click();
                        resetFilters(true, false, plat);
                        $(".selectSet:not(.hidden) input[value='" + ampt + "']")[0].click();
                        catScroll() 
                      })

                      $(document).on("click", ".internalLink, .cta_internal", function(e) {
                        e.preventDefault();
                        const amptVals = {"all-games": "allconsole", "allcore": "allGamesXboxCore",
                                          "consolegames": "allconsole", "pcgames": "allpc"}
                        let ampt = ""
                        if ($(this).hasClass("internalLink")) {
                          ampt = $(this).attr("href").split("#")[1] 
                        } else {
                          ampt = $(this).attr("data-cta-href").split("#")[1] ;
                        }
                        let inputClick = 0;
                        if (ampt === "consolegames") {
                          inputClick = 1;
                        } 
                        let plat = "xbox";
                        if (ampt.indexOf("pc") !== -1) {
                          plat = "pc";
                        }
                        if ($(".selectSet:not(.hidden) input[value='" + ampt + "']").length === 0) {
                          ampt = amptVals[ampt]
                        }
                        $("[data-theplat=" + plat + "]").click();
                        resetFilters(true, false, plat);
                        $(".selectSet:not(.hidden) input[value='" + ampt + "']")[inputClick].click();
                        catScroll() 
                      })

                      function catScroll() {
                        var acctop = $(".thecatalog").offset().top - 80;
                        setTimeout(function() {
                          $(".thecatalog .gameDiv a").eq(0).focus();
                        }, 400)
                        $("HTML, BODY").animate({
                          scrollTop: acctop
                        }, 300);
                      }

                      // Setting Deep Links individual for Core
                      if (durl.indexOf("coreall") !== -1) {
                          $("input[value='allGamesXboxCore']").click()
                      } else if (durl.indexOf("corepopular") !== -1) {
                          $("input[value='allGamesXboxCore']").click()
                          $("input[value='popularGamesXboxCore']").click();
                      }

                      function beginningState(platform) {  
                          if (urlRegion === "fr-fr") {
                            if ($(".catalogTitle #disclosureContainer").length > 0) {
                              $(".catalogTitle #disclosureContainer").detach().appendTo("#disclosureStore");
                            }
                          }
                          if (urlRegion === "fr-fr") {
                            // if (colTitle === "Les plus populaires") {
                              $("#disclosureStore #disclosureContainer").detach().appendTo(".catalogTitle");
                            // }
                          }

                          var filterAnchors = {
                              "consoleaction": { plat: "xbox", filterId: "genre-action & adventure" },
                              "pcaction": { plat: "pc", filterId: "genre-action & adventure" },
                              "classicsconsole": { plat: "xbox", filterId: "genre-classics" },
                              "classicspc": { plat: "pc", filterId: "genre-classics" },
                              "consoleindie": { plat: "xbox", filterId: "genre-indie" },
                              "pcindie": { plat: "pc", filterId: "genre-indie" },
                              "consoleplatformers": { plat: "xbox", filterId: "genre-platformers" },
                              "pcplatformers": { plat: "pc", filterId: "genre-platformers" },
                              "consolepuzzle": { plat: "xbox", filterId: "genre-puzzle" },
                              "pcpuzzle": { plat: "pc", filterId: "genre-puzzle" },
                              "consoleracing": { plat: "xbox", filterId: "genre-racing" },
                              "pcracing": { plat: "pc", filterId: "genre-racing" },
                              "consoleshooters": { plat: "xbox", filterId: "genre-shooter" },
                              "pcshooters": { plat: "pc", filterId: "genre-shooter" },
                              "pcrpg": { plat: "pc", filterId: "genre-role-playing" },
                              "consolerpg": { plat: "xbox", filterId: "genre-role-playing" },
                              "consolesports": { plat: "xbox", filterId: "genre-sports" },
                              "pcsports": { plat: "pc", filterId: "genre-sports" },
                              "consolestrategy": { plat: "xbox", filterId: "genre-strategy" },
                              "pcstrategy": { plat: "pc", filterId: "genre-strategy" },
                              "cloud": { plat: "xbox", filterId: "playon-cloud" },
                              "pcfamily": { plat: "pc", filterId: "genre-family" },
                              "consolefamily": { plat: "xbox", filterId: "genre-family" },
                              "consolesim": { plat: "xbox", filterId: "genre-simulation" },
                              "pcsim": { plat: "pc", filterId: "genre-simulation" }
                          }
                          var filterAnchorKeys = Object.keys(filterAnchors);

                          setTimeout(function() {
                              for (var a = 0; a < filterAnchorKeys.length; a++) {
                                  if (durl.indexOf(filterAnchorKeys[a]) !== -1) {
                                    runStartingFilter(filterAnchors[filterAnchorKeys[a]].plat, filterAnchors[filterAnchorKeys[a]].filterId)
                                    filterFound = true;
                                    break;
                                  }
                              }
                              if (filterFound === false) {
                                $("[data-theplat='xbox']")[0].click();
                              }

                              function runStartingFilter(platform, id) {
                                  $("[data-theplat='" + platform + "']")[0].click();
                                  $("[data-filt='" + id + "']").closest(".c-drawer.f-checkbox").find("button")[0].click();
                                  $("[data-filt='" + id + "']")[0].click();
                              }
                          }, 500)

                          setTimeout(function() {
                            if (document.URL.indexOf("#") !== -1) {
                              var btttop = $(".thecatalog").offset().top - 80;
                              $("HTML, BODY").animate({
                                  scrollTop: btttop
                              }, 400);
                              $(".thecatalog .gameDiv a").eq(0).focus();
                            }
                          }, 2000)  

                          // targeted content 2
                          if (typeof(xb_tgt) !== 'undefined') {
                            // horizontal channel handling
                            if (xb_tgt === "core") {
                              $("#GameCarousel1and2").remove();
                              $("#GameCarousel3and4").remove();
                              showRotators = false;
                            } else if (xb_tgt === "cons") {
                              $(".carouselselection").remove();
                              $(".gcPc").remove();
                              $(".gcConsole").removeClass("hidden");
                              $("#GameCarousel1and2").css("display", "block");
                              $("#GameCarousel3and4").css("display", "block");
                            } else if (xb_tgt === "pcgp") {
                              $(".carouselselection").remove();
                              $(".gcConsole").remove();
                              $(".gcPc").removeClass("hidden");
                              $("#GameCarousel1and2").css("display", "block");
                              $("#GameCarousel3and4").css("display", "block");
                            } 
                          }
                          // end targeted content 2
                      }
                  }
              }
          }
      }
  }

  function listGames(plat, mem, coll, filt, sort, searchactive) {
      setTimeout(function() {
        console.table(plat, mem, coll, filt, sort, searchactive)
          $(".specialBanners").addClass("hide");
          $(".enhancedlink").addClass("hide");
          $(".eappcBanner").addClass("hide");
          $(".cloudEnabled").addClass("hide");
          $(".nogamesfound").addClass("hidden");
          
          if (coll === "all") {
              //get rid of coming soon from fga
              if (gameIdArrays["095bda36-f5cd-43f2-9ee1-0a72f371fb96"] !== undefined) {
                  fullGameArrayNoComingSoon = fullGameArray.filter(function(v) { return gameIdArrays["095bda36-f5cd-43f2-9ee1-0a72f371fb96"].indexOf(v) === -1 });
              }
              if (gameIdArrays["4165f752-d702-49c8-886b-fb57936f6bae"] !== undefined) {
                  fullGameArrayNoComingSoon = fullGameArray.filter(function(v) { return gameIdArrays["4165f752-d702-49c8-886b-fb57936f6bae"].indexOf(v) === -1 });
              }
              coll = fullGameArrayNoComingSoon;
          } else if (sort === "search") {
              coll = coll;
          } else {
              coll = gameIdArrays[coll];
          }
          if (coll === gameIdArrays["consoleleavingsoon"] || coll === gameIdArrays["pcleavingsoon"]) {
              $(".messageLeavingSoon").removeClass("hide");
          }
          if (coll === gameIdArrays["pdoConsole"] || coll === gameIdArrays["pdoPC"]) {
              $(".messagePlayDayOne").removeClass("hide");
          }

          // filters
          selectedGames = coll;

          //remove based on ratings
          prunedGames = [];
          var ratarrlen = selectedGames.length;

          var filterarray = filt;
          const filtJoined = filt.join(",");
          if (filterarray.length >= 0) {
              var theplat = $(".platformselection").attr("data-platselected");
              for (var i = 0; i < ratarrlen; i++) {
                  var memset, platset, genreset, featureset, ratingset, playonset, deliveryset, inputset;
                  memset = platset = genreset = featureset = ratingset = playonset = deliveryset = inputset = 0;
                  var filtsettotal;

                  // membership filter 
                  if (gameIdArrays[mem].includes(selectedGames[i]) || coll === gameIdArrays["consolecomingsoon"] ||
                      coll === gameIdArrays["pccomingsoon"] || coll === gameIdArrays["riotgamesconsole"]) {
                    memset = 1;
                  }

                  // plat filter
                  // if (filt.indexOf("plat-") !== -1) {
                  if (theplat === "xbox" && gameIdArrays["allconsole"].indexOf(selectedGames[i]) !== -1) {
                    platset = 1;
                  } else if (theplat === "pc" && gameIdArrays["allpc"].indexOf(selectedGames[i]) !== -1) {
                    platset = 1;
                  } else if ((theplat === "xbox" && coll === gameIdArrays["consolecomingsoon"]) || 
                             (theplat === "pc" && coll === gameIdArrays["pccomingsoon"]) || coll === gameIdArrays["riotgamesconsole"]) {
                    platset = 1
                  }

                  if (plat === "xbox" && coll === gameIdArrays["eagametrialsconsole"]) {
                    platset = 1
                    memset = 1
                  }
                  if (plat === "pc" && coll === gameIdArrays["eagametrialspc"]) {
                    platset = 1
                    memset = 1
                  }

                  // genre filter
                  if (filtJoined.indexOf("genre-") !== -1) {
                      if (filtJoined.indexOf("genre-indie") !== -1) {
                          if (theplat === "xbox") {
                              if (gameIdArrays["indieconsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["pcgaVTIndies"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }

                          // for (var h = 0; h < gameIdArrays["indie"].length; h++) {
                          //   if (selectedGames[i] === gameIdArrays["indie"][h]) {
                          //     genreset = 1;
                          //     break;
                          //   }
                          // }
                      }
                      if (filtJoined.indexOf("genre-family") !== -1 && theplat === "xbox") {
                          if (gameIdArrays["familyconsole"].indexOf(selectedGames[i]) !== -1) {
                              genreset = 1;
                          }
                      }
                      if (filtJoined.indexOf("genre-family") !== -1 && theplat === "pc") {
                          if (gameIdArrays["pcgaVTFamily"].indexOf(selectedGames[i]) !== -1) {
                              genreset = 1;
                          }
                      }
                      if (filtJoined.indexOf("genre-simulation") !== -1 && theplat === "pc") {
                          if (theplat === "xbox") {
                              if (gameIdArrays["simconsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["simpc"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }
                      }
                      if (filtJoined.indexOf("genre-strategy") !== -1 && theplat === "pc") {
                          if (theplat === "xbox") {
                              if (gameIdArrays["strategyconsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["pcgaVTStrategy"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }
                      }
                      if (filtJoined.indexOf("genre-rpg") !== -1) {
                          if (gameIdArrays["pcgaVTRPG"].indexOf(selectedGames[i]) !== -1) {
                              genreset = 1;
                          }
                      }
                      if (filtJoined.indexOf("genre-shooter") !== -1) {
                          if (theplat === "xbox") {
                              if (gameIdArrays["shootersconsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["shooterspc"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }
                      }
                      if (filtJoined.indexOf("genre-sports") !== -1) {
                          if (theplat === "xbox") {
                              if (gameIdArrays["sportsConsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["sportsPc"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }
                      }
                      if (filtJoined.indexOf("genre-action & adventure") !== -1) {
                          if (theplat === "xbox") {
                              if (gameIdArrays["actionconsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["actionpc"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }
                      }
                      if (filtJoined.indexOf("genre-platformers") !== -1) {
                          if (theplat === "xbox") {
                              if (gameIdArrays["platformerconsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["platformerpc"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }
                      }
                      if (filtJoined.indexOf("genre-puzzle") !== -1) {
                          if (theplat === "xbox") {
                              if (gameIdArrays["puzzleconsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["puzzlepc"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }
                      }
                      if (filtJoined.indexOf("genre-racing") !== -1) {
                          if (theplat === "xbox") {
                              if (gameIdArrays["racingconsole"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          } else if (theplat === "pc") {
                              if (gameIdArrays["racingpc"].indexOf(selectedGames[i]) !== -1) {
                                  genreset = 1;
                              }
                          }
                      }

                      if (filtJoined.indexOf("genre-role-playing") !== -1) {
                          if (gameIdArrays["rpgConsole"].indexOf(selectedGames[i]) !== -1) {
                              genreset = 1;
                          }
                      }

                      var genfilters = [];
                      filterarray.forEach(function(fa) {
                          if (fa.indexOf("genre-") !== -1) {
                              fa = fa.replace("genre-", "");
                              genfilters.push(fa);
                          }
                      })
                      genfilters.forEach(function(gf) {
                          if (allGames[selectedGames[i]]["genresAll"].join(" ").toLowerCase().indexOf(gf) !== -1) {
                              genreset = 1;
                          }
                      })
                  } else {
                      genreset = 1;
                  }

                  // feature filter
                  if (filtJoined.indexOf("feature-") !== -1) {
                      var allfeats = []
                      filterarray.forEach(function(fa) {
                          if (fa.indexOf("feature-") !== -1) {
                              allfeats.push(fa);
                          }
                      })
                      var featcount = 0;
                      for (var f = 0; f < allfeats.length; f++) {
                          if (allfeats[f] === "feature-4k") {
                              if (gameIdArrays["fourk"].indexOf(selectedGames[i]) !== -1) {
                                  featcount++;
                              }
                          } else if (allfeats[f] === "feature-smartdelivery") {
                              if (gameIdArrays["cross"].indexOf(selectedGames[i]) !== -1) {
                                  featcount++;
                              }
                          } else if (allfeats[f] === "feature-hdr") {
                              if (gameIdArrays["HDRGaming"].indexOf(selectedGames[i]) !== -1) {
                                  featcount++;
                              }
                          } else if (allfeats[f] === "feature-multiplayer") {
                              if (allGames[selectedGames[i]]["multiplayer"] === "true") {
                                  featcount++;
                              }
                          } else if (allfeats[f] === "feature-multiplayerlocal") {
                              if (gameIdArrays["multilocal"].indexOf(selectedGames[i]) !== -1) {
                                  featcount++;
                              }
                          } else if (allfeats[f] === "feature-coop") {
                              if (allGames[selectedGames[i]]["coop"] === "true") {
                                  featcount++;
                              }
                          } else if (allfeats[f] === "feature-cooplocal") {
                              if (gameIdArrays["cooplocal"].indexOf(selectedGames[i]) !== -1) {
                                  featcount++;
                              }
                          }
                      }
                      if (featcount === allfeats.length) { featureset = 1 }
                  } else {
                      featureset = 1;
                  }

                  // play on filter
                  if (filtJoined.indexOf("playon-") !== -1) {
                      if (filtJoined.indexOf("playon-seriesxs") !== -1) {
                          if (allGames[selectedGames[i]].platformxsx === "true") {
                              playonset = 1;
                          }
                      } else if (filtJoined.indexOf("playon-x1") !== -1) {
                          if (gameIdArrays["allconsole"].indexOf(selectedGames[i]) !== -1) {
                              playonset = 1;
                          }
                      } else if (filtJoined.indexOf("playon-windows") !== -1) {
                          if (gameIdArrays["allpc"].indexOf(selectedGames[i]) !== -1) {
                              playonset = 1;
                          }
                      } else if (filtJoined.indexOf("playon-android") !== -1) {
                          if (gameIdArrays["allCloud"].indexOf(selectedGames[i]) !== -1) {
                              playonset = 1;
                          }
                      } else if (filtJoined.indexOf("playon-apple") !== -1) {
                          if (gameIdArrays["allCloud"].indexOf(selectedGames[i]) !== -1) {
                              playonset = 1;
                          }
                      } else if (filtJoined.indexOf("playon-pc") !== -1) {
                          if (gameIdArrays["allpc"].indexOf(selectedGames[i]) !== -1) {
                              playonset = 1;
                          }
                      } else if (filtJoined.indexOf("playon-cloud") !== -1) {
                          if (gameIdArrays["allCloud"].indexOf(selectedGames[i]) !== -1) {
                              playonset = 1;
                              $(".cloudEnabled").removeClass("hide");
                          }
                      }
                  } else {
                      playonset = 1;
                  }

                  // delivery filter
                  if (filtJoined.indexOf("delivery-cloud") !== -1) {
                      if (gameIdArrays["allCloud"].indexOf(selectedGames[i]) !== -1) {
                          deliveryset = 1;
                      } else {
                          deliveryset = 0;
                      }
                  } else {
                      deliveryset = 1;
                  }

                  // inputs filter
                  if (filtJoined.indexOf("inputs-touch") !== -1) {
                      if (gameIdArrays["touchCloud"].indexOf(selectedGames[i]) !== -1) {
                          inputset = 1;
                      } else {
                          inputset = 0;
                      }
                  } else {
                      inputset = 1;
                  }

                  // rating filter
                  if (filtJoined.indexOf("rating-") !== -1) {
                      var allrats = []
                      filterarray.forEach(function(fa) {
                          if (fa.indexOf("rating-") !== -1) {
                              allrats.push(fa.replace("rating-", ""));
                          }
                      })
                      for (var f = 0; f < allrats.length; f++) {
                          if (allGames[selectedGames[i]]["rating"] === allrats[f]) {
                              ratingset = 1;
                          }
                      }
                  } else {
                      ratingset = 1;
                  }

                  filtsettotal = memset + platset + genreset + featureset + ratingset + playonset + deliveryset + inputset;
                  
                  if (filtsettotal === 8) { // game passes all 4 filters
                      prunedGames.push(selectedGames[i]);
                  }
              }
          } else {
            for (var p = 0; p < ratarrlen; p++) {
              prunedGames.push(selectedGames[p]);
            }
          }

          //sort based on sort
          if (sort === "newest") {
              // prunedGames = prunedGames.sort(asc_sort);
              // function asc_sort(a, b){
              //   return (new Date(allGames[a]["releasedate"])) < (new Date(allGames[b]["releasedate"])) ? 1 : -1;  
              // }
              prunedGames = prunedGames.sort(asc_sort);

              function asc_sort(a, b) {
                  var anewmatch = 0;
                  var bnewmatch = 0;
                  if (allGames[a]["recentxgp"] === "true" && allGames[b]["recentxgp"] === "true") {
                      if ((new Date(allGames[a]["moddate"])) > (new Date(allGames[b]["moddate"]))) {
                          return -1
                      } else {
                          return 1
                      }
                  }
                  if (allGames[a]["recentxgp"] === "true") {
                      return -1
                  } else {
                      return 1
                  }

                  //return anewmatch - bnewmatch || ($(a).data("mod")) < ($(b).data("mod")) ? 1 : -1;    
              }
          } else if (sort === "az") {
              prunedGames = prunedGames.sort(asc_sort);

              function asc_sort(a, b) {
                  return (allGames[b]["title"].toLowerCase().trim()) < (allGames[a]["title"].toLowerCase().trim()) ? 1 : -1;
              }
          } else if (sort === "za") {
              prunedGames = prunedGames.sort(asc_sort);

              function asc_sort(a, b) {
                  return (allGames[a]["title"].toLowerCase().trim()) < (allGames[b]["title"].toLowerCase().trim()) ? 1 : -1;
              }
          } else if (sort === "percdown") {
              prunedGames = prunedGames.sort(asc_sort);

              function asc_sort(a, b) {
                  return (parseInt(allGames[a]["silversaleperc"])) < (parseInt(allGames[b]["silversaleperc"])) ? 1 : -1;
              }
          } else if (sort === "percup") {
              prunedGames = prunedGames.sort(asc_sort);

              function asc_sort(a, b) {
                  return (parseInt(allGames[a]["silversaleperc"])) > (parseInt(allGames[b]["silversaleperc"])) ? 1 : -1;
              }
          } else if (sort === "pricedown") {
              prunedGames = prunedGames.sort(asc_sort);

              function asc_sort(a, b) {
                  return (allGames[a]["listprice"]) < (allGames[b]["listprice"]) ? 1 : -1;
              }
          } else if (sort === "priceup") {
              prunedGames = prunedGames.sort(asc_sort);

              function asc_sort(a, b) {
                  return (allGames[a]["listprice"]) > (allGames[b]["listprice"]) ? 1 : -1;
              }
          } else if (sort === "featured") {
              prunedGames = prunedGames;
          }

          // console.log("prunedGames: " + prunedGames)
          paginateSetup(prunedGames);

          //filtersort();
          $(".games .c-progress.f-indeterminate-local.f-progress-large").hide();
          $(".gameDivsWrapper").removeClass("gdSorting");
          if ($(".thecatalog .gameDiv").length === 0) {
              if (coll === gameIdArrays["consoleleavingsoon"]) { // all leaving
                  $(".nogamesfound p").text(regionContent["keyAllleavingsoon"])
              } else if (coll === gameIdArrays["consoleleavingsoon"]) {
                  $(".nogamesfound p").text(regionContent["keyConsolesleavingsoon"])
              } else if (coll === gameIdArrays["pcleavingsoon"]) {
                  $(".nogamesfound p").text(regionContent["keyPcleavingsoon"])
              } else {
                $(".nogamesfound p").text(regionContent["keyNogamesfound"])
              }
              $(".nogamesfound").removeClass("hidden");
              setTimeout(function() {
                $(".CatAnnounce").text(regionContent["keyNogamesfound"])
              }, 30)
          }

          // if (sort === "search" && prunedGames.length === 0) {
          //   $(".CatAnnounce").text(regionContent["keyNogamesfound"])
          // }

          if (plat === "all") {
              $(".availability").removeClass("hidden");
          } else {
              $(".availability").addClass("hidden");
          }
          if (plat === "xbox") {
              $(".filtConsoleOnly").show();
              $(".filtPCOnly").hide();
              $(".eappcBanner").addClass("hide");
              $(".allpcBanner").addClass("hide");
              $(".ubisoftpcBanner").addClass("hide");
              $(".riotgamespcBanner").addClass("hide");

          }
          if (plat === "pc") {
              $(".filtPCOnly").show();
              $(".filtConsoleOnly").hide();
              $(".allpcBanner").removeClass("hide");
              $(".ubisoftpcBanner").addClass("hide");
              $(".riotgamespcBanner").addClass("hide");
          }
          if (searchactive === true) {
              // setTimeout(function() {
              $(".xghsearch button").click();
              // }, 100)
          }
          
          // Needs to be below
          if (coll === gameIdArrays["ubisoftpc"]) {
              $(".ubisoftpcBanner").removeClass("hide");
              $(".riotgamespcBanner").addClass("hide");
              $(".eappcBanner").addClass("hide");
              $(".allpcBanner").addClass("hide");
          }
          if (coll === gameIdArrays["riotgamespc"]) {
              $(".riotgamespcBanner").removeClass("hide");
              $(".eappcBanner").addClass("hide");
              $(".allpcBanner").addClass("hide");
              $(".ubisoftpcBanner").addClass("hide");
          }
          if (coll === gameIdArrays["eaplayPC"]) {
              $(".eappcBanner").removeClass("hide");
              $(".ubisoftpcBanner").addClass("hide");
              $(".riotgamespcBanner").addClass("hide");
              $(".allpcBanner").addClass("hide");
          }

      }, 10);
  }  

  function paginateSetup(array) {
      paginate(array, 0);
      //ratings pop
      var systems = {};
      var currentgameslength = selectedGames.length;
      for (var i = 0; i < currentgameslength; i++) {
          var rs = allGames[selectedGames[i]]["ratingsystem"];
          if (!systems[rs]) {
              systems[rs] = 1
          } else {
              systems[rs]++
          }
      }
      var bigsystemnum = 0;
      var bigsystem;
      for (var g = 0; g < Object.keys(systems).length; g++) {
          if (systems[Object.keys(systems)[g]] > bigsystemnum) {
              bigsystemnum = systems[Object.keys(systems)[g]]
              bigsystem = Object.keys(systems)[g].toString();
          }
      }

      // $("#ratingSelect li.dynRatingItem").remove(); // to dynamically populate ratings, but MWF can't handle 
      if ($(".dynRatingItem").length === 0) {
          for (var i = 0; i < currentgameslength; i++) {
              if (allGames[selectedGames[i]]["ratingsystem"] !== bigsystem) {
                  allGames[selectedGames[i]]["rating"] = "none";
              } else {
                  var sentenceRating = allGames[fullGameArray[i]]["rating"].toLowerCase();
                  sentenceRating = sentenceRating.charAt(0).toUpperCase() + sentenceRating.slice(1,sentenceRating.length);
                  if (sentenceRating.indexOf("Pegi") !== -1) { // capitalize PEGI
                    sentenceRating = sentenceRating.toUpperCase();
                  }
                  allGames[fullGameArray[i]]["rating"].toLowerCase()
                  var gamerating = "rating-" + allGames[fullGameArray[i]]["rating"];
                  if ($(".ratingchoice[data-filt='" + gamerating + "']").length === 0 && allGames[fullGameArray[i]]["rating"] !== "none") {
                      $("#ratingFilter").append('<li class="dynRatingItem" data-ratingage="' + allGames[fullGameArray[i]]["ratingage"] + '">' +
                          '<a class="c-refine-item c-hyperlink ratingchoice" role="checkbox" href="#" aria-label="' + 
                            regionContent["keyRefineby"].replace("<PLACEHOLDER>", allGames[fullGameArray[i]]["rating"]) + 
                            '" data-filt="' + gamerating + '" aria-checked="false">' +
                          '<span>' + sentenceRating + '</span>' +
                          '</a></li>');
                  }
              }
              if (i === currentgameslength - 1) {
                  setTimeout(function() {
                      var $alphadivs = $(".dynRatingItem");
                      var alphaRat = $alphadivs.sort(function(a, b) {
                          return $(a).data("ratingage") > $(b).data("ratingage") ? 1 : -1;
                      });
                      $("#ratingFilter").html(alphaRat);
                  }, 250)
              }
          }
      }
  }

  function paginate(array, page, smclicked) {
      docwidth = $(document).width();
      var startgame = page * gamesperpage;
      let quantity = gamesperpage * 2;
      if (smclicked === true) {
        quantity = gamesperpage
      }
      shownGames = array.slice(startgame, startgame + quantity);
      
      gamehtml = '';
      var catarrlen = shownGames.length;
      for (var i = 0; i < catarrlen; i++) {
          var thebigid = shownGames[i];
          var msrpshown = allGames[thebigid]["msrpprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
          var listshown = allGames[thebigid]["listprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
          if (allGames[thebigid]["listprice"] !== 100000000) {
              if (allGames[thebigid]["msrpprice"] !== allGames[thebigid]["listprice"] && allGames[thebigid]["gameswithgold"] === "false") {
                  var priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                      //'<s aria-label="' + regionContent["keyFullprice"].replace("<PLACEHOLDER>", msrpshown) + '">' + msrpshown + '</s>' +
                      '<s><span class="x-screen-reader">' + regionContent["keyFullprice"] + '</span> ' + msrpshown + '</s>' +
                      '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' +
                      '<span class="textpricenew x-hidden-focus" itemprop="price">' + listshown + '</span>' +
                      '</div>';
              } else {
                  var priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                      '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' +
                      '<span class="textpricenew x-hidden-focus" itemprop="price">' + msrpshown + '</span>' +
                      '</div>';
              }
          } else {
              var priceshown = "";
          }

          var pricestartingat = "";
          if (gameIdArrays["startingat"].indexOf(thebigid) !== -1) {
              pricestartingat = '<div class="startingattext">' + regionContent["keyStartingat"] + '</div>';
          }

          badges = '';
          if (gameIdArrays["b8900d09-a491-44cc-916e-32b5acae621b"].indexOf(thebigid) > -1 ||
              gameIdArrays["1d33fbb9-b895-4732-a8ca-a55c8b99fa2c"].indexOf(thebigid) > -1) {
              badges += '<strong class="c-badge f-small f-highlight badge-silver c-caption-2">EA PLAY</strong>'
          }

          if (docwidth < 768) {
              var theboxshot = allGames[thebigid]["boxshotsmall"]
          } else {
              var theboxshot = allGames[thebigid]["boxshot"]
          }

          var disprelease = "-"
          if (allGames[thebigid]["releasedate"] !== 0) {
              var d = new Date(allGames[thebigid]["releasedate"]);
              if (d.getFullYear() < 2027) {
                  disprelease = d.toLocaleDateString(urlRegion, { year: 'numeric', month: 'long', day: 'numeric' });
              }
          }

          var thedescriptors = '';
          var rawdesc = allGames[thebigid]["descriptors"];
          var rdarray = rawdesc.split(",");
          var rdtext = [];
          for (var r = 0; r < rdarray.length; r++) {
            var descnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors.length;
            for (var s = 0; s < descnum; s++) {
              if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors[s].Key === rdarray[r]) {
                var desc = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors[s].Descriptor;
                rdtext.push(desc);
              }
            }                
          }
          thedescriptors = rdtext.join(",</span> <span class='descNoWrap'>");
          if (thedescriptors !== '') {
            thedescriptors = '<span class="descNoWrap">' + thedescriptors + "</span>"
          }
          var theinteractive = '';
          var rawint = allGames[thebigid]["interactive"];
          var rintarray = rawint.split(",");
          var rinttext = [];
          for (var r = 0; r < rintarray.length; r++) {
            var intnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements.length;
            for (var s = 0; s < intnum; s++) {
              if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements[s].Key === rintarray[r]) {
                var int = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements[s].InteractiveElement;
                rinttext.push(int);
              }
            }                
          }
          theinteractive = rinttext.join(",</span> <span class='descNoWrap'>");
          if (theinteractive !== '') {
            theinteractive = '<span class="descNoWrap">' + theinteractive + "</span>"
          }
          var thedisclaimers = '';
          var rawdisc = allGames[thebigid]["disclaimers"];
          var rdiscarray = rawdisc.split(",");
          var rdisctext = [];
          for (var r = 0; r < rdiscarray.length; r++) {
            var discnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers.length;
            for (var s = 0; s < discnum; s++) {
              if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers[s].Key === rdiscarray[r]) {
                var disc = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers[s].Disclaimer;
                if (disc.length > 48) {
                  var discarr = disc.split(". ");
                  disc = discarr.join(". <br>");
                }
                rdisctext.push(disc);
              }
            }                
          }
          thedisclaimers = rdisctext.join(",</span> <span class='descNoWrap'>");
          if (thedisclaimers !== '') {
            thedisclaimers = '<span class="descNoWrap">' + thedisclaimers + "</span>"
          }

          var popiconRating, popiconEnhanced, popiconsXpa, popicon4k, popiconHdr;
          popiconRating = popiconEnhanced = popiconXpa = popicon4k = popiconHdr = '';

          var previousExists = false;

          if (allGames[thebigid]["rating"] === "none") {
              popiconRating = '';
              // } else if (ratingImages[allGames[thebigid]["rating"]] !== undefined) {
              //   popiconRating = '<span class="popicon piRating"><img src="' + ratingImages[allGames[thebigid]["rating"]] + '"></span>';
          } else {
              popiconRating = '<span class="popicon piRating">' + allGames[thebigid]["rating"] + '</span>';
          }

          if (gameIdArrays["genNine"].indexOf(thebigid) !== -1) {
              popiconEnhanced = '<span class="c-paragraph-3"> ' + quickLookLocStrings.locales[urlRegion]["keyOptimizedforxboxseriesxs"] + ' </span>';
              previousExists = true;
          }

          if (gameIdArrays["cross"].indexOf(thebigid) !== -1) {
              if (previousExists) {
                popiconXpa = '<span class="featureCircle">&nbsp;&nbsp;●&nbsp;&nbsp;</span>'
              }
              popiconXpa += '<span class="c-paragraph-3"> ' + quickLookLocStrings.locales[urlRegion]["keySmartdelivery"] + ' </span>';
              previousExists = true;
          }

          var popbadges = '';
          var popgoldprice = '';

          if (allGames[thebigid]["goldandsilversale"] === "true") {
              popbadges += '<span class="c-badge f-small f-highlight">' + regionContent["keyPopgolddiscount"] + '</span>';
              var specialshown = allGames[thebigid]["goldandsilversalegoldprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
              popgoldprice += '<div class="popgoldarea"><div class="c-price popgoldprice" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                  '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' +
                  '<span class="textpricenew x-hidden-focus" itemprop="price">' + specialshown + '</span>' +
                  '</div>' +
                  '<img class="popgoldlogo" src="https://assets.xboxservices.com/assets/e3/5b/e35b00a6-abca-4905-a709-288f1a0521da.svg?n=X1-Games-Catalog_0_Gold-Logo_64x23.svg"></div>';
          } else if (allGames[thebigid]["golddiscount"] === "true" || allGames[thebigid]["gameswithgold"] === "true") {
              popbadges += '<span class="c-badge f-small f-highlight">' + regionContent["keyPopgolddiscount"] + '</span>';
              var specialshown = allGames[thebigid]["specialprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
              popgoldprice += '<div class="popgoldarea"><div class="c-price popgoldprice" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                  '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' +
                  '<span class="textpricenew x-hidden-focus" itemprop="price">' + specialshown + '</span>' +
                  '</div>' +
                  '<img class="popgoldlogo" src="https://assets.xboxservices.com/assets/e3/5b/e35b00a6-abca-4905-a709-288f1a0521da.svg?n=X1-Games-Catalog_0_Gold-Logo_64x23.svg"></div>';
          }

          var popservices = '';
          var abovetitle = '';
          if (allGames[thebigid]["gamepassgame"] === "true") {
              // popservices += '<div class="servicesarea"><p>' + regionContent["keyPopgpgame"] + '</p></div>';
              abovetitle = '<div class="c-glyph gp-glyph"><img src="https://assets.xboxservices.com/assets/bd/d6/bdd616b4-9210-4d36-9d4f-0f9f21969131.svg?n=Games-Catalog_Image-0_Game-Pass-Badge_144x24.svg" alt="game pass icon"/></div>';
          }
          if (allGames[thebigid]["eaaccessgame"] === "true" && allGames[thebigid]["specialprice"] !== 100000000) {
              var eaprice = allGames[thebigid]["specialprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
              popservices += '<div class="servicesarea"><p>' + regionContent["keyPopeagame"].replace("<PLACEHOLDER>", eaprice) + '</p></div>';
          }

          var popbuytext = regionContent["keyBuynow"];
          if (allGames[thebigid]["title"].toLowerCase().indexOf("preview") !== -1 || allGames[thebigid]["description"].toLowerCase().indexOf("game preview") !== -1) {
              var popbuytext = regionContent["keyBuynow"];
          } else if (gameIdArrays["upcoming"].indexOf(thebigid) !== -1 && allGames[thebigid]["purchasable"] === "true") {
              popbuytext = regionContent["keyPreordernow"];
          }
          // var popgettext = regionContent["keyGetitnow"]; change all to learn more
          var popgettext = regionContent["keyLearnmore"];

          var dataret = '';
          if (allGames[thebigid]["gameurl"].toLowerCase().indexOf("games/store") !== -1) {
              dataret = 'data-retailer="ms store"'
          }

          if (allGames[thebigid]["gameurl"].toLowerCase().indexOf("games/store") !== -1) {
              priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" class="c-call-to-action c-glyph popbuynow" target="_blank" ' + 
                  ' aria-label="' + popgettext + ", " + allGames[thebigid]["title"] + '"' + dataret + '>' +
                  '<span>' + popgettext + '</span>' +
                  '</a>'
          } else {
              priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" class="c-call-to-action c-glyph" target="_blank"' + 
                  ' aria-label="' + regionContent["keyLearnmore"] + " about " + allGames[thebigid]["title"] + '">' +
                  '<span>' + popgettext + '</span>' +
                  '</a>'

          }
          if (gameIdArrays["upcoming"].indexOf(thebigid) !== -1 && allGames[thebigid]["purchasable"] === "false") {
              popprice = '<div class="popprice">'
              popbadges = '';
              priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                  '<span class="textpricenew soontextprice x-hidden-focus" itemprop="price">' + regionContent["keyBadgecomingsoonlower"] + '</span>' +
                  '</div>';
              popgoldprice = '';
              popservices = '';
              priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" class="c-call-to-action c-glyph" target="_blank"' + 
                  ' aria-label="' + regionContent["keyLearnmore"] + "about " + allGames[thebigid]["title"] + '">' +
                  '<span>' + regionContent["keyLearnmore"] + '</span>' +
                  '</a>'
          } else {
              popprice = '<div class="popprice">'
          }

          var plxb = '';
          var plpc = '';
          var plxsx = '';
          var plmo = '';
          var availon = '';

          if (allGames[thebigid]["platformxsx"] === "true") {
              plxsx = '<div class="c-tag">' +
                  // '<span class="c-glyph svg-xbox-series-x"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048" width="20" height="20"><path d="M832 384q-26 0-45-19t-19-45q0-26 19-45t45-19q26 0 45 19t19 45q0 26-19 45t-45 19zM512 0h1024v2048H512V0zm896 1920V128H640v1792h128v-896h128v896h512z"></path></svg></span>' +
                  'Xbox Series X|S' +
                  '</div>';
          }

          if (allGames[thebigid]["platformxo"] === "true") {
              plxb = '<div class="c-tag">' +
                  // '<span class="c-glyph glyph-xbox-one-console"></span>' + 
                  'Xbox One' +
                  '</div>';
              availon = '<div class="availability"><div><p class="c-caption-1">' + regionContent["keyPlatform"] + ':<span class="c-glyph" aria-label="Console"></span></p></div></div>'
          }
          if (allGames[thebigid]["platformpc"] === "true") {
              plpc = '<div class="c-tag">' +
                  // '<span class="c-glyph glyph-pc1"></span>' + 
                  //'PC' + 
                  quickLookLocStrings.locales[urlRegion]["keyPc"] +
                  '</div>';
              availon = '<div class="availability"><div><p class="c-caption-1">' + regionContent["keyPlatform"] + ':<span class="c-glyph" aria-label="PC"></span></p></div></div>'
          }
          if (gameIdArrays["allCloud"].indexOf(thebigid) !== -1 && nonCloudRegions.indexOf(urlRegion) === -1) {
              plmo = '<div class="c-tag capitalFirst">' +
                  // '<span class="c-glyph glyph-mobile-tablet"></span>' +
                  // quickLookLocStrings.locales[urlRegion]["keyMobile"] +
                  quickLookLocStrings.locales[urlRegion]["keyCloud"].toLowerCase() +
                  // 'Android' +
                  '</div>';
          }
          if (allGames[thebigid]["platformpc"] === "true" && allGames[thebigid]["platformxbox"] === "true") {
              availon = '<div class="availability"><div><p class="c-caption-1">' + regionContent["keyPlatform"] +
                  ':<span class="c-glyph" aria-label="Console"></span><span class="c-glyph" aria-label="PC"></span></p></div></div>'
          }

          var qlbutclass = '';
          if (allGames[thebigid]["physical"] === "true") { qlbutclass = ' physgame' }
          var eappclass = '';
          var notab = '';

          var eachGameClass = '';
          if (docwidth > 1083 && navigator.userAgent.indexOf("iPad") === -1) { // Added check -EL 11/23/20
              eachGameClass = 'm-product-placement-item f-size-medium context-game gameDiv';
          } else {
              eachGameClass = 'm-product-placement-item f-size-medium context-game gameDiv qlButtonFunc';
          }
          if (thebigid === "9N0H62KZ3BXV") {
            eachGameClass = 'm-product-placement-item f-size-medium context-game gameDiv qlButtonFuncNew';
          }
          var gamehref = allGames[thebigid]["gameurl"];
          if (allGames[thebigid]["eaplaypcgame"] === "true" || allGames[thebigid]["riotgamespc"] === "true" || (thebigid === "9N0H62KZ3BXV")) {
              eappclass = ' eappgame';
              gamehref = "";
              notab = 'tabindex="-1" role="presentation"';
          }
          var x360class = '';
          if (allGames[thebigid]["x360game"] === "true") { x360class = ' x360game' }
          var playsonimg = '';
          if (allGames[thebigid]["playson"] === "true") { playsonimg = '<img class="playsOn" src="https://assets.xboxservices.com/assets/ed/30/ed30bd9f-5631-4d38-8bca-d9610f8c74c7.png?n=EN_Plays-on-Xbox-One_Branding-Bar_215x51.png" alt="Plays on">' }
          var eachgameA = '<section class="showmoreHidden ' + eachGameClass + qlbutclass + x360class + '" itemscope="" itemtype="http://schema.org/Product" data-bigid="' + thebigid + '" ' +
              'data-releasedate="' + allGames[thebigid]["releasedate"] + '" data-msproduct="' + allGames[thebigid]["msproduct"] + '" data-multiplayer="' + allGames[thebigid]["multiplayer"] +
              '" data-rating="' + allGames[thebigid]["rating"] + '" data-ratingsystem="' + allGames[thebigid]["ratingsystem"] + '" data-listprice="' + allGames[thebigid]["listprice"] + '">' +
              '<a class="gameDivLink' + eappclass + '" href="' + gamehref + '" target="_blank" ' + dataret + notab + '>' +
              '<picture class="containerIMG">' +
              '<img class="c-image" aria-hidden="true" alt="' + boxshotlocstrings.locales[urlRegion]["keyPlaceholderboxshot"].replace("<PLACEHOLDER>", allGames[thebigid]["title"]) +
              '" srcset="" src="' + theboxshot + '">' +
              playsonimg +
              availon +
              '</picture>' +
              badges +
              '<div>' +
              '<h3 class="c-subheading-4 x1GameName" itemprop="product name">' + allGames[thebigid]["title"] + '</h3>' +
              //priceshown + 
              '</div>' +
              '</a>';

          var interactiveLine = '';
          var disclaimersLine = '';
          if (theinteractive !== '' && thedescriptors !== '') {
            interactiveLine = '<div class="descLine"></div>';
          }
          if (thedisclaimers !== '' && (theinteractive !== '' || thedescriptors !== '')) {
            disclaimersLine = '<div class="descLine"></div>';
          }

          var quickLookButton = '<div class="qlButton">' +
              '<button class="c-call-to-action c-glyph black-c" tabindex="0" aria-label="' + regionContent["keyQuickaria"] + '">' + regionContent["keyQuicklook"] + '</button>' +
              '</div>';

          var eawin10class = "";

          if ((allGames[thebigid]["eaplaypcgame"] === "true" && win10user === true) || (thebigid === "9N0H62KZ3BXV")) {
              priceButtons = $(".win10link").html();
              eawin10class = " eaw10 ";
          }
          if (allGames[thebigid]["eaplaypcgame"] === "true" && win10user === false) {
              priceButtons = $(".nonwin10link").html();
              eawin10class = " eanw10 ";
          }
          if (allGames[thebigid]["riotgamespc"] === "true" && win10user === true) {
              priceButtons = $(".win10linkriot").html();
              eawin10class = " eaw10 ";
          }
          if (allGames[thebigid]["riotgamespc"] === "true" && win10user === false) {
              priceButtons = $(".nonwin10linkriot").html();
              eawin10class = " eanw10 ";
          }
          if (allGames[thebigid]["ubisoftpc"] === "true" && win10user === true) {
              priceButtons = $(".ubisoftlink").html();
          }

          var thepoptitle = allGames[thebigid]["title"];
            if (thepoptitle.length > 68) {
              thepoptitle = thepoptitle.slice(0, 68) + "...";
            }
            var thedescription = '';
            if (allGames[thebigid]["description"] !== null) { thedescription = allGames[thebigid]["description"]; }
            if (thedescription.length > 200) {
              var descarr = thedescription.split(".");
              var newdesc = '';
              if (descarr[0].length > 200) {
                thedescription = descarr[0].slice(0, 200) + "...";
              } else if (descarr.length > 1) {
                newdesc = descarr[0];
                for (var d = 1; d < descarr.length; d++) {
                  if (newdesc.length + descarr[d].length > 200) {
                    break;
                  } else {
                    newdesc = newdesc + ". " + descarr[d];
                  }
                }
                thedescription = newdesc + ".";
              }
            }

          var eachgamePopup = '<div class="gameMoreInfo' + eawin10class + '" role="dialog" aria-label="dialog window with ' + allGames[thebigid]["title"] + ' information">' +
              '<div tabindex="0" class="qclosebutton" aria-label="close button for dialog window" role="button">' +
              '<img src="https://assets.xboxservices.com/assets/f4/6c/f46cc9e8-ce1f-4226-8713-89683d2a2a76.svg?n=Games-Catalog_Image-0_X-Button_230x120.svg" alt="close button">' +
              '</div>' +
              '<div class="poprotator">' +
              // therotator +
              // '<div class="c-age-rating"><img class="c-image" src="' + allGames[thebigid]["ratimage"] + '" alt=""></div>' +
              '</div>' +
              '<div class="popinfo">' +
              abovetitle +
              '<div class="poptitle">' +
              '<h3 class="c-heading" itemprop="product name">' + thepoptitle + '</h3>' +
              '</div>' +
              '<div class="popicons">' +
              // popiconRating + 
              popiconEnhanced + popiconXpa + popicon4k + popiconHdr +
              '</div>' +
              '<div class="popdescription">' +
              '<div class="furtherrelease"><span class="furthheading">' + regionContent["keyDescription"] +
              ': </span><span class="furthcontent">' + thedescription + '</span></div>' +
              '<div class="platformdescription"><div class="furtherplatform"><span class="furthheading">' + regionContent["keyPlatform"] +
              ': </span>' + plxsx + plxb + plpc + plmo + '</div></div>' +
              '</div>' +
              '<div class="popbottom">' +
              //'<div class="popprice">' +
              //badges + 
              popprice +
              popbadges +
              pricestartingat +
              priceshown +
              popgoldprice +
              popservices +
              '</div>' +
              '<div class="popButton">' +
              priceButtons +
              '</div>' +
              '<div class="poprating">' +
              '<div class="prLeft">' +
              '<div class="c-age-rating"><img class="c-image" src="' + allGames[thebigid]["ratimage"] + '" alt=""></div>' +
              '</div>' +
              '<div class="prRight">' +
              '<a href="' + allGames[thebigid]["ratingUrl"] + '" class="c-hyperlink poplastbutton" aria-label="' + regionContent["keyAriaratings"].replace("<PLACEHOLDER>", allGames[thebigid]["rating"]) + 
              '" data-cta="external" target="_blank">' + allGames[thebigid]["rating"] + '</a>' +
              '<div class="ratingdescriptors">' + thedescriptors + '</div>' +
              interactiveLine +
              '<div class="ratinginteractive">' + theinteractive + '</div>' +
              disclaimersLine +
              '<div class="ratingdisclaimers">' + thedisclaimers + '</div>' +
              '</div>' +
              '</div>' +
              '</div>' +
              '</div>' +
              '</div>';

          var eachgameB = '</section>';

          gamehtml += eachgameA + quickLookButton + eachgamePopup + eachgameB;
      }

      let showmorePageAdd = 1;
      if (page === 0) {
        $(".gameDivsWrapper .gameDiv").remove();
        $(".gameDivsWrapper").append(gamehtml);
        showmorePageAdd = 2
      } else {
        $(".gameDivsWrapper .gameDiv").last().after(gamehtml)
      }
      if (thebigid === "9N0H62KZ3BXV") {
        $(".popButton .padBot").text(regionContent["keyAccessapp"]);
      }

      // if (page === 0 && array.length > gamesperpage + 6) {
      //     setTimeout(function() {
      //         $(".gameDivsWrapper").css("min-height", "32vw");
      //     }, 2000)
      // }
      $(".gamesTotal").text(prunedGames.length);
      showMoreSetup(page + showmorePageAdd);
  }

  // tab only in popups
  setTimeout(function() { // with second close button
      /*redirect last tab to first input*/
      $(document).on("keydown", function(e) {
          if (e.keyCode === 9 && !e.shiftKey) {
              if ($(".gameMoreInfo.popupShow .poplastbutton")[0] === document.activeElement) {
                  e.preventDefault();
                  $(".gameMoreInfo.popupShow .qclosebutton").focus()
              }
          }
      })

      $(document).on("click", ".eappgame", function(e) {
          e.preventDefault();
          var winWidth = $(document).width();
          if (winWidth > 767) {
            $(this).next(".qlButton").find("button").click();
          }
      })
          /*redirect first shift+tab to last input*/
      $(document).on('keydown', ".gameMoreInfo.popupShow .qclosebutton", function(e) {
          if ((e.keyCode === 9 && e.shiftKey)) {
              e.preventDefault();
              $(".gameMoreInfo.popupShow .poplastbutton").focus()
              if ($(".gameMoreInfo.popupShow .qclosebutton")[0] === document.activeElement) {
                  $(".gameMoreInfo.popupShow .poplastbutton").focus()
              }
          }
      });


  }, 250)

  // shift tab to focus on quick look
  $(document).on('keydown', function(e) {
      if ((e.keyCode === 9 && e.shiftKey)) {
          if (document.activeElement.classList.contains('gameDivLink') && $(".gameDivLink").eq(0)[0] !== document.activeElement) {
              //e.preventDefault();
              setTimeout(function() {
                  var theactive = document.activeElement;
                  if ($(theactive)[0].nodeName === "BUTTON") {
                    $(theactive).closest(".gameDiv").next(".gameDiv").find(".qlButton").removeClass("popupShow");
                    $(theactive).closest(".gameDiv").find(".qlButton").addClass("popupShow");
                    $(theactive).closest(".gameDiv").find(".qlButton button").focus();
                  }
              }, 10)
          }
      }
  });

  let smExpanded = "false";

  const showMoreButton = function(nextPage) {
    return '<div class="x-type-center drawerContainer">' +
        '<a href="javascript:void(0)" class="showMoreText c-call-to-action zpt " aria-expanded="' + smExpanded + '" ' +
        'aria-label="' + regionContent["keyLoadmorearia"] + '" role="button" data-nextpage="' + nextPage +  '" ' + 
        'tabindex="0">' + regionContent["keyLoadmore"] + '</a></div>'
  }

  function showMoreSetup(page) {
    $(".drawerContainer").remove();
    if (page <= 2) {
      $(".gameDivsWrapper").find(".showmoreHidden").slice(0, gamesperpage).removeClass("showmoreHidden");
    }

    if ($(".gameDivsWrapper").find(".showmoreHidden").length > 6) { // no need for see more if not that many more
      $(".gameDivsWrapper").find(".gameDiv").not(".showmoreHidden").last().after(showMoreButton(page))
    } else {
      $(".showmoreHidden").removeClass("showmoreHidden")
    }
  }

  $(document).on("click", ".showMoreText", function(e) {
    e.preventDefault();
    smExpanded = "true";
    $(".showmoreHidden").removeClass("showmoreHidden");
    const topPos = document.documentElement.scrollTop + 160;
    const toFocus = $(this).closest(".drawerContainer").next(".gameDiv").find(".gameDivLink");
    const nextPage = parseInt($(this).attr("data-nextpage"));
    if ($(".CatAnnounce").text() === regionContent["keyLmclicked"]) {
      $(".CatAnnounce").text(regionContent["keyLmclicked"] + ".");
    } else {
      $(".CatAnnounce").text(regionContent["keyLmclicked"]);
    }

    paginate(prunedGames, nextPage, true);
    $("HTML, BODY").animate({
        scrollTop: topPos
    }, 500);
    setTimeout(function() {
      $(toFocus)[0].focus(); 
    }, 600)
  }) 

  $(document).on("focus, click", "#gamesort input", function(e) {
    const sortText = $(this).next("span").text();
    $(".currentSort").text(sortText);
    const sortVal = $(this).val();
    $("#gamesort").attr("data-sort", sortVal);
    setTimeout(function() {
      $(".CatAnnounce").text(regionContent["keySortupdate"].replace("<PLACEHOLDER>", sortText));
    }, 20)
    
    filtersort()
  })

  $(document).on("focus, click", ".membershipsFilter input", function(e) {
    const selText = $(this).next("span").text();
    const selVal = $(this).val();
    $(this).closest(".selectSet").attr("data-membership", selVal);
    setTimeout(function() {
      $(".CatAnnounce").text(regionContent["keyMemupdate"].replace("<PLACEHOLDER>", selText));
    }, 20)
    $(".collectionsFilter.coreOnly").addClass("hidden");
    if (selVal === "allGamesXboxCore") {
      $(".collectionsFilter.coreOnly").removeClass("hidden");
      $(".collectionsFilter.pcOnly").addClass("hidden");
      $(".collectionsFilter.consoleOnly").addClass("hidden");
    } else if (selVal === "allpc") {
      $(".collectionsFilter.pcOnly").removeClass("hidden");
      $(".collectionsFilter.consoleOnly").addClass("hidden");
    } else if (selVal === "allconsole") {
      $(".collectionsFilter.pcOnly").addClass("hidden");
      $(".collectionsFilter.consoleOnly").removeClass("hidden");
    }

    if (!$(this).hasClass("platformSelecting")) {
      filtersort()
    }
  })

  $(document).on("focus, click", ".collectionsFilter input", function(e) {
    const selText = $(this).next("span").text();
    const selVal = $(this).val();
    $(this).closest(".selectSet").attr("data-collection", selVal);
    setTimeout(function() {
      $(".CatAnnounce").text(regionContent["keyCollupdate"].replace("<PLACEHOLDER>", selText));
    }, 20)
    
    if (!$(this).hasClass("platformSelecting")) {
      filtersort()
    }
  })

  function filtersort() {
    smExpanded = "false";
    const thePlat = $(".platformselection").attr("data-platselected");
    const theMembership = $(".membershipsFilter").not(".hidden").find(".selectSet").attr("data-membership");
    const theCollection = $(".collectionsFilter").not(".hidden").find(".selectSet").attr("data-collection");
    let theFilters = [];
    $(".c-drawer.f-checkbox a.f-selected").each(function() {
      theFilters.push($(this).attr("data-filt"))
    })
    const theSort = $("#gamesort").attr("data-sort");

    if (theMembership === "allGamesXboxCore") {
      $(".noCore").addClass("coreHidden");
    } else {
      $(".noCore").removeClass("coreHidden");
    }

    $(".c-drawer.f-checkbox a").each(function() {
      const dataFilt = $(this).attr("data-filt");
      const type = dataFilt.split("-")[0]
      const thefilt = dataFilt.split("-")[1]
      if (!$(this).hasClass("f-selected")) {
        $(this).attr("aria-checked", "false")
        if ($(".filterSelections [data-selected='" + dataFilt + "']").length === 1) {
          removeFilterSummary(dataFilt);
        }
      } else {
        $(this).attr("aria-checked", "true")
        if ($(".filterSelections [data-selected='" + dataFilt + "']").length === 0) {
          console.log("adding filter " + dataFilt)
          addFilterSummary(dataFilt)
        }
      }

      // mobile filter close buttons
      if ($(".ui .f-checkbox .f-selected").length === 0) {
        $(".closeFilters").removeClass("hidden");
        $(".showResults").addClass("hidden");
      } else {
        $(".closeFilters").addClass("hidden");
        $(".showResults").removeClass("hidden");
      }
    })

    listGames(thePlat, theMembership, theCollection, theFilters, theSort)
    mobileZoom();
  }

  $(document).on("click", ".c-drawer.f-checkbox a", function(e) {
    e.preventDefault();
    $(this).toggleClass("f-selected")
    removeSearchSummary();
    filtersort();
  })

  $(document).on("click", ".filterSelections a", function(e) {
    e.preventDefault();
    const thefilt = $(this).closest("li.c-choice-summary").attr("data-selected");
    removeFilterSummary(thefilt);
    removeSearchSummary();
    filtersort();
  })

  $(document).on("click", ".clearFilters", function(e) {
    e.preventDefault();
    $(".gamesearch input").val("");
    clearFilters();
    removeSearchSummary();
  })

  $(document).on("click", ".c-search.gamesearch button", function(e) {
    e.preventDefault();
    const val = $(this).closest(".c-search").find("input").val().trim().replace(/\s+/g, ' ').replace(/</g, "").toLowerCase();
    gameSearch(val);
  })

  function addFilterSummary(filt) {
    const filtText = $("[data-filt='" + filt + "']").find("span").text();
    const filtAria = regionContent["keyRemovefilter"].replace("<PLACEHOLDER>", filtText);
    if ($(".filterSelections [aria-label='" + filtAria + "']").length === 0) {
      $(".filterSelections").append('<li class="c-choice-summary" data-selected="' + filt + '">' +
          '<a class="c-action-trigger c-glyph glyph-cancel" href="#" aria-label="' + filtAria + '">' +
            '<span class="x-screen-reader">' + filtAria + '</span></a>' +
        '<span class="summaryText">' + filtText + '</span></li>')
      $(".CatAnnounce").text(regionContent["keyFilteradded"].replace("<PLACEHOLDER>", filtText));
    }
    filterCount();
  }

  function removeFilterSummary(filt) {
    $("[data-filt='" + filt + "']").removeClass("f-selected");
    const filtText = $(".filterSelections [data-selected='" + filt + "']").find(".summaryText").text();
    $(".filterSelections [data-selected='" + filt + "']").remove();
    $(".CatAnnounce").text(regionContent["keyFilterremoved"].replace("<PLACEHOLDER>", filtText));
    filterCount();
  }

  function clearFilters() {
    $(".c-drawer.f-checkbox li a").removeClass("f-selected").attr("aria-checked", "false");
    filtersort();
    setTimeout(function() {
      $(".CatAnnounce").text(regionContent["keyFilterscleared"])  
    }, 50)
  }

  function filterCount() {
    const filterCount = $(".filterSelections li").length;
    $(".filterCount").text(filterCount);
  }

  // $(".xghsearch button").on("click", function(e) {
  //     e.preventDefault();
  //     gameSearch();
  // })

  function addSearchSummary(str) {
    const filtAria = regionContent["keyRemovefilter"].replace("<PLACEHOLDER>", str);
    if ($(".filterSelections [aria-label='" + filtAria + "']").length === 0) {
      $(".filterSelections").append('<li class="c-choice-summary" data-selected="search">' +
          '<a class="c-action-trigger c-glyph glyph-cancel" href="#" aria-label="' + filtAria + '">' +
            '<span class="x-screen-reader">' + filtAria + '</span></a>' +
        '<span class="summaryText">' + "'" + str + "'" + '</span></li>')
      $(".CatAnnounce").text(regionContent["keyFilteradded"].replace("<PLACEHOLDER>", str));
    }
    filterCount();
  }

  function removeSearchSummary() {
    if ($(".filterSelections li").length > 0) {
      const filtText = $(".filterSelections [data-selected='search']").find(".summaryText").text();
      $(".CatAnnounce").text(regionContent["keyFilterremoved"].replace("<PLACEHOLDER>", filtText));
      $(".filterSelections [data-selected='search']").remove();
      $(".product").removeClass("hidden");
    }
    filterCount();
  }

  function gameSearch(theval) {
    // clearFilters();
    removeSearchSummary()
      if ($(".filterSelections a").length > 0) {
          $(".filterSelections li").remove();
      }
      var newplat = $(".platselected").attr("data-theplat");
      var queryraw = encodeURI(theval.replace("<", "")).replace(/[!'()*]/g).replace(/%20/g, " ");
      var query = encodeURI(theval.replace(/\s+/g, ' ').replace("<", "").toLowerCase()).replace(/[!'()*]/g).replace(/%20/g, " ");
      resetFilters(true, true, newplat);
      $(".searcherrormessage").text("");
      
      searchArray = [];
      var searchObj = {};

      var smallwords = ["the", "a", "an", "of", "for", "and", "or", "it", "in", "on", "with", "as", "at", "be", "but", "by", "from", "had", "has", "how", "if", "its", "so", "than", "that",
          "to", "too", "was"
      ]; // "stop words"
      var allgameslength = fullGameArray.length;

      var queryarr = query.split(" ");
      // remove stop words
      var tempquery = [];
      for (var i = 0; i < queryarr.length; i++) {
          if (smallwords.indexOf(queryarr[i]) === -1) {
              tempquery.push(queryarr[i]);
          }
      }
      queryarr = tempquery;
      for (var i = 0; i < allgameslength; i++) {
          var titlesch = allGames[fullGameArray[i]]["title"].replace(/\s+/g, ' ').toLowerCase();
          var titlearr = titlesch.split(" ");

          var wordmatches = 0;
          for (var k = 0; k < queryarr.length; k++) {
              var queryword = queryarr[k];
              for (var m = 0; m < titlearr.length; m++) {
                  var titleword = titlearr[m];
                  if (queryword.length === titleword.length) {
                      var lettermatches = 0;
                      for (var n = 0; n < queryword.length; n++) {
                          if (queryword[n] === titleword[n]) {
                              lettermatches++;
                          }
                      }
                      if (lettermatches / queryword.length === 1) {
                          if (typeof searchObj[fullGameArray[i]] === "undefined") {
                              searchObj[fullGameArray[i]] = {};
                              searchObj[fullGameArray[i]].exacts = 1;
                          } else {
                              searchObj[fullGameArray[i]].exacts++;
                          }

                      } else if (lettermatches / queryword.length >= .75) {
                          // wordmatches++;
                          if (typeof searchObj[fullGameArray[i]] === "undefined") {
                              searchObj[fullGameArray[i]] = {};
                              searchObj[fullGameArray[i]].exacts = 0;
                          }
                      }
                  }
              }

          }


          // last straight matches
          if (titlesch.toLowerCase().replace("®", "").replace("™", "").indexOf(query) !== -1) { // && typeof searchObj[fullGameArray[i]] === "undefined"
              searchObj[fullGameArray[i]] = {};
              searchObj[fullGameArray[i]].exacts = 999;
          }
      }
      searchArray = Object.keys(searchObj);
      searchArray = searchArray.sort(asc_sortbi);

      function asc_sortbi(a, b) {
          return (new Date(searchObj[a]["exacts"])) < (new Date(searchObj[b]["exacts"])) ? 1 : -1;
      }
      if (newplat === "xbox") {
          searchArray = searchArray.filter(function(v) { return gameIdArrays["allconsole"].indexOf(v) !== -1 });
          if (gameIdArrays["consolecomingsoon"] !== undefined) { //coming soon should not be searched
              searchArray = searchArray.filter(function(v) { return gameIdArrays["consolecomingsoon"].indexOf(v) === -1 });
          }
      } else if (newplat === "pc") {
          searchArray = searchArray.filter(function(v) { return gameIdArrays["allpc"].indexOf(v) !== -1 });
          if (gameIdArrays["pccomingsoon"] !== undefined) {
              searchArray = searchArray.filter(function(v) { return gameIdArrays["pccomingsoon"].indexOf(v) === -1 });
          }
      }

      var availtype = "avail-download";

      var plattosend = $(".platformselection").attr("data-platselected");
      const theMembership = $(".membershipsFilter").not(".hidden").find(".selectSet").attr("data-membership");
      let theFilters = [];

      $(".CatAnnounce").text(regionContent["keyFiltersearch"].replace("<PLACEHOLDER>, queryraw"));
      // listGames(searchArray, availtype, "search", plattosend);
      listGames(plattosend, theMembership, searchArray, theFilters, "search")
      addSearchSummary(theval)
      $(".gamesTotal").text(searchArray.length)
  }

  // popup
  $(document).on("mouseenter", ".gameDiv a.gameDivLink", function(e) {
      //$(e.target).off("mouseleave");
      var buttontoshow = $(e.target).closest(".gameDiv").find(".qlButton");
      $(".popupShow").removeClass("popupShow");
      $(buttontoshow).addClass("popupShow");
  })

  $(document).on("mouseleave", ".gameDiv", function(e) {
      $(e.target).off("mouseenter");
      var buttontoshow = $(e.target).closest(".gameDiv").find(".qlButton");
      $(buttontoshow).removeClass("popupShow");
  })

  $(document).on("focus", ".gameDiv a.gameDivLink", function(e) {
      $(".qlButton").removeClass("popupShow");
      var buttontoshow = $(e.target).closest(".gameDiv").find(".qlButton");
      $(".popupShow").removeClass("popupShow");
      $(buttontoshow).addClass("popupShow");
  })

  $(document).on("click", ".disclosureClose", function() {
    $(this).closest(".c-flyout").prev("button").click();
  })
  $(document).on("click", "#disclosureContainer .glyph-prepend", function() {
    setTimeout(function() {
      if ($("#frDisclosure").css("display") !== 'none') {
        if ($(".CatAnnounce").text() === "l'info-bulle s'est ouverte") {
          $(".CatAnnounce").text("l'info-bulle s'est ouverte.")
        } else {
          $(".CatAnnounce").text("l'info-bulle s'est ouverte")
        }
      } else {  
        $(".CatAnnounce").text("l'info-bulle s'est fermée")
      }
      $(".disclosureClose")[0].focus()
    }, 30)
  })

  function makerand10() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 10; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }

  $(document).on("click", ".qlButton button", function(e) {
      e.preventDefault();
      var poptoopen = $(this).closest(".gameDiv").find(".gameMoreInfo");
      var starperc = $(poptoopen).find(".ratingstars").attr("data-starpercent") || "0";
      $(poptoopen).find(".c-rating[data-value].f-individual.filledstars div").css("width", starperc + "px");
      $(poptoopen).addClass("popupShow");

      $(poptoopen).find(".qclosebutton").focus();

      // populate rotator
      var thebigid = $(this).closest(".gameDiv").attr("data-bigid");
      if (allGames[thebigid]["physical"] === "true") {
          therotator = '<img class="physScreenshot" src="' + allGames[thebigid]["screenshot"] + '">';
      } else {
          var buttonhtml = '';
          var screenhtml = '';

          if (allGames[thebigid]["screenarray"].length > 0) {
              for (var s = 0; s < allGames[thebigid]["screenarray"].length; s++) {
                  if (s === 0) {
                      var humannum = s + 1;
                      buttonhtml += '<button role="tab" aria-selected="true" aria-label="View slide ' + humannum + '" aria-controls="' + allGames[thebigid]["titleclickname"] + s + '"></button>';
                      screenhtml += '<li id="' + allGames[thebigid]["titleclickname"] + s + '" class="f-active" role="tabpanel" data-f-theme="dark" >' +
                          '<section class="m-hero-item f-x-center f-y-center context-device theme-dark" itemscope itemtype="http://schema.org/Product">' +
                          '<picture class="c-image">' +
                          '<source srcset="' + allGames[thebigid]["screenarray"][s] + '" media="(min-width:0)">' +
                          '<img srcset="' + allGames[thebigid]["screenarray"][s] + '" src="' + allGames[thebigid]["screenarray"][s] + '" alt="' + allGames[thebigid]["title"] + '">' +
                          '</picture>' +
                          '</section>' +
                          '</li>';
                  } else {
                      var humannum = s + 1;
                      buttonhtml += '<button role="tab" aria-selected="false" aria-label="View slide ' + humannum + '" aria-controls="' + allGames[thebigid]["titleclickname"] + s + '"></button>';
                      screenhtml += '<li id="' + allGames[thebigid]["titleclickname"] + s + '" role="tabpanel" data-f-theme="dark" >' +
                          '<section class="m-hero-item f-x-center f-y-center context-device theme-dark" itemscope itemtype="http://schema.org/Product">' +
                          '<picture class="c-image">' +
                          '<source srcset="' + allGames[thebigid]["screenarray"][s] + '" media="(min-width:0)">' +
                          '<img srcset="' + allGames[thebigid]["screenarray"][s] + '" src="' + allGames[thebigid]["screenarray"][s] + '" alt="' + allGames[thebigid]["title"] + '">' +
                          '</picture>' +
                          '</section>' +
                          '</li>';
                  }
              }
          } else if (allGames[thebigid]["superheroart"]) { // Using keyart if there are no screenshots, fall back solution Finish this!!!!
              screenhtml += '<li id="' + allGames[thebigid]["titleclickname"] + s + '" role="tabpanel" data-f-theme="dark" >' +
                  '<section class="m-hero-item f-x-center f-y-center context-device theme-dark" itemscope itemtype="http://schema.org/Product">' +
                  '<picture class="c-image">' +
                  '<source srcset="' + allGames[thebigid]["superheroart"] + '" media="(min-width:0)">' +
                  '<img srcset="' + allGames[thebigid]["superheroart"] + '" src="' + allGames[thebigid]["superheroart"] + '" alt="' + boxshotlocstrings.locales[urlRegion]["keyPlaceholderboxshot"].replace("<PLACEHOLDER>", allGames[thebigid]["title"]) + '">' +
                  '</picture>' +
                  '</section>' +
                  '</li>';
          } else {
              console.log(allGames[thebigid]["superheroart"]);
          }

          if (fullcarouselimages.indexOf(thebigid) !== -1) {
              var fullimageclass = "";
          } else {
              var fullimageclass = "";
          }

          therotator = '<div class="c-carousel f-multi-slide f-auto-play' + fullimageclass + '" data-js-interval="6000">' +
              '<div class="c-group">' +
              '<div class="c-sequence-indicator" role="tablist">' +
              buttonhtml +
              '</div>' +
              '<button class="c-action-toggle c-glyph glyph-play f-toggle" data-toggled-label="Pause" data-toggled-glyph="glyph-pause" aria-label="Play"></button>' +
              '</div>' +
              '<button class="c-flipper f-previous" aria-hidden="true" tabindex="-1"></button>' +
              '<button class="c-flipper f-next" aria-hidden="true" tabindex="-1"></button>' +
              '<div itemscope itemtype="http://schema.org/ItemList">' +
              '<ul>' +
              screenhtml +
              '</ul>' +
              '</div>' +
              '</div>'
      }
  
      if ($(this).closest(".gameDiv").find(".poprotator .c-carousel").length === 0 && allGames[thebigid]["physical"] === "false") {
          $(this).closest(".gameDiv").find(".poprotator").prepend(therotator);
          mwf.ComponentFactory.create([
              { component: mwf.MultiSlideCarousel }
          ]);
      } else if ($(this).closest(".gameDiv").find(".poprotator img").length === 0 && allGames[thebigid]["physical"] === "true") {
          $(this).closest(".gameDiv").find(".poprotator").css("border-bottom", "1px grey solid").prepend(therotator);
      }
      // open popup dark background
      $("body").append('<div id="page-cover"></div>');
      $('body').addClass('stop-scrolling')

  })

  $(document).on("keypress", ".qlButton button", function(event) {
      if ((event.keyCode == 13) || (event.keyCode == 32)) {
          event.preventDefault();
          $(this).click();
      }
  })

  $(document).on("keypress", ".qlButtonFunc a", function(event) {
      if ((event.keyCode == 13) || (event.keyCode == 32)) {
          event.preventDefault();
          $(this).click();
      }
  })

  $(document).on("click", "#page-cover", function() {
      $(".gameMoreInfo.popupShow .qclosebutton").click();
      $("#page-cover").remove();
      $('body').removeClass('stop-scrolling')

  })

  $(document).on("click", ".qclosebutton", function(e) {
      e.preventDefault();
      $(".gameMoreInfo.popupShow").closest(".gameDiv").focus();
      $(".gameMoreInfo").removeClass("popupShow");
      $("#page-cover").remove();
      $('body').removeClass('stop-scrolling')

  })

  $(document).on("keypress", ".qclosebutton", function(event) {
      console.log(event.keyCode)
      if ((event.keyCode == 32) || (event.keyCode == 13)) {
          event.preventDefault();
          $(this).click();
      }
  })

  $(document).on("keydown", function(event) { // escape closes QL
    if (event.keyCode === 27 && $("#page-cover").length > 0) {
      $(".qclosebutton").click()
    }
  });

  $(document).on("click", '#bttbutton', function(e) {
    e.preventDefault();
    var btttop = $(".thecatalog").offset().top - 80;
    $("HTML, BODY").animate({
      scrollTop: btttop
    }, 500);
    setTimeout(function() {
      $(".thecatalog .gameDiv a").eq(0).focus();
    }, 600)
  });

  // locale specific
  var hideratingdropdown = "es-ar, es-co, es-cl";
  if (hideratingdropdown.indexOf(urlRegion) !== -1) {
      $("div#filter-ratings").hide();
  }

  // carousels
  function popCarousels() {
    consoleCarouselLists.forEach(function(list, ind) {

      if (ind === 2) {
        $(".featured-games:not(.specialFeatured)").eq(ind).addClass("leavingSoon")
      }

      // title and desc for cons and pc first
      const listTitle = siglTitles[list].title;
      const listDesc = siglTitles[list].desc;
      $(".featured-games:not(.specialFeatured)").eq(ind).find(".rotator-heading h2").text(listTitle);
      $(".featured-games:not(.specialFeatured)").eq(ind).find(".rotator-heading p").text(listDesc);
      $(".featured-games:not(.specialFeatured)").eq(ind).find(".gcConsole .carShopAll").attr("href", consoleCarouselLinks[ind]);

      const listGameIds = gameIdArrays[list].slice(0, 12);
      const listSize = listGameIds.length;
      $(".featured-games:not(.specialFeatured)").eq(ind).find(".spinnerHold").remove();
      listGameIds.forEach(function(game, gameind) {
        poplist(ind, ".gcConsole", game, false)
      })
      if (list.indexOf("leavingsoon") === -1) {
        poplist(ind, ".gcConsole", "", true)
      } else {
        console.log(listSize)
        if (listSize === 0) {
          $(".leavingSoon").hide()
        }
      }
    })

    pcCarouselLists.forEach(function(list, ind) {
      const listGameIds = gameIdArrays[list].slice(0, 12);
      const listSize = listGameIds.length;
      $(".featured-games:not(.specialFeatured)").eq(ind).find(".spinnerHold").remove();
      $(".featured-games:not(.specialFeatured)").eq(ind).find(".gcPc .carShopAll").attr("href", pcCarouselLinks[ind]);
      listGameIds.forEach(function(game, gameind) {
        poplist(ind, ".gcPc", game, false)
      })
      if (list.indexOf("leavingsoon") === -1) {
        poplist(ind, ".gcPc", "", true)
      }
      // enable pc lists
      if (list === pcCarouselLists[pcCarouselLists.length - 1]) {
        setTimeout(function() {
          $(".gcPc").addClass("hidden").removeClass("pcLoading")
          $(".carShopAll").removeClass("hidden")
        }, 500)
      }
    })

      function poplist(listInd, platClass, thebigid, final) {
        let altTag, gameurl, aria, box, title = "";
        if (final === false) {
          altTag = boxshotlocstrings.locales[urlRegion].keyPlaceholderboxshot;
          altTag = altTag.replace("PLACEHOLDER", allGames[thebigid].title);
          gameurl = allGames[thebigid].gameurl;
          aria = 'data-retailer="ms store" ';
          box = allGames[thebigid].boxshot;
          title = allGames[thebigid].title;
          targ = " target='_blank' ";
          exploreClass = "";
        } else {
          altTag = regionContent["keyXgplogoalt"];
          gameurl = $(".featured-games:not(.specialFeatured)").eq(listInd).find(platClass + " .carShopAll").attr("href");
          aria = 'aria-label="' + 
                  $(".featured-games:not(.specialFeatured)").eq(listInd).find(platClass + " .carShopAll").attr("href") + '"';
          box = "https://assets.xboxservices.com/assets/dd/a1/dda1aa1d-99f2-470b-9773-710eabf849e0.jpg?n=Game-Pass-Deals_Boxshot-0_XGP-Logo_720x1080.jpg";
          title = regionContent["keyExploremore"];
          targ = " ";
          exploreClass = " expLink";
        }

        $(".featured-games:not(.specialFeatured)").eq(listInd).find(platClass + " ul").append('<li>' +
          '<section class="m-product-placement-item f-size-large context-game gameDiv" itemscope="" itemtype="http://schema.org/Product">' +
            '<a class="gameDivLink' + exploreClass + '" href="' + gameurl + '" ' + targ + aria + '>' +
              '<picture class="containerIMG">' +
                '<img class="c-image" aria-hidden="true" alt="' + altTag + '" srcset="' + box + 
                '" src="' + box + '">' +
              '</picture>' +
              '<div>' +
                '<h3 class="c-heading" itemprop="product name">' + title + '</h3>' +
              '</div>' +
            '</a>' +
          '</section></li>')
      }

      $(document).on("click", ".carselectbutton", function(e) {
        e.preventDefault();
        if (!$(this).hasClass("carselected")) {
          // mwfAutoInit.ComponentFactory.create([{
          //   component: mwfAutoInit.SingleSlideCarousel,
          //   selector: ".c-carousel[class*=f-single-slide]",

          // }]);
          $(this).closest(".featured-games").find(".carselected").removeClass("carselected");
          $(this).addClass("carselected");
          $(this).closest(".featured-games").find(".gamesCarousel").removeClass("hidden");
          $(this).closest(".featured-games").find("." + $(this).attr("data-carhide")).addClass("hidden");
          const plat = $(this).find("span").text();
          if ($(".CatAnnounce").text().indexOf(".") === -1) {
            $(".CatAnnounce").text(regionContent["keyPlatformlist"].replace("<PLACEHOLDER>", plat) + ".")
          } else {
            $(".CatAnnounce").text(regionContent["keyPlatformlist"].replace("<PLACEHOLDER>", plat));
          }
        }
      })
  }
  // end rotator

  function mobileZoom() {
    zoomlevel = ((window.outerWidth - 10) / window.innerWidth) * 100;
    var newWidth = $(document).width();
    if (newWidth < 768 && zoomlevel > 109) {
      console.log("zoom add")
      setTimeout(function() {
        $(".gameDivsWrapper").addClass("mobileZoomed")
      }, 500)
    } else {
      console.log("zoom remove")
      setTimeout(function() {
        $(".gameDivsWrapper").removeClass("mobileZoomed")
      }, 500)
    }
  }

  if ($("label.c-label[role='radio']").length > 0) { // a11y fix for non en-us
    let labelCount = 0;
    var labelFix = setInterval(function() {
        labelCount++;
        if ($("label.c-label[role='radio']").length > 0 || labelCount === 9) {
          $("label.c-label[role='radio']").removeAttr("role");
          clearInterval(labelFix);
        }
    }, 500);
  }

});



ratingDescriptors = {
  "ESRB:FanVio": "Fantasy Violence",
  "ESRB:MilBlo": "Mild Blood",
  "ESRB:MilLyr": "Mild Lyrics",
  "ESRB:BloGor": "Blood and Gore",
  "ESRB:IntVio": "Intense Violence",
  "ESRB:StrLan": "Strong Language",
  "ESRB:ParNud": "Partial Nudity",
  "ESRB:UseDru": "Use of Drugs",
  "ESRB:SexCon": "Sexual Content",
  "ESRB:AlcRef": "Alcohol Reference",
  "ESRB:Blo": "Blood",
  "ESRB:Vio": "Violence",
  "ESRB:MilSugThe": "Suggestive Themes",
  "ESRB:MilLan": "Mild Language",
  "ESRB:MatHum": "Mature Humor",
  "ESRB:Nud": "Nudity",
  "ESRB:UseOfAlcAndTob": "Use of Alcohol and Tobacco",
  "ESRB:CarVio": "Cartoon Violence",
  "ESRB:SexThe": "Sexual Themes",
  "ESRB:DruRef": "Drug Reference",
  "ESRB:MilFanVio": "Mild Fantasy Violence",
  "ESRB:Lan": "Language",
  "ESRB:StrSexCon": "Strong Sexual Content",
  "ESRB:UseAlc": "Use of Alcohol",
  "ESRB:CruHum": "Crude Humor",
  "ESRB:MilVio": "Mild Violence",
  "ESRB:SugThe": "Suggestive Themes",
  "ESRB:AniBlo": "Animated Blood",
  "ESRB:UseTob": "Use of Tobacco"
}

ratingImages = {
  "ESRB:M": "https://assets.xboxservices.com/assets/55/aa/55aac49b-ca77-44f2-a66c-ce14c5a0e514.svg?n=ESRB-Mature_500x500.svg",
  "ESRB:T": "https://assets.xboxservices.com/assets/24/04/2404acb7-758f-4914-89ac-950730f24ca6.svg?n=ESRB-T_500x500.svg",
  "ESRB:E": "https://assets.xboxservices.com/assets/c9/69/c9693eb3-485e-4b6f-b231-0673a15cdefd.svg?n=ESRB-E_500x500.svg",
  "ESRB:E10": "https://assets.xboxservices.com/assets/77/04/7704472b-0434-42bf-abc0-4ebad0460e56.svg?n=ESRB-E-10%252b_500x500.svg",
  "ESRB:RPTeen": "https://assets.xboxservices.com/assets/be/cb/becb1436-d9f4-4824-857d-de7934386c69.svg?n=ESRB-Rating-Pending_500x500.svg",
  "ESRB:RPEveryone": "https://assets.xboxservices.com/assets/be/cb/becb1436-d9f4-4824-857d-de7934386c69.svg?n=ESRB-Rating-Pending_500x500.svg"
}

quickLookLocStrings = {
"locales": {
  "keys": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimized for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "Cloud"
  },
  "en-us": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimized for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "ar-ae": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "ar-sa": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "cs-cz": {
    "keyAddtowishlist": "Přidat do seznamu přání",
    "keyOptimizedforxboxseriesxs": "Optimalizováno pro Xbox Series X|S",
    "keySmartdelivery": "Inteligentní doručení",
    "keyCloudenabled": "Cloudové",
    "keyPc": "PC",
    "keyMobile": "Mobilní zařízení",
    "keyGetitnow": "POŘIĎTE SI JI JEŠTĚ DNES",
    "keyPreordernow": "PŘEDOBJEDNAT",
    "keyScreenshot": "snímek obrazovky",
    "keyCloud": "CLOUD"
  },
  "da-dk": {
    "keyAddtowishlist": "Føj til ønskeliste",
    "keyOptimizedforxboxseriesxs": "Optimeret til Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloudaktiveret",
    "keyPc": "Pc",
    "keyMobile": "Mobil",
    "keyGetitnow": "FÅ DET NU",
    "keyPreordernow": "FORUDBESTIL NU",
    "keyScreenshot": "skærmbillede",
    "keyCloud": "CLOUD"
  },
  "de-at": {
    "keyAddtowishlist": "Zur Wunschliste hinzufügen",
    "keyOptimizedforxboxseriesxs": "Optimiert für Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloudfähig",
    "keyPc": "PC",
    "keyMobile": "Handy",
    "keyGetitnow": "JETZT KAUFEN",
    "keyPreordernow": "JETZT VORBESTELLEN",
    "keyScreenshot": "Screenshot",
    "keyCloud": "CLOUD"
  },
  "de-ch": {
    "keyAddtowishlist": "Zur Wunschliste hinzufügen",
    "keyOptimizedforxboxseriesxs": "Optimiert für Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloudfähig",
    "keyPc": "PC",
    "keyMobile": "Handy",
    "keyGetitnow": "JETZT KAUFEN",
    "keyPreordernow": "JETZT VORBESTELLEN",
    "keyScreenshot": "Screenshot",
    "keyCloud": "CLOUD"
  },
  "de-de": {
    "keyAddtowishlist": "Zur Wunschliste hinzufügen",
    "keyOptimizedforxboxseriesxs": "Optimiert für Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloudfähig",
    "keyPc": "PC",
    "keyMobile": "Handy",
    "keyGetitnow": "JETZT KAUFEN",
    "keyPreordernow": "JETZT VORBESTELLEN",
    "keyScreenshot": "Screenshot",
    "keyCloud": "CLOUD"
  },
  "el-gr": {
    "keyAddtowishlist": "Προσθήκη στη λίστα επιθυμιών",
    "keyOptimizedforxboxseriesxs": "Βελτιστοποιημένο για Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Με δυνατότητα cloud",
    "keyPc": "PC",
    "keyMobile": "Κινητό",
    "keyGetitnow": "ΑΠΟΚΤΗΣΤΕ ΤΟ ΤΩΡΑ",
    "keyPreordernow": "ΠΡΟ-ΠΑΡΑΓΓΕΛΙΑ ΤΩΡΑ",
    "keyScreenshot": "στιγμιότυπο",
    "keyCloud": "CLOUD"
  },
  "en-au": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "en-ca": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimized for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "en-gb": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "en-hk": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "en-ie": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "en-in": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "en-nz": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "en-sg": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "en-za": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "es-ar": {
    "keyAddtowishlist": "Añadir a la lista de deseos",
    "keyOptimizedforxboxseriesxs": "Optimizado para Xbox Series X|S",
    "keySmartdelivery": "Entrega inteligente",
    "keyCloudenabled": "Habilitados para la nube",
    "keyPc": "PC",
    "keyMobile": "Dispositivos móviles",
    "keyGetitnow": "CONSÍGUELO AHORA",
    "keyPreordernow": "RESERVA AHORA",
    "keyScreenshot": "captura de pantalla",
    "keyCloud": "NUBE"
  },
  "es-cl": {
    "keyAddtowishlist": "Añadir a la lista de deseos",
    "keyOptimizedforxboxseriesxs": "Optimizado para Xbox Series X|S",
    "keySmartdelivery": "Entrega inteligente",
    "keyCloudenabled": "Habilitados para la nube",
    "keyPc": "PC",
    "keyMobile": "Dispositivos móviles",
    "keyGetitnow": "CONSÍGUELO AHORA",
    "keyPreordernow": "RESERVA AHORA",
    "keyScreenshot": "captura de pantalla",
    "keyCloud": "NUBE"
  },
  "es-co": {
    "keyAddtowishlist": "Añadir a la lista de deseos",
    "keyOptimizedforxboxseriesxs": "Optimizado para Xbox Series X|S",
    "keySmartdelivery": "Entrega inteligente",
    "keyCloudenabled": "Habilitados para la nube",
    "keyPc": "PC",
    "keyMobile": "Dispositivos móviles",
    "keyGetitnow": "CONSÍGUELO AHORA",
    "keyPreordernow": "RESERVA AHORA",
    "keyScreenshot": "captura de pantalla",
    "keyCloud": "NUBE"
  },
  "es-es": {
    "keyAddtowishlist": "Añadir a la lista de deseos",
    "keyOptimizedforxboxseriesxs": "Optimizado para Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Habilitados para la nube",
    "keyPc": "PC",
    "keyMobile": "Dispositivos móviles",
    "keyGetitnow": "CONSÍGUELO HOY",
    "keyPreordernow": "RESERVAR AHORA",
    "keyScreenshot": "captura de pantalla",
    "keyCloud": "NUBE"
  },
  "es-mx": {
    "keyAddtowishlist": "Añadir a la lista de deseos",
    "keyOptimizedforxboxseriesxs": "Optimizado para Xbox Series X|S",
    "keySmartdelivery": "Entrega inteligente",
    "keyCloudenabled": "Habilitados para la nube",
    "keyPc": "PC",
    "keyMobile": "Dispositivos móviles",
    "keyGetitnow": "CONSÍGUELO AHORA",
    "keyPreordernow": "RESERVA AHORA",
    "keyScreenshot": "captura de pantalla",
    "keyCloud": "NUBE"
  },
  "fi-fi": {
    "keyAddtowishlist": "Lisää toivomusluetteloon",
    "keyOptimizedforxboxseriesxs": "Optimoitu Xbox Series X|S:lle",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Pilvipohjainen",
    "keyPc": "PC:LLE",
    "keyMobile": "Mobiili",
    "keyGetitnow": "HANKI SE NYT",
    "keyPreordernow": "TILAA ENNAKKOON NYT",
    "keyScreenshot": "näyttökuva",
    "keyCloud": "PILVI"
  },
  "fr-be": {
    "keyAddtowishlist": "Ajouter à la liste de souhaits",
    "keyOptimizedforxboxseriesxs": "Optimisé pour Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Compatible avec le cloud",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "ACHETEZ-LE DÈS MAINTENANT",
    "keyPreordernow": "PRÉCOMMANDER MAINTENANT",
    "keyScreenshot": "capture d’écran",
    "keyCloud": "CLOUD"
  },
  "fr-ca": {
    "keyAddtowishlist": "Ajouter à la liste de souhaits",
    "keyOptimizedforxboxseriesxs": "Optimisé pour la Xbox Series X|S",
    "keySmartdelivery": "Livraison intelligente",
    "keyCloudenabled": "Compatible avec le jeu en nuage",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "OBTENEZ-LE MAINTENANT",
    "keyPreordernow": "PRÉCOMMANDER MAINTENANT",
    "keyScreenshot": "capture d’écran",
    "keyCloud": "NUAGE"
  },
  "fr-ch": {
    "keyAddtowishlist": "Ajouter à la liste de souhaits",
    "keyOptimizedforxboxseriesxs": "Optimisé pour Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Compatible avec le cloud",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "ACHETEZ-LE DÈS MAINTENANT",
    "keyPreordernow": "PRÉCOMMANDER MAINTENANT",
    "keyScreenshot": "capture d’écran",
    "keyCloud": "CLOUD"
  },
  "fr-fr": {
    "keyAddtowishlist": "Ajouter à la liste de souhaits",
    "keyOptimizedforxboxseriesxs": "Optimisé pour Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Compatible avec le cloud",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "ACHETEZ-LE DÈS MAINTENANT",
    "keyPreordernow": "PRÉCOMMANDER MAINTENANT",
    "keyScreenshot": "capture d’écran",
    "keyCloud": "CLOUD"
  },
  "he-il": {
    "keyAddtowishlist": "Add to wish list",
    "keyOptimizedforxboxseriesxs": "Optimised for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-enabled",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "GET IT NOW",
    "keyPreordernow": "PRE-ORDER NOW",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "hu-hu": {
    "keyAddtowishlist": "Hozzáadás a kívánságlistához",
    "keyOptimizedforxboxseriesxs": "Xbox Series X|S konzolra optimalizálva",
    "keySmartdelivery": "Intelligens játékletöltés",
    "keyCloudenabled": "Felhőkompatibilis",
    "keyPc": "PC",
    "keyMobile": "Mobil",
    "keyGetitnow": "SZEREZD BE MÉG MA!",
    "keyPreordernow": "RENDELD ELŐ MOST!",
    "keyScreenshot": "képernyőfelvétel",
    "keyCloud": "FELHŐ"
  },
  "it-it": {
    "keyAddtowishlist": "Aggiungi all'elenco preferenze",
    "keyOptimizedforxboxseriesxs": "Ottimizzato per Xbox Series X|S",
    "keySmartdelivery": "Consegna intelligente",
    "keyCloudenabled": "Utilizzabili via cloud",
    "keyPc": "PC",
    "keyMobile": "Dispositivi mobili",
    "keyGetitnow": "ACQUISTA ORA",
    "keyPreordernow": "PREORDINA ORA",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "ja-jp": {
    "keyAddtowishlist": "欲しい物リストに追加",
    "keyOptimizedforxboxseriesxs": "Optimized for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "クラウド対応",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "今すぐ購入",
    "keyPreordernow": "今すぐ予約する",
    "keyScreenshot": "スクリーンショット",
    "keyCloud": "クラウド"
  },
  "ko-kr": {
    "keyAddtowishlist": "위시 리스트에 추가",
    "keyOptimizedforxboxseriesxs": "Xbox Series X|S 최적화",
    "keySmartdelivery": "스마트 딜리버리",
    "keyCloudenabled": "클라우드 활성화",
    "keyPc": "PC",
    "keyMobile": "모바일",
    "keyGetitnow": "지금 구매하세요",
    "keyPreordernow": "지금 예약 주문하기",
    "keyScreenshot": "스크린샷",
    "keyCloud": "클라우드"
  },
  "nb-no": {
    "keyAddtowishlist": "Legg til ønskeliste",
    "keyOptimizedforxboxseriesxs": "Optimalisert for Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Sky-aktivert",
    "keyPc": "PC",
    "keyMobile": "Mobil",
    "keyGetitnow": "SKAFF DEG DET NÅ",
    "keyPreordernow": "FORHÅNDSBESTILL NÅ",
    "keyScreenshot": "skjermbilde",
    "keyCloud": "SKY"
  },
  "nl-be": {
    "keyAddtowishlist": "Toevoegen aan verlanglijstje",
    "keyOptimizedforxboxseriesxs": "Geoptimaliseerd voor Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-geschikt",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "KOOP NU",
    "keyPreordernow": "PRE-ORDER NU",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "nl-nl": {
    "keyAddtowishlist": "Toevoegen aan verlanglijstje",
    "keyOptimizedforxboxseriesxs": "Geoptimaliseerd voor Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Cloud-geschikt",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "KOOP NU",
    "keyPreordernow": "PRE-ORDER NU",
    "keyScreenshot": "screenshot",
    "keyCloud": "CLOUD"
  },
  "pl-pl": {
    "keyAddtowishlist": "Dodaj do listy życzeń",
    "keyOptimizedforxboxseriesxs": "Zoptymalizowane dla Xbox Series X|S",
    "keySmartdelivery": "Inteligentne pobieranie",
    "keyCloudenabled": "Z możliwością grania w chmurze",
    "keyPc": "KOMPUTER",
    "keyMobile": "Telefon komórkowy",
    "keyGetitnow": "KUP JUŻ TERAZ",
    "keyPreordernow": "ZAMÓW W PRZEDSPRZEDAŻY",
    "keyScreenshot": "zdjęcie z gry",
    "keyCloud": "CHMURA"
  },
  "pt-br": {
    "keyAddtowishlist": "Adicionar à lista de desejos",
    "keyOptimizedforxboxseriesxs": "Otimizado para Xbox Series X|S",
    "keySmartdelivery": "Entrega Inteligente",
    "keyCloudenabled": "Pronto para a nuvem",
    "keyPc": "PC",
    "keyMobile": "Dispositivos móveis",
    "keyGetitnow": "ADQUIRA AGORA",
    "keyPreordernow": "RESERVE AGORA",
    "keyScreenshot": "captura de tela",
    "keyCloud": "NUVEM"
  },
  "pt-pt": {
    "keyAddtowishlist": "Adicionar à lista de desejos",
    "keyOptimizedforxboxseriesxs": "Otimizado para a Xbox Series X|S",
    "keySmartdelivery": "Entrega Inteligente",
    "keyCloudenabled": "Preparado para a cloud",
    "keyPc": "PC",
    "keyMobile": "Dispositivos Móveis",
    "keyGetitnow": "OBTER AGORA",
    "keyPreordernow": "PRÉ-ENCOMENDAR AGORA",
    "keyScreenshot": "captura de ecrã",
    "keyCloud": "CLOUD"
  },
  "ru-ru": {
    "keyAddtowishlist": "Добавить в список желаний",
    "keyOptimizedforxboxseriesxs": "Оптимизировано для Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Поддержка облачного сервиса",
    "keyPc": "ПК",
    "keyMobile": "Мобильное устройство",
    "keyGetitnow": "ПОЛУЧИТЬ СЕЙЧАС",
    "keyPreordernow": "ОФОРМИТЬ ПРЕДЗАКАЗ",
    "keyScreenshot": "снимок экрана",
    "keyCloud": "ОБЛАКО"
  },
  "sk-sk": {
    "keyAddtowishlist": "Pridať do zoznamu prianí",
    "keyOptimizedforxboxseriesxs": "Optimalizované pre Xbox Series X|S",
    "keySmartdelivery": "Inteligentné doručenie",
    "keyCloudenabled": "Cloudové hranie",
    "keyPc": "PC",
    "keyMobile": "Mobilné zariadenie",
    "keyGetitnow": "ZÍSKAJTE JU EŠTE DNES",
    "keyPreordernow": "PREDOBJEDNAŤ",
    "keyScreenshot": "snímka obrazovky",
    "keyCloud": "CLOUD"
  },
  "sv-se": {
    "keyAddtowishlist": "Lägg till i önskelista",
    "keyOptimizedforxboxseriesxs": "Optimerad för Xbox Series X|S",
    "keySmartdelivery": "Smart Delivery",
    "keyCloudenabled": "Molnaktiverat",
    "keyPc": "PC",
    "keyMobile": "Mobil",
    "keyGetitnow": "SKAFFA DET I DAG",
    "keyPreordernow": "FÖRBESTÄLL NU",
    "keyScreenshot": "skärmbild",
    "keyCloud": "MOLN"
  },
  "tr-tr": {
    "keyAddtowishlist": "İstek listenize ekleyin",
    "keyOptimizedforxboxseriesxs": "Xbox Series X|S için Optimize Edildi",
    "keySmartdelivery": "Akıllı Teslimat",
    "keyCloudenabled": "Bulut özellikli",
    "keyPc": "BİLGİSAYAR",
    "keyMobile": "Mobil",
    "keyGetitnow": "ŞİMDİ EDİNİN",
    "keyPreordernow": "ŞİMDİ ÖN SİPARİŞ VERİN",
    "keyScreenshot": "ekran görüntüsü",
    "keyCloud": "BULUT"
  },
  "zh-hk": {
    "keyAddtowishlist": "新增至願望清單",
    "keyOptimizedforxboxseriesxs": "Xbox Series X|S 性能最佳化",
    "keySmartdelivery": "智慧分發",
    "keyCloudenabled": "具有雲端功能",
    "keyPc": "電腦",
    "keyMobile": "行動裝置",
    "keyGetitnow": "立即購買",
    "keyPreordernow": "立即預購",
    "keyScreenshot": "畫面截圖",
    "keyCloud": "雲端"
  },
  "zh-tw": {
    "keyAddtowishlist": "加入願望清單",
    "keyOptimizedforxboxseriesxs": "Xbox Series X|S 性能強化",
    "keySmartdelivery": "智慧分發",
    "keyCloudenabled": "具有雲端功能",
    "keyPc": "PC",
    "keyMobile": "Mobile",
    "keyGetitnow": "馬上購買",
    "keyPreordernow": "立即預購",
    "keyScreenshot": "螢幕擷取畫面",
    "keyCloud": "雲端"
  }
}
}

boxshotlocstrings = {
  "locales": {
      "en-us": {
          "keyPlaceholderboxshot": "box shot of <PLACEHOLDER>"
      },
      "en-ca": {
          "keyPlaceholderboxshot": "box shot of <PLACEHOLDER>"
      },
      "de-at": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> – Verpackung"
      },
      "tr-tr": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> kutu resmi"
      },
      "en-nz": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "de-de": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> – Verpackung"
      },
      "el-gr": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "nl-nl": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> - boxshot"
      },
      "en-za": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "en-sg": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "en-gb": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "es-ar": {
          "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
      },
      "es-mx": {
          "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
      },
      "en-au": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "nb-no": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> coverbilde"
      },
      "ar-ae": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "ar-sa": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "de-ch": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> – Verpackung"
      },
      "ja-jp": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> パッケージショット"
      },
      "ko-kr": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> 박스샷"
      },
      "fr-ca": {
          "keyPlaceholderboxshot": "Image de la boîte de <PLACEHOLDER>"
      },
      "he-il": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "fi-fi": {
          "keyPlaceholderboxshot": "Pakkauksen kansi: <PLACEHOLDER>"
      },
      "pt-br": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> imagem da caixa"
      },
      "zh-hk": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> 包裝圖"
      },
      "zh-tw": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> 包裝圖"
      },
      "ru-ru": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> — обложка"
      },
      "da-dk": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> billede af æsken"
      },
      "cs-cz": {
          "keyPlaceholderboxshot": "Obrázek krabice <PLACEHOLDER>"
      },
      "es-cl": {
          "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
      },
      "zh-cn": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> 包装盒"
      },
      "sv-se": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> bild på förpackning"
      },
      "en-ie": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "it-it": {
          "keyPlaceholderboxshot": "Immagine della confezione di <PLACEHOLDER>"
      },
      "es-es": {
          "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
      },
      "fr-fr": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> image de la boîte"
      },
      "fr-be": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> image de la boîte"
      },
      "es-co": {
          "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
      },
      "en-hk": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "fr-ch": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> image de la boîte"
      },
      "pl-pl": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> – zdjęcie opakowania"
      },
      "hu-hu": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> dobozának képe"
      },
      "en-in": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
      },
      "nl-be": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> - boxshot"
      },
      "pt-pt": {
          "keyPlaceholderboxshot": "Imagem da caixa de <PLACEHOLDER>"
      },
      "sk-sk": {
          "keyPlaceholderboxshot": "<PLACEHOLDER> – obrázok balenia"
      }
  }
}

titleStrings = {};