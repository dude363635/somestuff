$(document).ready(function() {
  if ($(".CatAnnounce").length === 0) {
    $("body").append('<div style="width:0;height:0;font-size:0;" class="CatAnnounce" aria-live="assertive"></div>');
  }
  const nonStore = "ar-ae, ar-sa, el-gr, en-hk, en-in, en-za, es-ar, es-cl, es-co, es-mx, he-il, hu-hu, ko-kr, pt-br, sk-sk, ru-ru, tr-tr, zh-hk, zh-tw";
  
  function hashChanged() {
      location.reload();
  }
  window.addEventListener('hashchange', hashChanged, false);

  //move sort to be hidden at mobile
  // $(".radioDrawer").prependTo(".refineFilters.mobileHidden");
  // $(".mobFilterButton").appendTo(".searchgroup");

  $("#featureFilter li").each(function() {
    if ($(this).find("a.c-refine-item span").text().length > 50) {
      $(this).find(".tooltipContainer").addClass("iPlacement");
    }
  })

  // Cloud and tv gaming image fixes
  $(".informTout[data-inform='workson-tv'] picture source").first().attr("srcset", "https://assets.xboxservices.com/assets/c3/2b/c32b1c13-a40b-4f52-9033-85345e03120c.jpg?n=Accessories-Hub_Info-Tout-768_Smart-TV_1200x300_02.jpg");
  $(".informTout[data-inform='workson-cloud'] picture source").first().attr("srcset", "https://assets.xboxservices.com/assets/33/7d/337d5b87-1e7e-49d2-a672-b18d18a06cb1.jpg?n=Accessories-Hub_Info-Tout-768_Cloud_1200x300_02.jpg");

  // tooltip handling
  $(document).on("click", ".tooltipClose", function() {
    $(this).closest(".c-flyout").prev("button").click();
  })
  $(document).on("click", ".tooltipContainer .glyph-prepend", function(e) {
    setTimeout(function() {
      console.log(e)
      console.log($(e.target).closest(".tooltipContainer").find(".ttFlyout").css("display"))
      if ($(e.target).closest(".tooltipContainer").find(".ttFlyout").css("display") !== 'none') {
        if ($(".CatAnnounce").text().indexOf(".") === -1) {
          $(".CatAnnounce").text($("#ttopen").text() + ".")
        } else {
          $(".CatAnnounce").text($("#ttopen").text())
        }
      } else {  
        $(".CatAnnounce").text($("#ttclosed").text())
      }
      $(e.target).closest(".tooltipContainer").find(".ttFlyout").find(".tooltipClose")[0].focus()
    }, 30)
  })

  //accessibility
  $(".c-drawer.f-checkbox a").attr("role", "checkbox");

  // fix image not clicking
  $(document).on("click", ".m-content-placement-item img", function(e) {
    // e.preventDefault();
    console.log($(this).closest(".m-content-placement-item").find("h3 a").length)
    $(this).closest(".m-content-placement-item").find("h3 a").click();
  });

  let bigTouts = {1:"", 2:"", 3:"",4:"",5:""};
  const toutOrder = {"a":1,"b":2,"c":3,"d":4,"e":5};

  function totop() {
    var acctop = $(".thecatalog").offset().top;
    $("HTML, BODY").animate({
      scrollTop: acctop
    }, 300);
  }
  $(document).on("click", ".openFilters", function() {
    $(".sortUi").addClass("mobileHidden");
    $(".searchgroup").addClass("mobileHidden");
    $(".refineFilters").removeClass("mobileHidden");
    // $(".filterSummary").removeClass("mobileHidden");
    $("body").addClass("mobileOpen");
    $(".thecatalog").addClass("mobileOpen");
    $(".closeShowResults").addClass("mobileOpen");
  })
  $(document).on("click", ".closeFilters, .showResults", function() {
    $(".sortUi").removeClass("mobileHidden");
    $(".searchgroup").removeClass("mobileHidden");
    $(".refineFilters").addClass("mobileHidden");
    // $(".filterSummary").addClass("mobileHidden");
    $("body").removeClass("mobileOpen");
    $(".thecatalog").removeClass("mobileOpen");
    $(".closeShowResults").removeClass("mobileOpen");
    $(".openFilters")[0].focus();
    totop();
  })
  
  var ItemPopulate = (function() { 
      var urlRegion = document.URL.split("/")[3].toLowerCase();
      if (urlRegion === "en-ae") {
          urlRegion = "ar-ae";
      } else if (urlRegion === "en-sa") {
          urlRegion = "ar-sa";
      } else if (urlRegion === "en-il") {
          urlRegion = "he-il";
      }
      if (nonStore.indexOf(urlRegion) !== -1) {
        $("#priceFilter").closest(".c-drawer").remove();
        // $("body").append('<style>.pricingInfo, span.priceText {display: none !important;}</style>');
      }
      var countryCode = urlRegion.split("-")[1].toUpperCase();
      var regionItems = allAccessories1.locales[urlRegion]
      var numItems = regionItems.length;
      var currencyFormat = priceFormat.locales[urlRegion];
      var bigIdStringList = "";
      var catflag = 0;
  
      regionItems.forEach(function(product) { // display catalog can accept SIDs in the query string
          let preorderId = "";
          if (product.poPid.length > 11) { preorderId = product.poPid + "," }
  
          let gaId = "";
          if (product.gaPid.length > 11) { gaId = product.gaPid + "," }
  
          let specId = "";
          if (product.specPid.length > 11) { specId = product.specPid + "," }
  
          bigIdStringList = bigIdStringList + preorderId + gaId + specId;
      });
  
      bigIdStringList = setCharAt(bigIdStringList, bigIdStringList.length - 1, ""); // Remove the , at the end of the string
  
      var apiUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=' + bigIdStringList + '&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';
  
      // hero title
      var regTitles = accHeadlines.locales[urlRegion]
      $(".accHeroTitle").text(regTitles["keyAccessories"])
  
      regionItems = regionItems.sort(function(a, b) {
        if (allAccessories2.ids[a.sheetId] !== undefined && allAccessories2.ids[b.sheetId] !== undefined) {
          if ((allAccessories2.ids[a.sheetId].pagePosition !== allAccessories2.ids[b.sheetId].pagePosition) &&
             allAccessories2.ids[a.sheetId].pagePosition !== "1000000" && 
             allAccessories2.ids[b.sheetId].pagePosition !== "1000000") {
            return parseInt(allAccessories2.ids[a.sheetId].pagePosition) - parseInt(allAccessories2.ids[b.sheetId].pagePosition)
          }
          const date1 = new Date(a.releaseDate);
          const date2 = new Date(b.releaseDate);
          if (date1 !== date2) {
            return date2 - date1
          }
        }
      });
  
      if (bigIdStringList !== "") {
          $.get(apiUrl)
              .done(function(responseData) {
                  if (responseData.Products.length === 0) {
                      populateAccessoriesHub(numItems, false)
                  } else {
                      apiItemList = [];
                      responseData.Products.forEach(function(product) {
                          product.DisplaySkuAvailabilities.forEach(function(skuAvailability) {
                              var apiItem = new Object();
                              apiItem.productId = product.ProductId;
                              apiItem.MSRP = skuAvailability.Availabilities[0].OrderManagementData.Price.MSRP;
                              apiItem.listPrice = skuAvailability.Availabilities[0].OrderManagementData.Price.ListPrice;
                              apiItem.skuId = skuAvailability.Availabilities[0].SkuId;
                              apiItem.invId = skuAvailability.Sku.Properties.InventoryControlSkuId;
                              apiItem.purchaseAction = false;
                              if (skuAvailability.Availabilities[0].Actions.includes("Purchase")) {
                                  apiItem.purchaseAction = true;
                              }
                              apiItemList.push(apiItem);
                          });
                      });
                      apiItemList.forEach(function(item, index) {
                          (function() {
                          let invUrl = "https://inv.mp.microsoft.com/v2.0/inventory/" +urlRegion.split("-")[1] +
                                          "/" + item.productId + "/" + item.skuId + "/" + item.invId;
                          $.get(invUrl)
                              .done(function(stockData) {
                              item.inStock = "false";
                              var shipTimes = Object.keys(stockData.futureLots);
                              var futureInstock = "";
                              if (shipTimes.length > 0) {
                                  $.each(shipTimes, function() { // Cycles through all future lots to see if in stock.
                                      futureInstock = stockData.futureLots[this]["9000000013"].inStock;
                                      if (futureInstock.toLowerCase() === "true") {
                                          item.inStock = "true";
                                          false; // This breaks out of the foreach loop
                                      }
                                  });
                              }
                              var instock = stockData.availableLots["0001-01-01T00:00:00.0000000Z"]["9000000013"].inStock;
                              if (futureInstock.toString().toLowerCase() === "true") {
                                  item.inStock = "true";
                              }
                              if (instock.toLowerCase() === "true") {
                                  item.inStock = "true";
                              }
                          })
                          .fail(function() {
                              item.inStock = "nodata";
                          })
                          .always(function() {
                              if (index === apiItemList.length - 1) {
                              populateAccessoriesHub(numItems, true, apiItemList);
                              }
                          })
                          })(item);
                      })
                  }
              })
              .fail(function() {
                  populateAccessoriesHub(numItems, false);
              })
      } else { populateAccessoriesHub(numItems, false); }
  
      function populateAccessoriesHub(numItems, useMS_store, apiItemList) {
          for (var i = 0; i < numItems; i++) {
              let sheet2data = allAccessories2.ids[regionItems[i].sheetId]
              if (sheet2data === undefined) {
                sheet2data = {
                  android: "f", category: "", cloud: "f", colors: "", features: "", iPhone: "f", 
                  pagePosition: "1000000", pc: "f", seriesXS: "f", tv: "f", xboxOne: "f", msft: "f"
                }
                console.warn("NO SHEET 2 DATA FOUND FOR SHEETID: " + regionItems[i].sheetId + ". Proceeding with inaccurate sheet 2 data for that product. It will not appear on the page.");
              }

              var useAPIPrice = true; // Using a '!' character at the beginning of the priceText in the allConsoles.js price to override the API price.
              if (regionItems[i].priceText.charAt(0) === "!") {
                  useAPIPrice = false;
                  regionItems[i].priceText = regionItems[i].priceText.replace("!", "");
                  regionItems[i].tprPriceText = regionItems[i].tprPriceText.replace("!", "");
              }
              regionItems[i].idUsing = "";
  
              if (useAPIPrice && useMS_store) {
                  var currentPID = "";
                  var currentSID = "";
                  apiItemList.forEach(function(item) { // order of importance: spec > ga > po
                      if (regionItems[i].specPid.length > 11) {
                          let apiItem = apiItemList.find(obj => {
                          return obj.productId === regionItems[i].specPid.split("/")[0].toUpperCase() && obj.skuId === regionItems[i].specPid.split("/")[1].toUpperCase()
                          })
                          if (apiItem !== undefined && apiItem.inStock !== "nodata") {
                          currentPID = regionItems[i].specPid.split("/")[0];
                          if (regionItems[i].specPid.indexOf("/") !== -1) {
                              currentSID = regionItems[i].specPid.split("/")[1];
                          }
                          regionItems[i].idUsing = "specPid";
                          }
                      } else if (regionItems[i].gaPid.indexOf("/") !== -1) {
                          let apiItem = apiItemList.find(obj => {
                          return obj.productId === regionItems[i].gaPid.split("/")[0].toUpperCase() && obj.skuId === regionItems[i].gaPid.split("/")[1].toUpperCase()
                          })
                          if (apiItem !== undefined && apiItem.inStock !== "nodata") {
                          currentPID = regionItems[i].gaPid.split("/")[0];
                          currentSID = regionItems[i].gaPid.split("/")[1];
                          }
                          regionItems[i].idUsing = "gaPid";
                      } else if (regionItems[i].poPid.indexOf("/") !== -1) {
                          let apiItem = apiItemList.find(obj => {
                          return obj.productId === regionItems[i].poPid.split("/")[0].toUpperCase() && obj.skuId === regionItems[i].poPid.split("/")[1].toUpperCase()
                          })
                          if (apiItem !== undefined && apiItem.inStock !== "nodata") {
                          currentPID = regionItems[i].poPid.split("/")[0];
                          currentSID = regionItems[i].poPid.split("/")[1];
                          }
                          regionItems[i].idUsing = "poPid";
                      }
  
                      if (item.productId === currentPID.toUpperCase() && item.skuId === currentSID.toUpperCase()) {
                          //console.log(item.productId + " " + item.skuId + " " + " MSRP= " + item.MSRP);
                          if ((item.MSRP != 0) && (item.MSRP != "100000")) {
                              //console.log("|" + item.MSRP + "|");
                              regionItems[i].priceText = formatCurrency(item.MSRP, currencyFormat);
                              regionItems[i].priceNumber = item.MSRP;
                              if (item.MSRP > item.listPrice) {
                                  regionItems[i].tprPriceText = formatCurrency(item.listPrice, currencyFormat);
                                  regionItems[i].tprPriceNumber = item.listPrice;
                              }
                          } else { // console.log("Broken: " + urlRegion + " - " + regionItems[i].productId + " - " + regionItems[i].updProductId + " - " + regionItems[i].headline); 
                          }
                          if (item.inStock === "false") {
                              regionItems[i].badge = soldOutString.locales[urlRegion].keySoldout.toUpperCase() + "*lightgray";
                          }
                      }
                  });
  
              }
  
              if (regionItems[i].priceNumber !== "####" && regionItems[i].priceNumber > 1) {
                  var displayPrice = formatCurrency(regionItems[i].priceNumber, currencyFormat);
              } else if (regionItems[i].priceNumber > 0) {
                  var displayPrice = "";
              } else {
                  var displayPrice = regionItems[i].priceNumber;
              }
  
              // Hide Badges
              // $("[data-product='Xbox Wireless Controller – Starfield Limited Edition'] .c-badge").hide();
                 // $("[data-product='Xbox Wireless Headset – Starfield Limited Edition'] .c-badge").hide();
  
              //construct review URL
              var countryStore = "msusa"
              if (urlRegion === "en-gb") {
                  countryStore = "msuk"
              }
              var urlRegionUrl = urlRegion.split("-")[0] + "_" + urlRegion.split("-")[1].toUpperCase();
              var reviewUrl = "https://www.microsoftstore.com/store/" + countryStore + "/" + urlRegionUrl + "/pdp/" + regionItems[i].itemId + "/productID." + regionItems[i].productId + "#ratingsandreviews";
  
              var detailstext = $("#seedetailstext").text().replace("[[PLACEHOLDER]]", regionItems[i].headline);
  
              // Aria's
              // if (regionItems[i].detailsCTA.indexOf("DESIGN") !== -1) {
              //     detailstext = "Design yours with, " + regionItems[i].headline;
              // }
  
              // if (regionItems[i].detailsCTA.indexOf("PICK YOUR TEAM") !== -1) {
              //     detailstext = "Pick your team with, " + regionItems[i].headline;
              // }
              // Data Retailer removal/addition
              var dataLearn = 'data-cta="learn"'
              var dataRetailer = 'data-retailer="MS Store" target="_blank"'
  
              if (regionItems[i].detailsURL.indexOf("microsoft.com") !== -1) {
                  dataLearn = "";
              } else if (regionItems[i].detailsURL.indexOf("xbox.com") !== -1) {
                  dataRetailer = "";
              } else {
                  dataLearn = "";
                  dataRetailer = 'data-cta="external" target="_blank"'
              }
  
              // EU Changes
              var euchangeArray = ["cs-cz", "da-dk", "de-at", "de-de", "el-gr", "en-ie", "es-es", "fi-fi", "fr-be", "fr-fr", "hu-hu", "it-it", "nl-be", "nl-nl", "pl-pl", "pt-pt", "sk-sk", "sv-se"];
  
              if (euchangeArray.indexOf(urlRegion) !== -1) {
                  var erpText = priceFormat.locales[urlRegion].keyErptext;
              } else {
                  erpText = "";
              }
  
              var badgeclass = "f-highlight";
              var badgetext = regionItems[i].badge;
              if (badgetext.indexOf("*") !== -1) {
                  badgetext = regionItems[i].badge.split("*")[0];
                  var badgecolor = regionItems[i].badge.split("*")[1].toLowerCase();
                  if (badgecolor === "green") {
                  badgeclass = "f-accent white-c";
                  } else if (badgecolor === "lightgray") {
                  badgeclass = "f-highlight badge-silver"
                  } else if (badgecolor === "darkgray") {
                  badgeclass = "f-lowlight";
                  }
              }

              if (urlRegion.indexOf("en-") === -1) {
                if (badgetext === "NEW") {
                  badgetext = badgeCopy.locales[urlRegion].keyNew;
                } else if (badgetext === "PRE-ORDER") {
                  badgetext = badgeCopy.locales[urlRegion].keyPreorder;
                } else if (badgetext === "SALE") {
                  badgetext = badgeCopy.locales[urlRegion].keySale;
                } else if (badgetext === "EXCLUSIVE") {
                  badgetext = badgeCopy.locales[urlRegion].keyExclusive;
                } else if (badgetext === "BEST SELLER") {
                  badgetext = badgeCopy.locales[urlRegion].keyBestseller;
                } else if (badgetext === "LIMITED EDITION") {
                  badgetext = badgeCopy.locales[urlRegion].keyLimitededition;
                } else if (badgetext === "CLOUD") {
                  badgetext = badgeCopy.locales[urlRegion].keyCloud;
                } else if (badgetext === "GAME PASS") {
                  badgetext = badgeCopy.locales[urlRegion].keyGamepass;
                } else if (badgetext === "SOLD OUT") {
                  badgetext = badgeCopy.locales[urlRegion].keySoldout;
                } else if (badgetext === "FREE ENGRAVING") {
                  badgetext = badgeCopy.locales[urlRegion].keyFreeengraving;
                }

              }

              var toutSize = "productNormal"
              if (regionItems[i].itemSize === "2") {
                toutSize = "productBig"
              } else if (regionItems[i].itemSize === "3") {
                toutSize = "productFullwidth"
              }

              if (regionItems[i].colorpivot.length < 3) {
                let mainImage = regionItems[i].image;
                let bannerImage = '';
                if (regionItems[i].itemSize === "3") {
                  mainImage = regionItems[i].image;
                  bannerImage = '<source srcset="' + regionItems[i].alternateImage + '" media="(min-width:1400px)" />'
                }

                let textArea = '<h3 class="c-subheading-4"><a href="' + regionItems[i].detailsURL.trim() + '" class="detailsCta" ' + dataLearn + ' ' + 
                      dataRetailer + ' aria-label="' + detailstext + '">' + 
                      regionItems[i].headline + '</a></h3>'
                if (regionItems[i].itemSize === "2" || regionItems[i].itemSize === "3") {
                  textArea = '<h3 class="c-subheading-4">' + regionItems[i].headline + '</h3>' +
                      '<p class="c-paragraph-3">' + regionItems[i].merchCopy + '</p>' +
                      '<a href="' + regionItems[i].detailsURL.trim() + '" class="detailsCta c-glyph c-call-to-action" ' + 
                      dataLearn + ' ' + dataRetailer + ' aria-label="' + detailstext + '">' + 
                      regionItems[i].merchCTA + '</a>'
                }

                var dynamicItem = '<div class="product ' + toutSize + '">' +
                    '<div class="item point" data-position="' + sheet2data.pagePosition + '" data-price="' + regionItems[i].priceNumber +
                  '" data-tprpricetext="' + regionItems[i].tprPriceNumber + '" data-originalorder="' + i + '" ' + 
                      'data-releasedate="' + regionItems[i].releaseDate + '" ' +
                      'data-android="' + sheet2data.android + '" data-category="' + sheet2data.category + 
                      '" data-cloud="' + sheet2data.cloud + '" data-colors="' + sheet2data.colors + 
                      '" data-features="' + sheet2data.features + '" data-iphone="' + sheet2data.iPhone + 
                      '" data-pc="' + sheet2data.pc + '" data-seriesxs="' + sheet2data.android + 
                      '" data-tv="' + sheet2data.tv + '" data-xboxone="' + sheet2data.xboxOne + '" data-msft="' + 
                      sheet2data.msft +'">' +
                  '<div>' +
                  '<section class="m-content-placement-item" data-js-href="' + regionItems[i].detailsURL.trim() + '">' +
                  '<picture class="c-image">' +
                  bannerImage + 
                  '<source srcset="' + regionItems[i].image + '" media="(min-width:0)">' +
                  '<img srcset="" src="" alt="' +
                  regionItems[i].headline + '" ms.title="' + regionItems[i].headline + '" aria-hidden="true">' +
                  '</picture>' +
                  '<div class="productCopy">' +
                  '<strong class="c-badge f-small ' + badgeclass + '">' + badgetext + '</strong>' +
                  textArea +
                  '<p class="c-paragraph-3 pricingInfo"><span class="priceText">' + displayPrice + erpText + '</span></p>' +
                  '</div><div></div>' +
                  '</section>' +
                  '</div>' +
                  '</div>' +
                  '</div>'

                  if (toutSize === "productNormal") {
                    const prodCats = sheet2data.category.split(",")
                    for (j = 0; j < prodCats.length; j++) {
                      if (prodCats[j].length > 0) {
                        $("#" + prodCats[j].replace(/\s+/g, '').trim() + " .productLayout").append(dynamicItem);
                      }
                    }
                    $("#all .productLayout").append(dynamicItem)
                  } else {
                    const bigToutKey = toutOrder[sheet2data.pagePosition.toLowerCase()];
                    if (typeof bigToutKey === 'number') {
                      bigTouts[bigToutKey] = dynamicItem;
                    }
                  }

                } else { // item is part of color pivot

                  let thecats = sheet2data.category.split(",");
                  thecats.push("all");
                  for (let c = 0; c < thecats.length; c++) {
                    const thiscat = thecats[c].replace(/\s+/g, '').replace("&",     "").replace("-", "").trim()
                    const pivotId = regionItems[i].colorpivot.split("-")[0] + thiscat;
                    const pivotColor = regionItems[i].colorpivot.split("-")[1]
                    let controlId = "pivot" + pivotId + pivotColor
                    let ariaHidden = "false";

                    function top(controlId, ariaHidden) {
                      let mainImage = regionItems[i].image;
                      let bannerImage = '';
                      if (regionItems[i].itemSize === "3") {
                        mainImage = regionItems[i].image;
                        bannerImage = '<source srcset="' + regionItems[i].alternateImage + '" media="(min-width:1400px)" />'
                      }
                      return '<div id="' + controlId + '" aria-hidden="' + ariaHidden + '" class="item point" data-position="' + sheet2data.pagePosition + 
                        '" data-price="' + regionItems[i].priceNumber + 
                        '" data-tprpricetext="' + regionItems[i].tprPriceNumber + '" data-originalorder="' + i + '" ' +
                        'data-releasedate="' + regionItems[i].releaseDate + '" role="tabpanel" ' +
                        'data-android="' + sheet2data.android + '" data-category="' + sheet2data.category + 
                        '" data-cloud="' + sheet2data.cloud + '" data-colors="' + sheet2data.colors + 
                        '" data-features="' + sheet2data.features + '" data-iphone="' + sheet2data.iPhone + 
                        '" data-pc="' + sheet2data.pc + '" data-seriesxs="' + sheet2data.android + 
                        '" data-tv="' + sheet2data.tv + '" data-xboxone="' + sheet2data.xboxOne + '" data-msft="' + 
                        sheet2data.msft +'">' +
                        '<div>' +
                        '<section class="m-content-placement-item" data-js-href="' + regionItems[i].detailsURL.trim() + '">' +
                        '<picture class="c-image">' +
                        bannerImage +
                        '<source srcset="  ' + mainImage + '" media="(min-width:0)" />' +
                        '<img srcset="" src="" alt="' +
                        regionItems[i].headline + '" ms.title="' + regionItems[i].headline + '" aria-hidden="true" />' +
                        '</picture>' +
                        // '<div class="productCopy">' +
                        '<strong class="c-badge f-small ' + badgeclass + '">' + badgetext + '</strong>' +
                        '<h3 class="c-subheading-4"><a href="' + regionItems[i].detailsURL.trim() + '" class="detailsCta" ' + dataLearn + ' ' + 
                          dataRetailer + ' aria-label="' + detailstext + '">' + 
                          regionItems[i].headline + '</a></h3>' + 
                        '<p class="c-paragraph-3"><span class="priceText">' + displayPrice + erpText + '</span></p>' +
                        // '</div>' +
                        '</section></div></div>'
                    }

                    let liClass = "";

                    function picker(liClass, controlId) {
                      let showPrice = ""
                      if (regionItems[i].tprPriceText !== "####") {
                        showPrice = regionItems[i].tprPriceText;
                      } else {
                        showPrice = regionItems[i].priceText;
                      }
                      return '<li class="' + liClass + '" role="tab" tabindex="0" aria-controls="' + controlId + 
                              '" aria-label="' + regionItems[i].headline + ' ' + showPrice + '">' +
                              '<div class="color-indicator-border" role="none" style="background-color: #' + pivotColor + ';">' +
                                '<div class="color-indicator" style="background-color: #' + pivotColor + '; border-color: #' + pivotColor + '"></div>' +
                              '</li>'
                    }

                    if ($("#" + thiscat + " #" + pivotId).length === 0) {
                      liClass = "f-active";
                      function pivotItem(liClass, controlId, ariaHidden, cat) {
                        return '<div id="' + pivotId + '" class="product ' + toutSize + ' c-pivot">' +
                        '<span class="f-pivot-accessibility-text">' + $("#pickeraria").text() + '</span>' +
                          '<button class="c-flipper f-previous" aria-hidden="true" tabindex="-1" aria-label="' + $("#previousaria").text() + '"></button>' +
                          '<ul role="tablist">' + picker(liClass, controlId) + '</ul>' +
                        '<button class="c-flipper f-next" aria-hidden="true" tabindex="-1" aria-label="' + $("#nextaria").text() + '"></button>' +
                        top(controlId, ariaHidden) +
                        '</div>'
                      }

                      controlId = controlId + thiscat;
                      $("#" + thiscat + " .productLayout").append(pivotItem(liClass,controlId, ariaHidden));
                    } else {
                      controlId = controlId + thiscat;
                      ariaHidden = "true";
                      $("#" + thiscat + " #" + pivotId + " .item.point").last().after(top(controlId, ariaHidden));
                      liClass = ''
                      $("#" + thiscat + " #" + pivotId + " ul").append(picker(liClass, controlId));
                    }
                  }
                }                  
  
          } 
  
          var startingCopy = accHeadlines.locales[urlRegion].keyStarting;
          var freeCopy = badgeCopy.locales[urlRegion].keyFreecopy;

          // Free Copy + Legal
          document.querySelector(".legal1").setAttribute("id", "legal1");

          // asterisk click
          function legalJump() {
            var legaljump = $(".legal1").offset().top - 70;
            $("HTML, BODY").animate({
                scrollTop: legaljump
            }, 10);
          }

          $(document).on("click", ".legalDrop", function(e) {
            legalJump();
            $("#legal1")[0].focus();
          });
  
          $(".item").each(function() {
              if ($(this).find(".c-badge").text().indexOf("####") !== -1 || 
                  $(this).find(".c-badge").text() === "") {
                  $(this).find(".c-badge:contains('####')").remove();
                  $(this).find(".c-badge").each(function() {
                    if ($(this).text() === "") { $(this).remove(); }
                  })
              }
              var blankHref = $(this).find("a").attr("href");
              if (blankHref !== undefined && blankHref.indexOf("####") !== -1) {
                  $(this).find("a").attr("tabindex", "-1")
              }
              //console.log($(this).data("product"));
              //console.log("msrp is " + parseFloat($(this).data("price")) + " tpr is " + parseFloat($(this).data("tprpricetext")));
              $(this).attr("data-percoff", "0");
              
              priceDisplay(this);
  
              // Free Copy for Adaptive Thumbstick Toppers
              if ($(this).find("a").attr("href").indexOf("adaptive-thumbstick-toppers-for-xbox-controllers") !== -1) {
                if (freeCopy !== undefined) {
                  $(this).find(".pricingInfo").last().prepend('<span class="c-paragraph-3">' + freeCopy + '</span>' + "<a class='c-hyperlink legalDrop' style='margin: 0; cursor: pointer;' aria-label='*, Disclaimer about Adaptive Thumbstick Toppers'><sup>*</sup></a>")
                  $(this).find(".m-content-placement-item").addClass("f-precise-click");
                }
              } 

              if ($(this).find(".detailsCta").attr("href") !== undefined && $(this).find(".detailsCta").attr("href").indexOf("####") > -1) {
                  $(this).css("pointer-events", "none").css("cursor", "auto");
                  $(this).find(".detailsCta").css("visibility", "hidden");
              }
  
              if ($(this).find("a").attr("href") !== undefined && $(this).find("a").attr("href").indexOf("razer-edge-android-gaming-handheld") !== -1) {
                  $(this).find(".c-paragraph-3").prepend("Starting From: ")
              }
              const sfAfter = ["ja-jp"]
              if ($(this).find("a").attr("href") !== undefined && $(this).find("a").attr("href").indexOf("xboxdesignlab") !== -1) {
                  if (sfAfter.includes(urlRegion)) {
                    $(this).find(".priceText").last().append('<span class="c-paragraph-3">' + startingCopy + '</span>');
                  } else {
                    if ($(this).find("a").attr("href").indexOf("adaptive-thumbstick-toppers-for-xbox-controllers") === -1) {
                      $(this).find(".priceText").last().prepend('<span class="c-paragraph-3">' + startingCopy + '</span>');
                    }

                  }
              }
          })
  
          $(".priceText:contains('####')").css("visibility", "hidden");

            handleCats();
            removeEmpty();
            mwfAutoInit.ComponentFactory.create([{
              component: mwfAutoInit.Pivot,
              selector: ".c-pivot"
            }]);
            setTimeout(function() {
              $(".product.c-pivot").each(function() {
                if ($(this).find("ul li").length > 3 && $(this).find(".f-next").attr("aria-hidden") === "false") {
                  $(".product.c-pivot").each(function(ind) {
                    if ($(".product.c-pivot").eq(ind).find("ul li").length > 3) {
                      $(".product.c-pivot").eq(ind).find(".f-next").attr("aria-hidden", "false"); // fix arrow not visible upon init
                    }
                  })
                }
              })
            }, 1000)
      }

      function removeEmpty() {
        $(".itemCat").each(function() {
          if ($(this).find(".product").length === 0) {
            const cat = $(this).attr("id");
            $("[data-filt='category-" + cat + "']").closest("li").remove();
          }
        })
      }
  
      function showCount() {
        $(".itemcountHidden").removeClass("itemcountHidden");
        var itemcount = $(".itemCat:not(.hidden) .product").not(".hidden").length;
        $(".accTotal").text(itemcount);
        $(".noItems").addClass("itemcountHidden");
        $(".randItem").addClass("itemcountHidden");
        if (itemcount === 0) {
          $(".itemCat").not(".hidden").addClass("itemcountHidden");
          const rand = Math.ceil(Math.random() * 5);
          $(".rand" + rand).removeClass("itemcountHidden");
          $(".noItems").removeClass("itemcountHidden");
          $(".CatAnnounce").text($(".noResultsText").text());
        }
        // hide cats that show no products
        $(".itemCat:not(.hidden)").each(function() {
          if ($(this).find(".product:not(.hidden)").length === 0) {
            $(this).addClass("noProdhidden");
          } else {
            $(this).removeClass("noProdhidden");
          }
        })
        showInforms()
        showMoreSetup()
      }

      function showInforms() {
        console.log("running showInforms")
        $(".products .informTout").remove();
        let informFilts = [];
        $(".informTouts .informTout").each(function() {
          informFilts.push($(this).attr("data-inform"));
        })
        if (informFilts.length === 0) { return false }

        let informActives = [];

        for (let k = 0; k < informFilts.length; k++) {
          if ($("[data-filt='" + informFilts[k] + "']").hasClass("f-selected")) {
            informActives.push(informFilts[k]);
          }
        }
        if (informActives.length === 0) { return false }

        const itemcount = $(".itemCat:not(.hidden) .product").not(".hidden").length;
        for (let k = 0; k < informActives.length; k++) {
          if (itemcount > 6) {
            const spot = 4 * (k + 1);
            const infTout = $("[data-inform='" + informActives[k] + "']").clone()
            $(".itemCat:not(.hidden)").first().find(".product").not(".hidden").eq(spot).before(infTout)
          } else {
            const infTout = $("[data-inform='" + informActives[k] + "']").clone();
            $(".itemCat:not(.hidden)").first().find(".product").not(".hidden").last().after(infTout)
          }
        }
        $(".informTout p.c-paragraph-3").each(function() {
          if ($(this).text().length > 299) {
            $(this).addClass("smallestToutText");
          } else if ($(this).text().length > 238 || urlRegion === "ja-jp") {
            $(this).addClass("smallerToutText");
          }
        })
        $(".informTout h3.c-subheading-4").each(function() {
          if ($(this).text().length > 30) {
            $(this).addClass("smallerHeadingText");
          }
        })       
      }

      function showMoreSetup() {
        $(".drawerContainer").remove();
        $(".itemCat").each(function() {
          const currentCat = this;
          $(currentCat).find(".showmoreHidden").removeClass("showmoreHidden");
          $(currentCat).find(".prevHidden").removeClass("prevHidden");
          let prodsToShow = 50;
          if (window.innerWidth < 768) {
            prodsToShow = 20;
          }
          if ($(currentCat).find(".product").not(".hidden").length > (prodsToShow + 6)) { // no need for see more if not that many more
            $(currentCat).find(".product").not(".hidden").slice(prodsToShow).addClass("showmoreHidden");
            $(currentCat).find(".product").not("hidden").last().after('<div class="x-type-center drawerContainer">' +
              '<a href="javascript:void(0)" class="showMoreText c-call-to-action zpt " aria-expanded="false" ' +
              'aria-label="' + $("#showmorearia").text() + '" role="button" data-more="' + $("#showmore").text() + 
              '" data-fewer="' + $("#showfewer").text() + '" tabindex="0">' + $("#showmore").text() + '</a></div>')
          }
        })
      }

      $(document).on("click", ".showMoreText", function(e) {
        e.preventDefault();
        if ($(this).attr("aria-expanded") === "false") {
          $(this).closest(".itemCat").find(".showmoreHidden").addClass("prevHidden").removeClass("showmoreHidden");
          const lessText = $(this).attr("data-fewer");
          $(this).text(lessText);
          $(this).attr("aria-expanded", "true");
          $(this).attr("aria-label", $("#showfeweraria").text());
          $(this).closest(".itemCat").find(".prevHidden").first().find("a").focus();
        } else if($(this).attr("aria-expanded") === "true") {
          $(".gamesMore").addClass("hiddenGames");
          var moreText = $(this).attr("data-more");
          $(this).closest(".itemCat").find(".prevHidden").addClass("showmoreHidden").removeClass("prevHidden");
          $(this).text(moreText);
          $(this).attr("aria-expanded", "false");
          $(this).attr("aria-label", $("#showmorearia").text());
          var acctop = $(this).closest(".itemCat").offset().top;
          $("HTML, BODY").animate({
              scrollTop: acctop
          }, 500);
          $(this).closest(".itemCat").find(".product:not(.hidden)").first().find("a").focus()
        }   
      }) 

      $(document).on("click", "#categoryFilter a", function(e) {
        e.preventDefault();
        $(this).toggleClass("f-selected")
        removeSearchSummary()
        handleCats();
      })

      $(document).on("click", ".c-drawer.f-checkbox:not(.catFilter) a", function(e) {
        e.preventDefault();
        $(this).toggleClass("f-selected")
        removeSearchSummary();
        handleFilters();
      })

      $(document).on("click", ".filterSelections a", function(e) {
        e.preventDefault();
        const thefilt = $(this).closest("li.c-choice-summary").attr("data-selected");
        removeFilterSummary(thefilt);
        removeSearchSummary();
        handleCats();
      })

      $(document).on("click", ".clearFilters", function(e) {
        e.preventDefault();
        $(".accsearch input").val("");
        clearFilters();
        removeSearchSummary();
      })

      $(document).on("click", ".c-search.accsearch button", function(e) {
        e.preventDefault();
        const val = $(this).closest(".c-search").find("input").val().trim().replace(/\s+/g, ' ').replace(/</g, "").toLowerCase();
        accSearch(val);
      })

      $(document).on("focus, click", "#productSort input", function(e) {
        // console.log("radio focused")
        const sortText = $(this).next("span").text();
        $(".currentSort").text(sortText);
        const sortVal = $(this).val();
        $("#productSort").attr("data-sort", sortVal);
        setTimeout(function() {
          $(".CatAnnounce").text($("#sortupdated").text().replace("[[PLACEHOLDER]]", sortText));
        }, 20)
        
        runSort()
        showMoreSetup()
      })

      $('#bttbutton').click(function(e) {
        e.preventDefault();
        var acctop = $(".thecatalog").offset().top;
        $("HTML, BODY").animate({
            scrollTop: acctop
        }, 500);
        $(".itemCat:not(.hidden) .product:not(.hidden) a").eq(0).focus()
      });

      function handleCats() { // deal with categories first, then other filters
        $("#categoryFilter a").each(function() {
          const dataFilt = $(this).attr("data-filt");
          const thecat = dataFilt.split("-")[1]
          if (!$(this).hasClass("f-selected")) {
            $(this).attr("aria-checked", "false")
            $("." + thecat).addClass("hidden")
            $("." + thecat + " .product").addClass("hidden");
            if ($(".filterSelections [data-selected='" + dataFilt + "']").length === 1) {
              removeFilterSummary(dataFilt);
            }
            if ($("#categoryFilter .f-selected").length === 0) {
              $(".itemCat").removeClass("hidden");
              $(".itemCat .product").removeClass("hidden");
            }
          } else {
            $(this).attr("aria-checked", "true")
            $("." + thecat).removeClass("hidden")
            $("." + thecat + " .product").removeClass("hidden");
            addFilterSummary("category-" + thecat)
          }
        })
        if ($("#categoryFilter a.f-selected").length === 0) {
          deactivateCategories();
        } else {
          activateCategories();
        }
        handleFilters();
      }

      function handleFilters() {
        $(".products .informTout").remove();
        filters = {
          "workson": [],
          "price": [],
          "features": [],
          "colors": []
        }
        const filtersKeys = Object.keys(filters);
        $(".colorStay").removeClass("colorStay");
        $(".c-drawer.f-checkbox:not(.catFilter) a").each(function() {
          const dataFilt = $(this).attr("data-filt");
          const type = dataFilt.split("-")[0]
          const thefilt = dataFilt.split("-")[1]
          if (!$(this).hasClass("f-selected")) {
            $(this).attr("aria-checked", "false")
            if ($(".filterSelections [data-selected='" + dataFilt + "']").length === 1) {
              removeFilterSummary(dataFilt);
            }
          } else {
            $(this).attr("aria-checked", "true")
            if ($(".filterSelections [data-selected='" + dataFilt + "']").length === 0) {
              addFilterSummary(dataFilt)
            }
            filters[type].push(thefilt)
          }
        })

        $(".itemCat:not(.hidden) .item").each(function() {
          const currentItem = this;
          let filterScore = 0;
          for (let k = 0; k < filtersKeys.length; k++) {
            if (filtersKeys[k] === "workson") {
              if (filters[filtersKeys[k]].length === 0) {
                filterScore++
              } else {
                let pass = false
                for (var m = 0; m < filters[filtersKeys[k]].length; m++) {
                  if ($(currentItem).attr("data-" + filters[filtersKeys[k]][m]) === "t") {
                    pass = true
                  }
                }
                if (pass === true) {
                  filterScore++
                }
              }
            } else if (filtersKeys[k] === "price") {
              if (filters[filtersKeys[k]].length === 0) {
                filterScore++
              } else {
                let pass = false
                const itemPrice = parseFloat($(currentItem).attr("data-price"));
                for (var m = 0; m < filters[filtersKeys[k]].length; m++) {
                  // if (filters[filtersKeys[k]].indexOf("price" + m) !== -1) {
                    const loprice = parseFloat($("[data-filt='price-" + filters[filtersKeys[k]][m] + "']").attr("data-pricerange").split("^")[0]);
                    const hiprice = parseFloat($("[data-filt='price-" + filters[filtersKeys[k]][m] + "']").attr("data-pricerange").split("^")[1]);
                    
                    if (itemPrice >= loprice && itemPrice <= hiprice) {
                      pass = true
                    }
                  // }
                }
                if (pass === true) {
                  filterScore++
                }
              }
            } else if (filtersKeys[k] === "features") {
              if (filters[filtersKeys[k]].length === 0) {
                filterScore++
              } else {
                let pass = false
                for (var m = 0; m < filters[filtersKeys[k]].length; m++) {
                  if ($(currentItem).attr("data-" + filtersKeys[k]).indexOf(filters[filtersKeys[k]][m]) !== -1) {
                    pass = true
                  }
                }
                if (pass === true) {
                  filterScore++
                }
              }
            } else if (filtersKeys[k] === "colors") {
              if (filters[filtersKeys[k]].length === 0) {
                filterScore++
              } else {
                let pass = false
                for (var m = 0; m < filters[filtersKeys[k]].length; m++) {
                  if ($(currentItem).attr("data-" + filtersKeys[k]).indexOf(filters[filtersKeys[k]][m]) !== -1) {
                    pass = true
                  }
                }
                for (var m = 0; m < filters[filtersKeys[k]].length; m++) {
                  if ($(currentItem)[0].hasAttribute("id")) { // if one in color pivot has any selected color, product survives
                      $(currentItem).siblings("div[id]").each(function() {
                        if ($(this).attr("data-" + filtersKeys[k]).indexOf(filters[filtersKeys[k]][m]) !== -1) {
                          pass = true
                          if (filterScore === filtersKeys.length -1) {
                            showPivotColor($(this).attr("id"));
                          }
                        }
                      })
                  }
                }
                if (pass === true) {
                  filterScore++
                }
              }
            }
          }

          if (filterScore === filtersKeys.length) {
            $(currentItem).closest(".product").removeClass("hidden");
          } else {
            $(currentItem).closest(".product").not(".colorStay").addClass("hidden");
          }
        })

        if ($(".ui .f-checkbox .f-selected").length === 0) {
          $(".closeFilters").removeClass("hidden");
          $(".showResults").addClass("hidden");
        } else {
          $(".closeFilters").addClass("hidden");
          $(".showResults").removeClass("hidden");
        }

        runSort();
        showCount();
      }

      function runSort() {
        const sorting = $("#productSort").attr("data-sort");
        let idsForPivot = [];
        $(".productBig").remove();
        $(".productFullwidth").not(".informTout").remove();
        $(".itemCat:not(.hidden) .productLayout").each(function() {
          let catItems = $(this);
          catItems.find(".product.productNormal:not(.hidden)").sort(function(a, b) {
            if (sorting === "featured") {
              if ($(a).find(".item").first()[0].dataset.position !== "1000000" || 
                 $(b).find(".item").first()[0].dataset.position !== "1000000") {
                return $(a).find(".item").first()[0].dataset.position - $(b).find(".item").first()[0].dataset.position
              }
              const msft1 = $(a).find(".item").first()[0].dataset.msft;
              const msft2 = $(b).find(".item").first()[0].dataset.msft;
              if (msft1 !== msft2) {
                return msft1 < msft2 ? 1 : -1;
              }
              const date1 = new Date($(a).find(".item").first()[0].dataset.releasedate);
              const date2 = new Date($(b).find(".item").first()[0].dataset.releasedate);
              if (date1 !== date2) {
                return date2 - date1
              }
              const title1 = $(a).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              const title2 = $(b).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              return title2 < title1 ? 1 : -1;      
            } else if (sorting === "newest") {
              const date1 = new Date($(a).find(".item").first()[0].dataset.releasedate);
              const date2 = new Date($(b).find(".item").first()[0].dataset.releasedate);
              if (date1 !== date2) {
                return date2 - date1
              }
              const title1 = $(a).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              const title2 = $(b).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              return title2 < title1 ? 1 : -1;
            } else if (sorting === "az") {
              const title1 = $(a).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              const title2 = $(b).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              return title2 < title1 ? 1 : -1;
            } else if (sorting === "za") {
              const title1 = $(a).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              const title2 = $(b).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              return title1 < title2 ? 1 : -1;
            } else if (sorting === "hilo") {
              let x = 0;
              let y = 0;
              let hiItemIda = "";
              let hia = 0;
              if ($(a).find(".item").length > 1) {
                for (let u = 0; u < $(a).find(".item").length; u++) {
                  if (parseFloat($(a).find(".item").eq(u).attr("data-price")) > hia) {
                    hia = parseFloat($(a).find(".item").eq(u).attr("data-price"))
                    x = u;
                    hiItemIda = $(a).find(".item").eq(u).attr("id");
                  }
                }
                if (hiItemIda.length > 0 && !idsForPivot.includes(hiItemIda)) {
                  idsForPivot.push(hiItemIda)
                }
              }
              let hiItemIdb = "";
              let hib = 0;
              if ($(b).find(".item").length > 1) {
                for (let u = 0; u < $(b).find(".item").length; u++) {
                  if (parseFloat($(b).find(".item").eq(u).attr("data-price")) > hib) {
                    hib = parseFloat($(b).find(".item").eq(u).attr("data-price"))
                    y = u;
                    hiItemIdb = $(b).find(".item").eq(u).attr("id");
                  }
                }
                if (hiItemIdb.length > 0 && !idsForPivot.includes(hiItemIdb)) {
                  idsForPivot.push(hiItemIdb)
                }
              }
              let price1 = $(a).find(".item").eq(x).attr("data-price");
              let price2 = $(b).find(".item").eq(y).attr("data-price");
              if (price1 === "####") { price1 = "0" }
              if (price2 === "####") { price2 = "0" }
              if (price1 !== price2) {
                return parseFloat(price1) < parseFloat(price2) ? 1 : -1;
              }
              const title1 = $(a).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              const title2 = $(b).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              return title2 < title1 ? 1 : -1;
            } else if (sorting === "lohi") {
              let x = 0;
              let y = 0;
              let hiItemIda = "";
              let hia = 10000000000;
              if ($(a).find(".item").length > 1) {
                for (let u = 0; u < $(a).find(".item").length; u++) {
                  if (parseFloat($(a).find(".item").eq(u).attr("data-price")) < hia) {
                    hia = parseFloat($(a).find(".item").eq(u).attr("data-price"))
                    x = u;
                    hiItemIda = $(a).find(".item").eq(u).attr("id");
                  }
                }
                if (hiItemIda.length > 0 && !idsForPivot.includes(hiItemIda)) {
                  idsForPivot.push(hiItemIda)
                }
              }
              let hiItemIdb = "";
              let hib = 10000000000;
              if ($(b).find(".item").length > 1) {
                for (let u = 0; u < $(b).find(".item").length; u++) {
                  if (parseFloat($(b).find(".item").eq(u).attr("data-price")) < hib) {
                    hib = parseFloat($(b).find(".item").eq(u).attr("data-price"))
                    y = u;
                    hiItemIdb = $(b).find(".item").eq(u).attr("id");
                  }
                }
                if (hiItemIdb.length > 0 && !idsForPivot.includes(hiItemIdb)) {
                  idsForPivot.push(hiItemIdb)
                }
              }
              let price1 = $(a).find(".item").eq(x).attr("data-price");
              let price2 = $(b).find(".item").eq(y).attr("data-price");
              if (price1 === "####") { price1 = "1000000000000" }
              if (price2 === "####") { price2 = "1000000000000" }
              if (price1 !== price2) {
                return parseFloat(price2) < parseFloat(price1) ? 1 : -1;
              }
              const title1 = $(a).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              const title2 = $(b).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              return title2 < title1 ? 1 : -1;
            } else if (sorting === "perc") {
              let x = 0;
              let y = 0;
              let hiItemIda = "";
              let hiPercoffa = 0;
              if ($(a).find(".item").length > 1) {
                for (let u = 0; u < $(a).find(".item").length; u++) {
                  if (parseFloat($(a).find(".item").eq(u).attr("data-percoff")) > hiPercoffa) {
                    hiPercoffa = parseFloat($(a).find(".item").eq(u).attr("data-percoff"))
                    x = u;
                    hiItemIda = $(a).find(".item").eq(u).attr("id");
                  }
                }
                if (!idsForPivot.includes(hiItemIda)) {
                  idsForPivot.push(hiItemIda)
                }
              }
              let hiItemIdb = "";
              let hiPercoffb = 0;
              if ($(b).find(".item").length > 1) {
                for (let u = 0; u < $(b).find(".item").length; u++) {
                  console.log(hiPercoffb)
                  if (parseFloat($(b).find(".item").eq(u).attr("data-percoff")) > hiPercoffb) {
                    hiPercoffb = parseFloat($(b).find(".item").eq(u).attr("data-percoff"))
                    y = u;
                    hiItemIdb = $(b).find(".item").eq(u).attr("id");
                  }
                }
                if (!idsForPivot.includes(hiItemIdb)) {
                  idsForPivot.push(hiItemIdb)
                }
              }
              let percoff1 = parseFloat($(a).find(".item").eq(x)[0].dataset.percoff);
              let percoff2 = parseFloat($(b).find(".item").eq(y)[0].dataset.percoff);
              if (percoff1 !== percoff2) {
                return percoff1 < percoff2 ? 1 : -1;
              }
              const title1 = $(a).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              const title2 = $(b).find(".item").first().find("h3 a").text().toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e");
              return title2 < title1 ? 1 : -1;
            }
          }).appendTo(catItems);
        }) 
        
        if (sorting === "featured") {
          const bigToutKeys = Object.keys(bigTouts);
          bigToutKeys.forEach(function(key, index) {
            const after = (key * 12) - 1;
            if ($("#all .productLayout .product.productNormal").not(".hidden").length >= after) { 
              $("#all .productLayout .product.productNormal").not(".hidden").eq(after).after(bigTouts[key]);
            }
          }) 
          checkBigTouts();
        } 
        if (idsForPivot.length > 0) {
          idsForPivot.forEach(function(id) {
            showPivotColor(id);
          })
        }
      }       

      function activateCategories() {
        $("#all").addClass("hidden");
        $("#all .product").addClass("hidden");
        // $(".itemCat").not("#all").removeClass("hidden");
        // $(".itemCat").not("#all").find(".product").removeClass("hidden");
      }

      function deactivateCategories() {
        // $("#all").removeClass("hidden");
        // $("#all .product").removeClass("hidden");
        $(".itemCat").not("#all").addClass("hidden");
        $(".itemCat").not("#all").find(".product").addClass("hidden");
      }

      function checkBigTouts() {
        const startingCopy = accHeadlines.locales[urlRegion].keyStarting;

        $(".productBig .item, .productFullwidth .item").each(function() {
          if ($(this).find("strong").text() === "####" || $(this).find("strong").text() === "") {
            $(this).find("strong").remove();
          }
          if ($(this).find(".priceText").text().indexOf("####") !== -1 || $(this).find(".priceText").text() === "") {
            $(this).find(".priceText").remove();
          }
          $(this).attr("data-percoff", "0");

          priceDisplay(this);

          const sfAfter = ["ja-jp"]
          if (nonStore.indexOf(urlRegion) === -1) {
              if ($(this).find("a").attr("href") !== undefined && ($(this).find("a").attr("href").includes("xboxdesignlab") || $(this).find("a").attr("href").includes("xbox-wireless-controller"))) {
                  if (sfAfter.includes(urlRegion)) {
                    $(this).find(".pricingInfo").last().append('<span class="c-paragraph-3">' + startingCopy + '</span>');
                  } else {
                    $(this).find(".pricingInfo").prepend('<span class="c-paragraph-3">' + startingCopy + '</span>');
                  }
              }
          }
        });
      }

      function priceDisplay(item) {
        if ($(item).data("tprpricetext") !== "####" && (parseFloat($(item).data("price")) > parseFloat($(item).data("tprpricetext")))) {
          var newPrice = $(item).data("tprpricetext");
          $(item).attr("data-oldprice", $(item).attr("data-price")) // keep old price for perc off
          $(item).attr("data-price", newPrice); //Update price so it sorts based on tpr
          const percoff = (parseFloat($(item).attr("data-oldprice")) - parseFloat($(item).attr("data-price"))) / parseFloat($(item).attr("data-oldprice")) * 100;
          const btext = $("#percoff").text().replace("[[PLACEHOLDER]]", Math.round(percoff));
          $(item).attr("data-percoff", percoff);
          $(item).find("h3").before('<strong class="c-badge f-small f-highlight">' + btext + '</strong>')
          newPrice = formatCurrency(newPrice, currencyFormat);
          $(item).find(".priceText").last().prepend('<span class="sr-text">' + $("#previousprice").text() + '</span>');
          $(item).find(".priceText").last().css("text-decoration", "line-through").after('<span itemprop="price" class="priceText" style="margin-left: 8px"><span class="sr-text">' +
              $("#currentprice").text() + '</span>' + newPrice + '</span>');
        }
      }

      function addFilterSummary(filt) {
        const filtText = $("[data-filt='" + filt + "']").find("span").text();
        const filtAria = $("#removefilter").text().replace("[[PLACEHOLDER]]", filtText);
        if ($(".filterSelections [aria-label='" + filtAria + "']").length === 0) {
          $(".filterSelections").append('<li class="c-choice-summary" data-selected="' + filt + '">' +
              '<a class="c-action-trigger c-glyph glyph-cancel" href="#" aria-label="' + filtAria + '">' +
                '<span class="x-screen-reader">' + filtAria + '</span></a>' +
            '<span class="summaryText">' + filtText + '</span></li>')
          $(".CatAnnounce").text($("#filteradded").text().replace("[[PLACEHOLDER]]", filtText));
        }
        filterCount();
      }

      function removeFilterSummary(filt) {
        $("[data-filt='" + filt + "']").removeClass("f-selected");
        const filtText = $(".filterSelections [data-selected='" + filt + "']").find(".summaryText").text();
        $(".filterSelections [data-selected='" + filt + "']").remove();
        $(".CatAnnounce").text($("#filterremoved").text().replace("[[PLACEHOLDER]]", filtText));
        filterCount();
      }

      function filterCount() {
        const filterCount = $(".filterSelections li").length;
        $(".filterCount").text(filterCount);
      }

      function showPivotColor(id) {
        $("#" + id).closest(".product").addClass("colorStay");
        $("#" + id).siblings("[id]").each(function() {
          $(this).attr("aria-hidden", "true")
        })
        $("#" + id).attr("aria-hidden", "false")
        $("[aria-controls='" + id + "']").siblings("li").each(function() {
          $(this).attr("tabindex", "-1").removeClass("f-active").attr("aria-selected", "false")
        })
        const actEl = document.activeElement;
        $("[aria-controls='" + id + "']").attr("tabindex", "0").addClass("f-active").attr("aria-selected", "true").click()
        actEl.focus();
      }

      function clearFilters() {
        $(".c-drawer.f-checkbox li a").removeClass("f-selected").attr("aria-checked", "false");
        handleCats();
        setTimeout(function() {
          $(".CatAnnounce").text($("#clearfilters").text())  
        }, 50)
      }
    
      function accSearch(str) {
        clearFilters();
        removeSearchSummary()
        deactivateCategories()
        var smallwords = ["the", "a", "an", "of", "for", "and", "or", "it", "in", "on", "with", "as", "at", "be", "but", "by", "from", "had", "has", "how", "if", "its", "so", "than", "that",
            "to", "too", "was"]
        $(".product").addClass("hidden");
        $(".product .item").each(function() {
          let text = $(this).find("a").text() + " "
          text += $(this).attr("data-category") + " " + $(this).attr("data-colors") + " " + $(this).attr("data-features");
          const strArr = str.split(" ");
          const textArr = text.split(" ");
          for (let s = 0; s < strArr.length; s++) {
            for (let t = 0; t < textArr.length; t++) {
              let simNum = 0;
              if (!smallwords.includes(strArr[s])) {
                simNum = similarity(textArr[t].toLowerCase(), strArr[s]);
              }
              console.table(simNum, textArr[t].toLowerCase(), strArr[s]);
              if (simNum > .8) {
                $(this).closest(".product").removeClass("hidden");
              }
            }
          }
        })
        addSearchSummary(str)
      }

      function addSearchSummary(str) {
        const filtAria = $("#removefilter").text().replace("[[PLACEHOLDER]]", str);
        if ($(".filterSelections [aria-label='" + filtAria + "']").length === 0) {
          $(".filterSelections").append('<li class="c-choice-summary" data-selected="search">' +
              '<a class="c-action-trigger c-glyph glyph-cancel" href="#" aria-label="' + filtAria + '">' +
                '<span class="x-screen-reader">' + filtAria + '</span></a>' +
            '<span class="summaryText">' + "'" + str + "'" + '</span></li>')
          $(".CatAnnounce").text($("#filteradded").text().replace("[[PLACEHOLDER]]", str));
        }
        showCount();
        filterCount();
      }

      function removeSearchSummary() {
        if ($(".filterSelections li").length > 0) {
          const filtText = $(".filterSelections [data-selected='search']").find(".summaryText").text();
          $(".CatAnnounce").text($("#filterremoved").text().replace("[[PLACEHOLDER]]", filtText));
          $(".filterSelections [data-selected='search']").remove();
          $(".product").removeClass("hidden");
        }
        filterCount();
      }

      function similarity(s1, s2) {
        var longer = s1;
        var shorter = s2;
        if (s1.length < s2.length) {
          longer = s2;
          shorter = s1;
        }
        var longerLength = longer.length;
        if (longerLength == 0) {
          return 1.0;
        }
        return (longerLength - editDistance(longer, shorter)) / parseFloat(longerLength);
      }
      function editDistance(s1, s2) {
        s1 = s1.toLowerCase();
        s2 = s2.toLowerCase();

        var costs = new Array();
        for (var i = 0; i <= s1.length; i++) {
          var lastValue = i;
          for (var j = 0; j <= s2.length; j++) {
            if (i == 0)
              costs[j] = j;
            else {  
              if (j > 0) {
                var newValue = costs[j - 1];
                if (s1.charAt(i - 1) != s2.charAt(j - 1))
                  newValue = Math.min(Math.min(newValue, lastValue),
                    costs[j]) + 1;
                costs[j - 1] = lastValue;
                lastValue = newValue;
              }
            }
          }
          if (i > 0)
            costs[s2.length] = lastValue;
        }
        return costs[s2.length];
      }
  
      var theTarget = document.URL;
  
      function changeCat(cat, thedelay) {
          setTimeout(function() {
            if (cat.indexOf("-") === -1) {
              $("[data-filt='category-" + cat + "']").click();
            } else {
              $("[data-filt='" + cat + "']").click();
            }  
            totop();
          }, thedelay)
      }
  
      if (theTarget.indexOf("#") > -1) {
          // $(".gameList").hide();
          // reset page for FF and IE
          //changeCat("boxAll", 0)
          theTarget = theTarget.split("#")[1].toLowerCase()
          if (theTarget === "controllers") {
              changeCat("controllers", 1500)
          } else if (theTarget.indexOf("xdl") !== -1) {
              changeCat("xdl", 1500)
          } else if (theTarget.indexOf("mobile") !== -1) {
              changeCat("mobile", 1500)
          } else if (theTarget.indexOf("stands") !== -1) {
              changeCat("stands", 1500)
          } else if (theTarget === "headsets") {
              changeCat("headsets", 1500)
          } else if (theTarget.indexOf("storage") !== -1) {
              changeCat("storage", 1500)
          } else if (theTarget.indexOf("display") !== -1) {
              changeCat("display", 1500)
          } else if (theTarget.indexOf("cables") !== -1) {
              changeCat("cables", 1500)
          } else if (theTarget.indexOf("consolewraps") !== -1) {
              changeCat("wraps", 1500)
          } else if (theTarget.indexOf("wheels") !== -1) {
              changeCat("wheels", 1500)
          } else if (theTarget.indexOf("starters") !== -1) {
              changeCat("components", 1500)
          } else if (theTarget.indexOf("assistive") !== -1) {
              changeCat("assistive", 1500)
          } else if (theTarget.indexOf("windows") !== -1) {
              changeCat("workson-pc", 1500)
          } else if (theTarget.indexOf("monitors") !== -1) {
              changeCat("display", 1500)
          } else if (theTarget.indexOf("handheld") !== -1) {
              changeCat("handhelds", 1500)
          } else if (theTarget === "wired") {
            changeCat("features-wired", 1500);
          } else if (theTarget.indexOf("wiredcontrollers") !== -1) {
            changeCat("controllers", 1500);
            changeCat("features-wired", 1500);
          } else if (theTarget.indexOf("wirelessheadsets") !== -1) {
            changeCat("headsets", 1500);
            changeCat("features-wireless", 1500);
          } else if (theTarget.indexOf("wiredheadsets") !== -1) {
            changeCat("headsets", 1500);
            changeCat("features-wired", 1500);
          }
      }
  
      
  
      setTimeout(function() {
          $(".item img").attr("tabindex", "-1")
          $(".item .detailsCta").attr("tabindex", "0")
      }, 1500)
  
      // m-feature fix
      // $(".m-feature").removeClass("m-feature").addClass("m-");
  
      var windowresized2 = (function() {
          var timers = {};
          return function(callback, ms, uniqueId) {
              if (!uniqueId) {
                  uniqueId = "Fires only once.";
              }
              if (timers[uniqueId]) {
                  clearTimeout(timers[uniqueId]);
              }
              timers[uniqueId] = setTimeout(callback, ms);
          };
      })();    
  
  })();
  
  });
  
  function setCharAt(str, index, chr) {
      if (index > str.length - 1) return str;
      return str.substr(0, index) + chr + str.substr(index + 1);
  }
  
  accHeadlines = {
      "locales": {
          "en-us": {
              "keyAccessories": "Accessories",
              "keyLastChance": "LAST CHANCE",
              "keyStarting": "Starting from "
          },
          "ar-ae": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "ar-sa": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "cs-cz": {
              "keyAccessories": "Příslušenství",
              "keyStarting": "Již od  "
          },
          "da-dk": {
              "keyAccessories": "Tilbehør",
              "keyLastChance": "SIDSTE CHANCE",
              "keyStarting": "Fra  "
          },
          "de-at": {
              "keyAccessories": "Zubehör",
              "keyLastChance": "LETZTE CHANCE",
              "keyStarting": "Erhältlich ab  "
          },
          "de-ch": {
              "keyAccessories": "Zubehör",
              "keyStarting": "Erhältlich ab  "
          },
          "de-de": {
              "keyAccessories": "Zubehör",
              "keyLastChance": "LETZTE CHANCE",
              "keyStarting": "Erhältlich ab  "
          },
          "el-gr": {
              "keyAccessories": "Αξεσουάρ",
              "keyStarting": "Από  "
          },
          "en-au": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "en-ca": {
              "keyAccessories": "Accessories",
              "keyLastChance": "LAST CHANCE",
              "keyStarting": "Starting from "
          },
          "en-gb": {
              "keyAccessories": "Accessories",
              "keyLastChance": "LAST CHANCE",
              "keyStarting": "Starting from "
          },
          "en-hk": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "en-ie": {
              "keyAccessories": "Accessories",
              "keyLastChance": "LAST CHANCE",
              "keyStarting": "Starting from "
          },
          "en-in": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "en-nz": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "en-sg": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "en-za": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "es-ar": {
              "keyAccessories": "Accesorios",
              "keyStarting": ""
          },
          "es-cl": {
              "keyAccessories": "Accesorios",
              "keyStarting": ""
          },
          "es-co": {
              "keyAccessories": "Accesorios",
              "keyStarting": ""
          },
          "es-es": {
              "keyAccessories": "Accesorios",
              "keyLastChance": "ÚLTIMA OPORTUNIDAD",
              "keyStarting": "Desde  "
          },
          "es-mx": {
              "keyAccessories": "Accesorios",
              "keyStarting": ""
          },
          "fi-fi": {
              "keyAccessories": "Lisälaitteet",
              "keyLastChance": "VIIMEINEN MAHDOLLISUUS",
              "keyStarting": "Alkaen  "
          },
          "fr-be": {
              "keyAccessories": "Accessoires",
              "keyLastChance": "DERNIÈRE CHANCE",
              "keyStarting": "À partir de  "
          },
          "fr-ca": {
              "keyAccessories": "Accessoires",
              "keyLastChance": "DERNIÈRE CHANCE",
              "keyStarting": "À partir de  "
          },
          "fr-ch": {
              "keyAccessories": "Accessoires",
              "keyStarting": "À partir de  "
          },
          "fr-fr": {
              "keyAccessories": "Accessoires",
              "keyLastChance": "DERNIÈRE CHANCE",
              "keyStarting": "À partir de  "
          },
          "he-il": {
              "keyAccessories": "Accessories",
              "keyStarting": "Starting from "
          },
          "hu-hu": {
              "keyAccessories": "Tartozék ",
              "keyStarting": " -tól"
          },
          "it-it": {
              "keyAccessories": "Accessori",
              "keyLastChance": "ULTIMA POSSIBILITÀ",
              "keyStarting": "A partire da  "
          },
          "ja-jp": {
              "keyAccessories": "アクセサリー",
              "keyStarting": " から"
          },
          "ko-kr": {
              "keyAccessories": "액세서리",
              "keyStarting": "최저 가격:  "
          },
          "nb-no": {
              "keyAccessories": "Tilbehør",
              "keyStarting": "Fra  "
          },
          "nl-be": {
              "keyAccessories": "Accessoires",
              "keyLastChance": "LAATSTE KANS",
              "keyStarting": "Vanaf  "
          },
          "nl-nl": {
              "keyAccessories": "Accessoires",
              "keyLastChance": "LAATSTE KANS",
              "keyStarting": "Vanaf  "
          },
          "pl-pl": {
              "keyAccessories": "Akcesoria",
              "keyLastChance": "OSTATNIA SZANSA",
              "keyStarting": "Już od  "
          },
          "pt-br": {
              "keyAccessories": "Acessórios",
              "keyStarting": ""
          },
          "pt-pt": {
              "keyAccessories": "Acessórios",
              "keyLastChance": "ÚLTIMA OPORTUNIDADE",
              "keyStarting": "A partir de  "
          },
          "ru-ru": {
              "keyAccessories": "Аксессуары",
              "keyStarting": ""
          },
          "sk-sk": {
              "keyAccessories": "Príslušenstvo",
              "keyStarting": "Už od  "
          },
          "sv-se": {
              "keyAccessories": "Tillbehör",
              "keyLastChance": "SISTA CHANSEN",
              "keyStarting": "Börjar från  "
          },
          "tr-tr": {
              "keyAccessories": "Aksesuarlar",
              "keyStarting": ""
          },
          "zh-cn": {
              "keyAccessories": "配件",
              "keyStarting": ""
          },
          "zh-hk": {
              "keyAccessories": "配件",
              "keyStarting": ""
          },
          "zh-tw": {
              "keyAccessories": "配件",
              "keyStarting": "起 "
          }
      }
  }
  
  priceFormat = {
      "locales": {
          "en-us": {
              "keyPriceFormat": "$#",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "ar-ae": {
              "keyPriceFormat": "AED #",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "ar-sa": {
              "keyPriceFormat": "SR.#",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "cs-cz": {
              "keyPriceFormat": "# Kč",
              "keyHasDecimal": true,
              "keyThousandCharacter": " ",
              "keyErptext": " OMC"
          },
          "da-dk": {
              "keyPriceFormat": "# kr",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " ERP"
          },
          "de-at": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " Geschätzter Ladenpreis"
          },
          "de-ch": {
              "keyPriceFormat": "CHF #",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " Geschätzter Ladenpreis"
          },
          "de-de": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " Geschätzter Ladenpreis"
          },
          "el-gr": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " ERP"
          },
          "en-au": {
              "keyPriceFormat": "$# ",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "en-ca": {
              "keyPriceFormat": "$# ",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "en-gb": {
              "keyPriceFormat": "£#",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "en-hk": {
              "keyPriceFormat": "HK$#",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "en-ie": {
              "keyPriceFormat": "€ #",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "en-in": {
              "keyPriceFormat": "₹ #",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "en-nz": {
              "keyPriceFormat": "$# ",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "en-sg": {
              "keyPriceFormat": "SG$#",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "en-za": {
              "keyPriceFormat": "",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "es-ar": {
              "keyPriceFormat": "",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " PVP"
          },
          "es-cl": {
              "keyPriceFormat": "$#",
              "keyHasDecimal": false,
              "keyThousandCharacter": ".",
              "keyErptext": " PVP"
          },
          "es-co": {
              "keyPriceFormat": "",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " PVP"
          },
          "es-es": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " PVP"
          },
          "es-mx": {
              "keyPriceFormat": "$#",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " PVP"
          },
          "fi-fi": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " ERP"
          },
          "fr-be": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " Prix de revente estimé"
          },
          "fr-ca": {
              "keyPriceFormat": "# $",
              "keyHasDecimal": true,
              "keyThousandCharacter": " ",
              "keyErptext": " PDE"
          },
          "fr-ch": {
              "keyPriceFormat": "CHF #",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " Prix de revente estimé"
          },
          "fr-fr": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " Prix de revente estimé"
          },
          "he-il": {
              "keyPriceFormat": "# NIS",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "hu-hu": {
              "keyPriceFormat": "# HUF",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " Becsült fogyasztói ár"
          },
          "it-it": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " Prezzo stimato"
          },
          "ja-jp": {
              "keyPriceFormat": "# 円 (税込)",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " 推定小売価格"
          },
          "ko-kr": {
              "keyPriceFormat": "₩#",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " 예상 소매 가격"
          },
          "nb-no": {
              "keyPriceFormat": "# kr",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " ERP"
          },
          "nl-be": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " ERP"
          },
          "nl-nl": {
              "keyPriceFormat": "€ #",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " ERP"
          },
          "pl-pl": {
              "keyPriceFormat": "# zł",
              "keyHasDecimal": true,
              "keyThousandCharacter": " ",
              "keyErptext": " ERP"
          },
          "pt-br": {
              "keyPriceFormat": "R$ #",
              "keyHasDecimal": false,
              "keyThousandCharacter": ".",
              "keyErptext": " ERP"
          },
          "pt-pt": {
              "keyPriceFormat": "#  €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " ERP"
          },
          "ru-ru": {
              "keyPriceFormat": "# ₽",
              "keyHasDecimal": false,
              "keyThousandCharacter": "",
              "keyErptext": " ERP"
          },
          "sk-sk": {
              "keyPriceFormat": "# €",
              "keyHasDecimal": true,
              "keyThousandCharacter": ".",
              "keyErptext": " OMC"
          },
          "sv-se": {
              "keyPriceFormat": "# kr",
              "keyHasDecimal": true,
              "keyThousandCharacter": "",
              "keyErptext": " rek-pris"
          },
          "tr-tr": {
              "keyPriceFormat": "",
              "keyHasDecimal": true,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "zh-hk": {
              "keyPriceFormat": "HK$#",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          },
          "zh-tw": {
              "keyPriceFormat": "NT$#",
              "keyHasDecimal": false,
              "keyThousandCharacter": ",",
              "keyErptext": " ERP"
          }
      }
  }
  
  soldOutString = {
      "locales": {
      "en-us": {
          "keySoldout": "Sold out"
      },
      "ar-ae": {
          "keySoldout": "Sold out"
      },
      "ar-sa": {
          "keySoldout": "Sold out"
      },
      "cs-cz": {
          "keySoldout": "Vyprodáno"
      },
      "da-dk": {
          "keySoldout": "Udsolgt"
      },
      "de-at": {
          "keySoldout": "Ausverkauft"
      },
      "de-ch": {
          "keySoldout": "Ausverkauft"
      },
      "de-de": {
          "keySoldout": "Ausverkauft"
      },
      "el-gr": {
          "keySoldout": "Εξαντλήθηκε"
      },
      "en-au": {
          "keySoldout": "Sold out"
      },
      "en-ca": {
          "keySoldout": "Sold out"
      },
      "en-gb": {
          "keySoldout": "Sold out"
      },
      "en-hk": {
          "keySoldout": "Sold out"
      },
      "en-ie": {
          "keySoldout": "Sold out"
      },
      "en-in": {
          "keySoldout": "Sold out"
      },
      "en-nz": {
          "keySoldout": "Sold out"
      },
      "en-sg": {
          "keySoldout": "Sold out"
      },
      "en-za": {
          "keySoldout": "Sold out"
      },
      "es-ar": {
          "keySoldout": "Stock agotado"
      },
      "es-cl": {
          "keySoldout": "Stock agotado"
      },
      "es-co": {
          "keySoldout": "Stock agotado"
      },
      "es-es": {
          "keySoldout": "Existencias agotadas"
      },
      "es-mx": {
          "keySoldout": "Stock agotado"
      },
      "fi-fi": {
          "keySoldout": "Loppuunmyyty"
      },
      "fr-be": {
          "keySoldout": "Épuisé"
      },
      "fr-ca": {
          "keySoldout": "Épuisée"
      },
      "fr-ch": {
          "keySoldout": "Épuisé"
      },
      "fr-fr": {
          "keySoldout": "Épuisé"
      },
      "he-il": {
          "keySoldout": "Sold out"
      },
      "hu-hu": {
          "keySoldout": "Elfogyott"
      },
      "it-it": {
          "keySoldout": "Esaurito"
      },
      "ja-jp": {
          "keySoldout": "売り切れ"
      },
      "ko-kr": {
          "keySoldout": "품절"
      },
      "nb-no": {
          "keySoldout": "Utsolgt"
      },
      "nl-be": {
          "keySoldout": "Uitverkocht"
      },
      "nl-nl": {
          "keySoldout": "Uitverkocht"
      },
      "pl-pl": {
          "keySoldout": "Wyprzedane"
      },
      "pt-br": {
          "keySoldout": "Esgotado"
      },
      "pt-pt": {
          "keySoldout": "Esgotado"
      },
      "ru-ru": {
          "keySoldout": "Продано"
      },
      "sk-sk": {
          "keySoldout": "Vypredané"
      },
      "sv-se": {
          "keySoldout": "Slutsåld"
      },
      "tr-tr": {
          "keySoldout": "Tükendi"
      },
      "zh-hk": {
          "keySoldout": "售完"
      },
      "zh-tw": {
          "keySoldout": "售完"
      }
      }
  }

badgeCopy = {
  "locales": {
    "en-us": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING",
      "keyFreecopy": "FREE"
    },
    "ar-ae": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING"
    },
    "ar-sa": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING"
    },
    "cs-cz": {
      "keyNew": "NOVINKA",
      "keyPreorder": "PŘEDOBJEDNAT",
      "keySale": "VÝPRODEJ",
      "keyExclusive": "EXKLUZIVNÍ",
      "keyBestseller": "NEJPRODÁVANĚJŠÍ",
      "keyLimitededition": "LIMITOVANÁ EDICE",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "VYPRODÁNO",
      "keyFreeengraving": "BEZPLATNÉ GRAVÍROVÁNÍ",
      "keyFreecopy": "ZDARMA"
    },
    "da-dk": {
      "keyNew": "NYHED",
      "keyPreorder": "FORUDBESTIL",
      "keySale": "TILBUD",
      "keyExclusive": "EKSKLUSIV",
      "keyBestseller": "MEST SOLGTE",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "UDSOLGT",
      "keyFreeengraving": "GRATIS INDGRAVERING",
      "keyFreecopy": "GRATIS"
    },
    "de-at": {
      "keyNew": "NEU",
      "keyPreorder": "VORBESTELLEN",
      "keySale": "SALE",
      "keyExclusive": "EXKLUSIVE",
      "keyBestseller": "BESTSELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "AUSVERKAUFT",
      "keyFreeengraving": "KOSTENLOSE GRAVUR",
      "keyFreecopy": "KOSTENLOS"
    },
    "de-ch": {
      "keyNew": "NEU",
      "keyPreorder": "VORBESTELLEN",
      "keySale": "SALE",
      "keyExclusive": "EXKLUSIVE",
      "keyBestseller": "BESTSELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "AUSVERKAUFT",
      "keyFreeengraving": "KOSTENLOSE GRAVUR",
      "keyFreecopy": "KOSTENLOS"
    },
    "de-de": {
      "keyNew": "NEU",
      "keyPreorder": "VORBESTELLEN",
      "keySale": "SALE",
      "keyExclusive": "EXKLUSIVE",
      "keyBestseller": "BESTSELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "AUSVERKAUFT",
      "keyFreeengraving": "KOSTENLOSE GRAVUR",
      "keyFreecopy": "KOSTENLOS"
    },
    "el-gr": {
      "keyNew": "ΝΕΟ",
      "keyPreorder": "ΠΡΟ-ΠΑΡΑΓΓΕΛΙΑ",
      "keySale": "ΕΚΠΤΩΣΕΙΣ",
      "keyExclusive": "ΑΠΟΚΛΕΙΣΤΙΚΟ",
      "keyBestseller": "ΜΕ ΤΙΣ ΚΑΛΥΤΕΡΕΣ ΠΩΛΗΣΕΙΣ",
      "keyLimitededition": "ΠΕΡΙΟΡΙΣΜΕΝΗ ΕΚΔΟΣΗ",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ΕΞΑΝΤΛΗΘΗΚΕ",
      "keyFreeengraving": "ΔΩΡΕAΝ ΧAΡΑΞΗ",
      "keyFreecopy": "ΔΩΡΕΑΝ"
    },
    "en-au": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING",
      "keyFreecopy": "FREE"
    },
    "en-ca": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING",
      "keyFreecopy": "FREE"
    },
    "en-gb": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING",
      "keyFreecopy": "FREE"
    },
    "en-hk": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING"
    },
    "en-ie": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING",
      "keyFreecopy": "FREE"
    },
    "en-in": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING"
    },
    "en-nz": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING",
      "keyFreecopy": "FREE"
    },
    "en-sg": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING",
      "keyFreecopy": "FREE"
    },
    "en-za": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING"
    },
    "es-ar": {
      "keyNew": "NUEVO",
      "keyPreorder": "RESERVAR",
      "keySale": "OFERTA",
      "keyExclusive": "DESCUENTOS",
      "keyBestseller": "LOS MÁS VENDIDOS",
      "keyLimitededition": "EDICIÓN LIMITADA",
      "keyCloud": "NUBE",
      "keyGamepass": "GAME PASS",
      "keySoldout": "EXISTENCIAS AGOTADAS",
      "keyFreeengraving": "GRABADO GRATUITO"
    },
    "es-cl": {
      "keyNew": "NUEVO",
      "keyPreorder": "RESERVAR",
      "keySale": "OFERTA",
      "keyExclusive": "DESCUENTOS",
      "keyBestseller": "LOS MÁS VENDIDOS",
      "keyLimitededition": "EDICIÓN LIMITADA",
      "keyCloud": "NUBE",
      "keyGamepass": "GAME PASS",
      "keySoldout": "EXISTENCIAS AGOTADAS",
      "keyFreeengraving": "GRABADO GRATUITO"
    },
    "es-co": {
      "keyNew": "NUEVO",
      "keyPreorder": "RESERVAR",
      "keySale": "OFERTA",
      "keyExclusive": "DESCUENTOS",
      "keyBestseller": "LOS MÁS VENDIDOS",
      "keyLimitededition": "EDICIÓN LIMITADA",
      "keyCloud": "NUBE",
      "keyGamepass": "GAME PASS",
      "keySoldout": "EXISTENCIAS AGOTADAS",
      "keyFreeengraving": "GRABADO GRATUITO"
    },
    "es-es": {
      "keyNew": "NUEVO",
      "keyPreorder": "RESERVAR",
      "keySale": "MUNDIAL",
      "keyExclusive": "VENTAJAS",
      "keyBestseller": "MÁS VENDIDOS",
      "keyLimitededition": "MANDO DE",
      "keyCloud": "NUBE",
      "keyGamepass": "GAME PASS",
      "keySoldout": "EXISTENCIAS AGOTADAS",
      "keyFreeengraving": "GRABADO GRATUITO",
      "keyFreecopy": "GRATIS"
    },
    "es-mx": {
      "keyNew": "NUEVO",
      "keyPreorder": "RESERVAR",
      "keySale": "OFERTA",
      "keyExclusive": "DESCUENTOS",
      "keyBestseller": "LOS MÁS VENDIDOS",
      "keyLimitededition": "EDICIÓN LIMITADA",
      "keyCloud": "NUBE",
      "keyGamepass": "GAME PASS",
      "keySoldout": "EXISTENCIAS AGOTADAS",
      "keyFreeengraving": "GRABADO GRATUITO"
    },
    "fi-fi": {
      "keyNew": "UUSI",
      "keyPreorder": "TILAA ENNAKKOON",
      "keySale": "ALE",
      "keyExclusive": "YKSINOIKEUDELLA",
      "keyBestseller": "MYYDYIMMÄT",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "PILVI",
      "keyGamepass": "GAME PASS",
      "keySoldout": "LOPPUUNMYYTY",
      "keyFreeengraving": "ILMAINEN KAIVERRUS",
      "keyFreecopy": "ILMAINEN"
    },
    "fr-be": {
      "keyNew": "NOUVEAUTÉ",
      "keyPreorder": "PRÉCOMMANDER",
      "keySale": "MONDIALES",
      "keyExclusive": "AVANTAGES",
      "keyBestseller": "MEILLEURES VENTES",
      "keyLimitededition": "ÉDITION LIMITÉE",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ÉPUISÉ",
      "keyFreeengraving": "GRAVURE GRATUITE",
      "keyFreecopy": "GRATUIT"
    },
    "fr-ca": {
      "keyNew": "NOUVEAUTÉ",
      "keyPreorder": "PRÉCOMMANDER",
      "keySale": "MONDIAL",
      "keyExclusive": "AVANTAGES",
      "keyBestseller": "MEILLEURE VENTE",
      "keyLimitededition": "ÉDITION LIMITÉE",
      "keyCloud": "NUAGE",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ÉPUISÉE",
      "keyFreeengraving": "GRAVURE GRATUITE",
      "keyFreecopy": "GRATUIT"
    },
    "fr-ch": {
      "keyNew": "NOUVEAUTÉ",
      "keyPreorder": "PRÉCOMMANDER",
      "keySale": "MONDIALES",
      "keyExclusive": "AVANTAGES",
      "keyBestseller": "MEILLEURES VENTES",
      "keyLimitededition": "ÉDITION LIMITÉE",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ÉPUISÉ",
      "keyFreeengraving": "GRAVURE GRATUITE",
      "keyFreecopy": "GRATUIT"
    },
    "fr-fr": {
      "keyNew": "NOUVEAUTÉ",
      "keyPreorder": "PRÉCOMMANDER",
      "keySale": "MONDIALES",
      "keyExclusive": "AVANTAGES",
      "keyBestseller": "MEILLEURES VENTES",
      "keyLimitededition": "ÉDITION LIMITÉE",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ÉPUISÉ",
      "keyFreeengraving": "GRAVURE GRATUITE",
      "keyFreecopy": "GRATUIT"
    },
    "he-il": {
      "keyNew": "NEW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "SALE",
      "keyExclusive": "EXCLUSIVE",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SOLD OUT",
      "keyFreeengraving": "FREE ENGRAVING",
    },
    "hu-hu": {
      "keyNew": "ÚJ",
      "keyPreorder": "ELŐRENDELÉS",
      "keySale": "AKCIÓ",
      "keyExclusive": "EXKLUZÍV",
      "keyBestseller": "LEGNÉPSZERŰBBEK",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "FELHŐ",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ELFOGYOTT",
      "keyFreeengraving": "INGYENES GRAVÍROZÁS",
      "keyFreecopy": "INGYENES"
    },
    "it-it": {
      "keyNew": "NOVITÀ",
      "keyPreorder": "PREORDINA",
      "keySale": "OFFERTA",
      "keyExclusive": "VANTAGGI",
      "keyBestseller": "PIÙ VENDUTI",
      "keyLimitededition": "EDIZIONE LIMITATA",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ESAURITO",
      "keyFreeengraving": "INCISIONE GRATUITA",
      "keyFreecopy": "GRATIS"
    },
    "ja-jp": {
      "keyNew": "新着",
      "keyPreorder": "予約受付中",
      "keySale": "セール",
      "keyExclusive": "限定",
      "keyBestseller": "ベストセラー",
      "keyLimitededition": "限定版",
      "keyCloud": "クラウド",
      "keyGamepass": "GAME PASS",
      "keySoldout": "売り切れ",
      "keyFreeengraving": "無料刻印サービス",
      "keyFreecopy": "無料"
    },
    "ko-kr": {
      "keyNew": "신제품",
      "keyPreorder": "예약 주문",
      "keySale": "세일",
      "keyExclusive": "특별 제공",
      "keyBestseller": "베스트셀러",
      "keyLimitededition": "한정판",
      "keyCloud": "클라우드",
      "keyGamepass": "Game Pass",
      "keySoldout": "품절",
      "keyFreeengraving": "무료 각인",
      "keyFreecopy": "무료"
    },
    "nb-no": {
      "keyNew": "NYHET",
      "keyPreorder": "FORHÅNDSBESTILL",
      "keySale": "SALG",
      "keyExclusive": "EKSKLUSIVT",
      "keyBestseller": "BESTSELGER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "SKYEN",
      "keyGamepass": "GAME PASS",
      "keySoldout": "UTSOLGT",
      "keyFreeengraving": "GRATIS INNGRAVERING",
      "keyFreecopy": "GRATIS"
    },
    "nl-be": {
      "keyNew": "NIEUW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "UITVERKOOP",
      "keyExclusive": "EXCLUSIEF",
      "keyBestseller": "BESTSELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "UITVERKOCHT",
      "keyFreeengraving": "GRATIS GRAVERING",
      "keyFreecopy": "GRATIS"
    },
    "nl-nl": {
      "keyNew": "NIEUW",
      "keyPreorder": "PRE-ORDER",
      "keySale": "UITVERKOOP",
      "keyExclusive": "EXCLUSIEF",
      "keyBestseller": "BESTSELLER",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "UITVERKOCHT",
      "keyFreeengraving": "GRATIS GRAVERING",
      "keyFreecopy": "GRATIS"
    },
    "pl-pl": {
      "keyNew": "NOWOŚĆ",
      "keyPreorder": "ZAMÓW W PRZEDSPRZEDAŻY",
      "keySale": "WYPRZEDAŻ",
      "keyExclusive": "EKSKLUZYWNE",
      "keyBestseller": "BESTSELLERY",
      "keyLimitededition": "EDYCJA LIMITOWANA",
      "keyCloud": "CHMURA",
      "keyGamepass": "GAME PASS",
      "keySoldout": "WYPRZEDANE",
      "keyFreeengraving": "DARMOWY GRAWERUNEK",
      "keyFreecopy": "BEZPŁATNIE"
    },
    "pt-br": {
      "keyNew": "NOVO",
      "keyPreorder": "PRÉ-VENDA",
      "keySale": "GRÁTIS",
      "keyExclusive": "VANTAGENS",
      "keyBestseller": "MAIS VENDIDOS",
      "keyLimitededition": "CONTROLE DE",
      "keyCloud": "NUVEM",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ESGOTADO",
      "keyFreeengraving": ""
    },
    "pt-pt": {
      "keyNew": "NOVO",
      "keyPreorder": "PRÉ-ENCOMENDAR",
      "keySale": "PROMOÇÃO",
      "keyExclusive": "EXCLUSIVO",
      "keyBestseller": "BEST SELLER",
      "keyLimitededition": "COMANDO",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "ESGOTADO",
      "keyFreeengraving": "GRAVAÇÃO GRÁTIS",
      "keyFreecopy": "GRÁTIS"
    },
    "ru-ru": {
      "keyNew": "НОВИНКА",
      "keyPreorder": "ОФОРМИТЬ ПРЕДЗАКАЗ",
      "keySale": "РАСПРОДАЖА",
      "keyExclusive": "ЭКСКЛЮЗИВ",
      "keyBestseller": "БЕСТСЕЛЛЕР",
      "keyLimitededition": "ОГРАНИЧЕННАЯ СЕРИЯ",
      "keyCloud": "ОБЛАКО",
      "keyGamepass": "АБОНЕМЕНТ GAME PASS",
      "keySoldout": "ПРОДАНО",
      "keyFreeengraving": ""
    },
    "sk-sk": {
      "keyNew": "NOVÉ",
      "keyPreorder": "PREDOBJEDNAŤ",
      "keySale": "VÝPREDAJ",
      "keyExclusive": "EXKLUZÍVNE",
      "keyBestseller": "NAJPREDÁVANEJŠIE",
      "keyLimitededition": "LIMITOVANÉ VYDANIE",
      "keyCloud": "CLOUD",
      "keyGamepass": "GAME PASS",
      "keySoldout": "VYPREDANÉ",
      "keyFreeengraving": "",
      "keyFreecopy": "BEZPLATNÉ"
    },
    "sv-se": {
      "keyNew": "NYHET",
      "keyPreorder": "FÖRBESTÄLL",
      "keySale": "REA",
      "keyExclusive": "EXKLUSIVA",
      "keyBestseller": "BÄSTSÄLJARE",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "I MOLNET",
      "keyGamepass": "GAME PASS",
      "keySoldout": "SLUTSÅLD",
      "keyFreeengraving": "GRATIS GRAVERING",
      "keyFreecopy": "GRATIS"
    },
    "tr-tr": {
      "keyNew": "YENİ",
      "keyPreorder": "ÖN SİPARİŞ VERİN",
      "keySale": "İNDİRİM",
      "keyExclusive": "ÖZEL",
      "keyBestseller": "ÇOK SATAN",
      "keyLimitededition": "LIMITED EDITION",
      "keyCloud": "BULUT",
      "keyGamepass": "GAME PASS",
      "keySoldout": "TÜKENDİ",
      "keyFreeengraving": ""
    },
    "zh-hk": {
      "keyNew": "新上市",
      "keyPreorder": "預購",
      "keySale": "特惠",
      "keyExclusive": "獨家",
      "keyBestseller": "暢銷遊戲",
      "keyLimitededition": "限量版",
      "keyCloud": "雲端",
      "keyGamepass": "GAME PASS",
      "keySoldout": "售完",
      "keyFreeengraving": ""
    }, 
    "zh-tw": {
      "keyNew": "新上市",
      "keyPreorder": "預購",
      "keySale": "特惠",
      "keyExclusive": "獨家遊戲",
      "keyBestseller": "最暢銷",
      "keyLimitededition": "限量版",
      "keyCloud": "雲端",
      "keyGamepass": "GAME PASS",
      "keySoldout": "售完",
      "keyFreeengraving": "免費刻字",
      "keyFreecopy": "免費"
    }
  }
} 
  
  //If you don't send in the format from the PriceFormat JSON, you're going to have a bad time.
  function formatCurrency(price, format) {
      var formattedPrice = "" + price;
      if (!format.keyHasDecimal) {
          formattedPrice = formattedPrice.split(".")[0];
      } else if (formattedPrice.split(".")[1] == null) {
          // Function Change 1/10/23
          formattedPrice = formattedPrice.split(".")[0] + ".00";
      }
      if (formattedPrice.split(".")[0].length > 3) { // Needs to figure out thousands
          //console.log("splitting thousands");
          if (!format.keyHasDecimal) {
              formattedPrice = formattedPrice.substring(0, formattedPrice.length - 3) + "*" + formattedPrice.substring(formattedPrice.length - 3, formattedPrice.length);
          } else {
              formattedPrice = formattedPrice.substring(0, formattedPrice.length - 6) + "*" + formattedPrice.substring(formattedPrice.length - 6, formattedPrice.length);
          }
      }
      if (formattedPrice.split(".")[0].length > 7) { // Needs to figure out millions
          //console.log("splitting millions");
          if (!format.keyHasDecimal) {
              formattedPrice = formattedPrice.substring(0, formattedPrice.length - 7) + "MMM" + formattedPrice.substring(formattedPrice.length - 7, formattedPrice.length);
          } else {
              formattedPrice = formattedPrice.substring(0, formattedPrice.length - 10) + "MMM" + formattedPrice.substring(formattedPrice.length - 10, formattedPrice.length);
          }
      }
  
      if (format.keyThousandCharacter === ",") {
          //console.log("replacing thousand");
          formattedPrice = formattedPrice.replace("*", format.keyThousandCharacter);
          formattedPrice = formattedPrice.replace("MMM", format.keyThousandCharacter);
      } else {
          //console.log("replacing period");
          formattedPrice = formattedPrice.replace(".", ",");
          formattedPrice = formattedPrice.replace("*", format.keyThousandCharacter);
          formattedPrice = formattedPrice.replace("MMM", format.keyThousandCharacter);
      }
      // Added US 6/21/23
      if (urlRegion === "en-sg" || urlRegion === "en-us" || urlRegion === "en-au" || urlRegion === "en-nz" ) {
          if (formattedPrice.split(".")[1].length <= 1) {
              formattedPrice = formattedPrice + "0"
          }
      }
  
      formattedPrice = "" + format.keyPriceFormat.replace("#", formattedPrice);
  
      return formattedPrice;
  }