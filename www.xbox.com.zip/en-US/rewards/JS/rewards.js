
if (window.location.search !== '' && window.location.search !== undefined) {
    var queryString = window.location.search;
    queryString = queryString.replace(/</g, "").replace('?', '');

    var rewardsButton = $('#heroRewardsCTA'); 
    var rewardsButton2 = $('#3upRewardsCTA');
    var rewardsHREF = rewardsButton.attr('href');
    var rewardsQS = "";

    if (rewardsHREF) {
        rewardsQS = rewardsHREF.split('?');
    }
    var rewardsQS_base = rewardsQS[0];
    var rewardsQS_Parts = rewardsQS[1].split("&");
    var queryString_Parts = queryString.split("&");
    var final_parts = queryString_Parts;

    if (rewardsQS_Parts) {
        rewardsQS_Parts.forEach(function(reward_element) {
            var foundMatch = false;
            if (queryString_Parts) {
                queryString_Parts.forEach(function(qs_element) {
                    if (qs_element.split('=')[0].toLowerCase() == reward_element.split('=')[0].toLowerCase()) {
                        foundMatch = true;
                    }
                });
            }
            if (!foundMatch) {
                final_parts.push(reward_element)
            }
        });
    }
    var final_QS = "?";
    var index = 1;
    final_parts.forEach(function(final_element) {
        final_QS += final_element;
        if (index < final_parts.length) {
            final_QS += '&';
        }
        index += 1;
    });
    rewardsButton.attr('href',rewardsQS_base + final_QS);
    rewardsButton2.attr('href',rewardsQS_base + final_QS);
    console.log(rewardsButton2.attr('href'));
}