$(document).ready(function() {

    var urlRegion = document.URL.split("/")[3].toLowerCase();
    
    if (urlRegion === "fr-fr") {
        $(".rotator-heading h3").each(function(i) {
        $(this).after('<span class="disclosureContainer">' +
        '<button class="glyph-prepend glyph-prepend-info" type="button" aria-describedby="frDisclosure' + i + '"></button>' +
        '<div class="c-flyout f-beak frDisclosure" id="frDisclosure' + i + '" role="tooltip" data-js-flyout-placement="top" data-js-flyout-dismissible="true" aria-hidden="true">' +
        '<button tabindex="0" class="disclosureClose" aria-label="bouton de fermeture pour l\'info-bulle">' +
        '<img src="https://assets.xboxservices.com/assets/3b/df/3bdfab2d-d1b1-4019-9bac-d953db4fd7fb.svg?n=Games-Catalog_Image-0_X-Button_230x120.svg" alt="bouton de fermeture">' +
        '</button>' +
        '<p class="c-paragraph">Voir <a href="https://www.microsoft.com/fr-fr/store/b/imprint" target="_blank">mentions légales et informations consommateurs</a> pour ' +
        'plus d\'informations sur les critères de classement.</p>' +
        '</div>' +
        '</span>')
    })
    
    $(".disclosureContainer .glyph-prepend").click(function() {
    const butInd = $(this).index(".glyph-prepend");
        
    setTimeout(function() {
        if ($(".frDisclosure").css("display") !== 'none') {
        if ($(".CatAnnounce").text() === "l'info-bulle s'est ouverte") {
        $(".CatAnnounce").text("l'info-bulle s'est ouverte.")
        } else {
        $(".CatAnnounce").text("l'info-bulle s'est ouverte")
        }
        } else {  
        $(".CatAnnounce").text("l'info-bulle s'est fermée")
        }
        $(".disclosureClose")[butInd].focus()
        }, 30)
        })
        $(".disclosureClose").click(function() {
        $(this).closest(".c-flyout").prev("button").click();
        })
    }
     
    regionRatingOrgs = { "en-us" : "ESRB", "en-au" : "COB-AU", "en-hk" : "IARC", "en-in" : "IARC", "en-nz" : "OFLC-NZ", "en-sg" : "IARC", "ja-jp" : "CERO", "ko-kr" : "GRB", "zh-hk" : "IARC", "zh-tw" : "CSRR", "ar-ae" : "IARC", "ar-sa" : "IARC", "cs-cz" : "PEGI", "da-dk" : "PEGI", "de-at" : "PEGI", "de-ch" : "PEGI", "de-de" : "USK", "el-gr" : "PEGI", "en-gb" : "PEGI", "en-ie" : "PEGI", "en-za" : "FPB", "fi-fi" : "PEGI", "fr-be" : "PEGI", "fr-ch" : "PEGI", "fr-fr" : "PEGI", "he-il" : "PEGI", "hu-hu" : "PEGI", "it-it" : "PEGI", "nb-no" : "PEGI", "nl-be" : "PEGI", "nl-nl" : "PEGI", "pl-pl" : "PEGI", "pt-pt" : "PEGI", "ru-ru" : "PCBP", "sk-sk" : "PEGI", "sv-se" : "PEGI", "tr-tr" : "PEGI", "en-ca" : "ESRB", "fr-ca" : "ESRB", "es-ar" : "ESRB", "es-cl" : "CCC", "es-co" : "ESRB", "es-es" : "PEGI", "es-mx" : "ESRB", "pt-br": "DJCTQ" };
    
    ratingorg = regionRatingOrgs[urlRegion];

    var ratingsApi = (function() {
        var ratingsUrl = "https://displaycatalog.mp.microsoft.com/v7.0/ratings?market=US&languages=LANG&MS-CV=DGU1mcuYo0WMMp+F.1"
        ratingsUrl = ratingsUrl.replace("US", urlRegion.split("-")[1]).replace("LANG", urlRegion);
  
        $.get(ratingsUrl)
          .done(function(listData) {
            ratingData = listData;
          })
      })();

    var onlineUrl = "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/TopPaid?Market=" + urlRegion.split("-")[1] + "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.Xbox&count=2000&skipitems=0";
    
    var onlineArray = [];
        
        // Get GUIDS
    $.get(onlineUrl)
        .done(function(responseData) {
            responseData.Items.forEach(function(e) {
            onlineArray.push(e.Id)
    });
    
        // onlineArray = onlineArray.splice(0, 12);
        var onlineGuids = onlineArray.join(",");
    
        gamesPop(onlineGuids);
    
    });
        
        
    function gamesPop(onlineGuids) {
    
        var countryCode = urlRegion.split("-")[1].toUpperCase();
        var guidOnline = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
    
        guidOnline = guidOnline.replace("GAMEIDS", onlineGuids);
    
        $.get(guidOnline)
        .done(function(responseData) {
        var onlineData = responseData;
    
            populateOne(onlineData);
        });
    }
        
    function populateOne(data) {
        // var bigidUrls = biUrls.items.urls;
        // var biuArray = Object.keys(bigidUrls);
        
        var productlength = data.Products.length;
        
        for (var x = 0; x < productlength; x++) {
            // Item Id/Title
            var itemId = data.Products[x].ProductId.toUpperCase();
            var itemTitle = data.Products[x].LocalizedProperties[0].ProductTitle;
            if (itemTitle === undefined) {
            itemTitle = "";
            }
            var itemUrlName = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, "");
            if (itemUrlName === "") {
            itemUrlName = "-"
        }
        
        var shortDesc = data.Products[x].LocalizedProperties[0].ShortDescription;
        if (shortDesc === "") {
        shortDesc = data.Products[x].LocalizedProperties[0].ProductDescription;
        }
        if (shortDesc === undefined) {
        shortDesc = "";
        }
        
        var imagesNum = data.Products[x].LocalizedProperties[0].Images.length;
        var imgEnd = 999;
        
        for (var j = 0; j < imagesNum; j++) {
            if (data.Products[x].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                imgEnd = j;
                break;
            }
        }
        
        if (imgEnd === 999) {
            for (var j = 0; j < imagesNum; j++) {
                if (data.Products[x].LocalizedProperties[0].Images[j].Width < data.Products[x].LocalizedProperties[0].Images[j].Height) {
                    imgEnd = j;
                    break
                }
            }
        }
        
        if (imgEnd === 999) {
            imgEnd = 1;
        }
        
        // Grabbing Image Path
        if (data.Products[x].LocalizedProperties[0].Images[imgEnd]) {
            var itemBoxshot = data.Products[x].LocalizedProperties[0].Images[imgEnd].Uri.replace("http:", "https:");
            var itemBoxshotSmall;
        } else {
            var itemBoxshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
            var itemBoxshotSmall = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
        }
        if (itemBoxshot.indexOf("store-images") !== -1) {
            itemBoxshotSmall = itemBoxshot + "?w=140";
            // itemBoxshot = itemBoxshot + "&h=300&w=200&format=jpg";
            itemBoxshot = itemBoxshot + "?w=280";
        } else {
            itemBoxshotSmall = itemBoxshot;
        }
        
        // URL turn back on and add file to get Xbox URLs
        // if (biuArray.indexOf(itemId) === -1 || bigidUrls[itemId].toLowerCase().indexOf(urlRegion) !== -1) {
    
            var itemhref = 'https://www.xbox.com/' + urlRegion + '/games/store/' + itemUrlName + '/' + itemId;
        // } else {
        //     var itemhref = bigidUrls[itemId].split("<exc>")[0];
        //     var splitHref = itemhref.split("/");
        //     splitHref.splice(3, 0, urlRegion);
        //     itemhref = splitHref.join("/");
        // }
        
        var rating = "none";
        var ratingUrl = "https://www.esrb.org/";
        var ratingcode = "";
        var ratingage = 99;
        var ratingsystem = "none";
        var kidfamilyratings = [ "ESRB:E","ESRB:EC", "PEGI:3", "COB-AU:G", "OFLC-NZ:G", "USK:Everyone",
            "PCBP:0", "DJCTQ:L", "CSRR:G", "CERO:A", "GRB:All", "IARC:3", "CCC:TE"
        ]
        var rawdescriptors = "none";
        var rawinteractive = "none";
        var rawdisclaimers = "none";
        var pegiFallbackRegions = "en-za ,";
        var iarcFallbackRegions = "ja-jp ,";
        var cr = 99;
        var cresrb = 99;
        var crfallback = 0;
        var crfallback_PEGI = -1;
        var crfallback_IARC = -1;
        if (data.Products[x].MarketProperties[0].ContentRatings !== undefined && data.Products[x].MarketProperties[0].ContentRatings !== null && data.Products[x].MarketProperties[0].ContentRatings.length > 0) {
            for (var c = 0; c < data.Products[x].MarketProperties[0].ContentRatings.length; c++) {
              // if (data.Products[x].MarketProperties[0].ContentRatings[c].RatingSystem === "ESRB") {
              //   cresrb = c;
              // }
              if (data.Products[x].MarketProperties[0].ContentRatings[c].RatingSystem === "Microsoft") { // Microsoft rating is fallback
                crfallback = c;
              }
              if ((pegiFallbackRegions.includes(urlRegion)) && data.Products[x].MarketProperties[0].ContentRatings[c].RatingSystem === "PEGI") { // PEGI fallback for en-za
                crfallback_PEGI = c;
              }
              if ((iarcFallbackRegions.includes(urlRegion)) && data.Products[x].MarketProperties[0].ContentRatings[c].RatingSystem === "IARC") { // PEGI fallback for en-za
                crfallback_IARC = c;
              }
              if (data.Products[x].MarketProperties[0].ContentRatings[c].RatingSystem === ratingorg) {
                cr = c;
              }
            }
            if (cr === 99) { cr = cresrb } // if region's rating system is not found, use esrb
            if (cr === 99) { cr = crfallback } // fallback if no esrb either
            if ((pegiFallbackRegions.includes(urlRegion)) && crfallback_PEGI !== -1 && cr === crfallback) { cr = crfallback_PEGI } // fallback if pegi needed
            if ((iarcFallbackRegions.includes(urlRegion)) && crfallback_IARC !== -1 && cr === crfallback) { cr = crfallback_IARC } // fallback if iarc needed
            ratingsystem = data.Products[x].MarketProperties[0].ContentRatings[cr].RatingSystem;
            ratingcode = data.Products[x].MarketProperties[0].ContentRatings[cr].RatingId;

            var ratimage = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].LocalizedProperties[0].LogoUrl;
            ratingage = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].Age;
            rating = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].LocalizedProperties[0].LongName;
            ratingUrl = ratingData.RatingBoards[ratingsystem].LocalizedProperties[0].Url;
            

            rawdescriptors = data.Products[x].MarketProperties[0].ContentRatings[cr].RatingDescriptors.join(",");
            rawinteractive = data.Products[x].MarketProperties[0].ContentRatings[cr].InteractiveElements.join(",");
            rawdisclaimers = data.Products[x].MarketProperties[0].ContentRatings[cr].RatingDisclaimers.join(",");
        }
        


    if (kidfamilyratings.indexOf(ratingcode) !== -1) {
    $(".familyCarousel" + " ul").append('<li>' +
        '<section class="m-product-placement-item f-size-large context-device f-clean" data-prodid="' + itemId + '">' +
        '<a target="blank" href="' + itemhref + '" data-retailer="MS Store" aria-label="' + itemTitle + '">' +
        '<picture>' +
        '<source srcset="' + itemBoxshot + '" media="(min-width:0)">' +
        '<img class="c-image" srcset="' + itemBoxshot + '" src="' + itemBoxshot + '" ' +
        'alt="' + itemTitle + ' boxshot">' +
        '</picture>' +
        '<div>' +
        '<h3 class="c-heading">' + itemTitle + '</h3>' +
        '</div>' +
        '</a>' +
        '</section>' +
        '</li>');
        }
    }
    
    $(".familyCarousel").closest(".featured-games").fadeIn("slow");
    
    }
    
    });