$(document).ready(function() {
  // targeted content
  if (typeof(xb_tgt) !== 'undefined') {
    console.log("running targeted content")

    if (xb_tgt === "signedout") {
      $(".targ_signedIn").remove()
      $(".targ_signedOut").removeClass("hidden")
    } else {
      $(".targ_signedOut").remove()
      $(".targ_signedIn").removeClass("hidden")
    }
  }
  // end targeted content

  //contextual store redeem code
  $(".contextualRedeemLink").each(function() {
    $(this).attr("href", "JavaScript:void(0);")
           .attr("onclick", 'document.dispatchEvent(new CustomEvent("launchContextualStore", {detail: { experience: "Redeem" },}))')
  })
})